#!/bin/bash

# ============================================
# CAPTIVE PORTAL CARNAVAL DE RECIFE
# Script de Deploy Automático com SSL
# ============================================

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Funções de log
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step() { echo -e "${PURPLE}[ETAPA $1]${NC} $2"; }

# Banner
echo -e "${YELLOW}"
cat << "EOF"
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🎭 CAPTIVE PORTAL CARNAVAL DE RECIFE 🎭                ║
║   Deploy Automático com SSL                               ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

# Verificar se está rodando como root
if [ "$EUID" -ne 0 ]; then
    log_error "Execute este script como root (sudo ./deploy.sh)"
    exit 1
fi

# Diretório do projeto
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

log_info "Diretório do projeto: $PROJECT_DIR"

# ============================================
# ETAPA 0: COLETAR INFORMAÇÕES
# ============================================
log_step "0" "Coletando informações de configuração"

echo ""
echo -e "${YELLOW}═══ CONFIGURAÇÃO DO DOMÍNIO E SSL ═══${NC}"
echo ""
read -p "Digite o domínio para o certificado SSL (ex: captive.seudominio.com): " DOMAIN
read -p "Digite o email para notificações do Let's Encrypt (ex: admin@seudominio.com): " EMAIL
read -p "Digite o IP público do servidor (ex: 206.42.50.83): " PUBLIC_IP

echo ""
echo -e "${YELLOW}═══ CONFIGURAÇÃO DO ABACATEPAY ═══${NC}"
echo ""
read -p "Digite a API Key do AbacatePay: " ABACATEPAY_KEY
read -p "Digite o Webhook Secret do AbacatePay: " WEBHOOK_SECRET

echo ""
echo -e "${YELLOW}═══ CONFIGURAÇÃO DO MIKROTIK ═══${NC}"
echo ""
read -p "Digite o IP do roteador MikroTik (ex: 192.168.10.1): " ROUTER_IP
read -p "Digite o usuário do MikroTik (padrão: admin): " ROUTER_USER
ROUTER_USER=${ROUTER_USER:-admin}
read -s -p "Digite a senha do MikroTik: " ROUTER_PASS
echo ""

# Validar domínio
if [ -z "$DOMAIN" ]; then
    log_error "Domínio não pode estar vazio!"
    exit 1
fi

# Validar email
if [ -z "$EMAIL" ]; then
    log_error "Email não pode estar vazio!"
    exit 1
fi

log_success "Configuração coletada"

# ============================================
# ETAPA 1: ATUALIZAR SISTEMA
# ============================================
log_step "1" "Atualizando sistema"
apt-get update -qq
apt-get upgrade -y -qq
log_success "Sistema atualizado"

# ============================================
# ETAPA 2: INSTALAR DEPENDÊNCIAS
# ============================================
log_step "2" "Instalando dependências"

# Docker
if ! command -v docker &> /dev/null; then
    log_info "Instalando Docker..."

    apt-get install -y -qq \
        ca-certificates \
        curl \
        gnupg \
        lsb-release

    mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg

    echo \
        "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
        $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null

    apt-get update -qq
    apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin

    systemctl enable docker
    systemctl start docker

    log_success "Docker instalado"
else
    log_success "Docker já instalado"
fi

# Certbot (Let's Encrypt)
if ! command -v certbot &> /dev/null; then
    log_info "Instalando Certbot..."
    apt-get install -y -qq certbot
    log_success "Certbot instalado"
else
    log_success "Certbot já instalado"
fi

# ============================================
# ETAPA 3: GERAR CERTIFICADO SSL
# ============================================
log_step "3" "Gerando certificado SSL com Let's Encrypt"

SSL_DIR="$PROJECT_DIR/nginx/ssl"
mkdir -p "$SSL_DIR"

# Parar nginx se estiver rodando (para liberar porta 80)
if docker ps | grep -q nginx; then
    log_info "Parando nginx temporariamente..."
    docker stop captive-portal-nginx 2>/dev/null || true
fi

# Gerar certificado com certbot
if [ ! -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]; then
    log_info "Gerando certificado SSL para $DOMAIN..."

    certbot certonly --standalone \
        --non-interactive \
        --agree-tos \
        --email "$EMAIL" \
        -d "$DOMAIN"

    log_success "Certificado SSL gerado para $DOMAIN"
else
    log_success "Certificado SSL já existe para $DOMAIN"
fi

# Copiar certificados para o projeto
log_info "Copiando certificados..."
cp "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" "$SSL_DIR/server.crt"
cp "/etc/letsencrypt/live/$DOMAIN/privkey.pem" "$SSL_DIR/server.key"
chmod 600 "$SSL_DIR/server.key"
chmod 644 "$SSL_DIR/server.crt"
log_success "Certificados copiados"

# Criar script de renovação automática
log_info "Configurando renovação automática..."
cat > /etc/cron.d/certbot-renew << EOF
# Renovar certificado SSL automaticamente
0 2 * * * root certbot renew --quiet --post-hook "cp /etc/letsencrypt/live/$DOMAIN/fullchain.pem $SSL_DIR/server.crt && cp /etc/letsencrypt/live/$DOMAIN/privkey.pem $SSL_DIR/server.key && docker restart captive-portal-nginx"
EOF
log_success "Renovação automática configurada (diariamente às 2AM)"

# ============================================
# ETAPA 4: CRIAR/ATUALIZAR ARQUIVO .ENV
# ============================================
log_step "4" "Configurando variáveis de ambiente"

# Gerar secrets seguros
JWT_SECRET=$(openssl rand -hex 32)
SESSION_SECRET=$(openssl rand -hex 32)
DB_PASSWORD=$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)

# URL do webhook com domínio
WEBHOOK_URL="https://$DOMAIN/api/webhooks/abacatepay"

cat > "$PROJECT_DIR/.env" << EOF
# ============================================
# CAPTIVE PORTAL CARNAVAL DE RECIFE
# Configuração de Ambiente - PRODUÇÃO
# Gerado automaticamente em $(date)
# ============================================

# Ambiente
NODE_ENV=production
PORT=3000

# URLs Públicas
PUBLIC_URL=https://$DOMAIN
PUBLIC_URL_HTTP=http://$PUBLIC_IP
LOCAL_IP=192.168.10.250

# Domínio SSL
DOMAIN=$DOMAIN

# ============================================
# SEGURANÇA
# ============================================
JWT_SECRET=$JWT_SECRET
SESSION_SECRET=$SESSION_SECRET

# ============================================
# BANCO DE DADOS
# ============================================
DB_HOST=postgres
DB_PORT=5432
DB_NAME=captive_portal
DB_USER=captive
DB_PASSWORD=$DB_PASSWORD

DATABASE_URL=postgresql://captive:$DB_PASSWORD@postgres:5432/captive_portal

# ============================================
# REDIS
# ============================================
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=

# ============================================
# ABACATEPAY (Gateway de Pagamento Pix)
# ============================================
ABACATEPAY_API_KEY=$ABACATEPAY_KEY
ABACATEPAY_API_URL=https://api.abacatepay.com/v1
ABACATEPAY_WEBHOOK_SECRET=$WEBHOOK_SECRET
ABACATEPAY_WEBHOOK_URL=$WEBHOOK_URL
ABACATEPAY_ENABLED=true
ABACATEPAY_FEE=0
ABACATEPAY_FIXED_FEE=80

# ============================================
# MIKROTIK
# ============================================
ROUTER_IP=$ROUTER_IP
ROUTER_USER=$ROUTER_USER
ROUTER_PASSWORD=$ROUTER_PASS
ROUTER_PORT=8728
ROUTER_INTERFACE=ether2
MIKROTIK_SIMULATED=false

# ============================================
# ADMIN PADRÃO
# ============================================
ADMIN_CPF=11111111111
ADMIN_PASSWORD=Admin@Carnaval2026!
ADMIN_NAME=Administrador
ADMIN_EMAIL=$EMAIL

# ============================================
# CONFIGURAÇÕES DE SESSÃO
# ============================================
SESSION_CHECK_INTERVAL=60000
JWT_EXPIRATION=24h

# ============================================
# RATE LIMITING
# ============================================
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOGIN_RATE_LIMIT_MAX=5
PAYMENT_RATE_LIMIT_MAX=3

# ============================================
# LOGS
# ============================================
LOG_LEVEL=info
LOG_RETENTION_DAYS=365

# ============================================
# PROMETHEUS/GRAFANA
# ============================================
PROMETHEUS_ENABLED=true
GRAFANA_ADMIN_PASSWORD=GrafanaAdmin2026!
EOF

log_success "Arquivo .env criado com certificado SSL válido"

# ============================================
# ETAPA 5: CRIAR DIRETÓRIOS NECESSÁRIOS
# ============================================
log_step "5" "Criando diretórios"
mkdir -p "$PROJECT_DIR/logs"
mkdir -p "$PROJECT_DIR/monitoring/grafana/dashboards"
mkdir -p "$PROJECT_DIR/monitoring/grafana/datasources"
log_success "Diretórios criados"

# ============================================
# ETAPA 6: CONFIGURAR PROMETHEUS
# ============================================
log_step "6" "Configurando Prometheus"
cat > "$PROJECT_DIR/monitoring/prometheus.yml" << 'EOF'
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'captive-portal'
    static_configs:
      - targets: ['app:3000']
    metrics_path: '/api/metrics'

  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']
EOF
log_success "Prometheus configurado"

# ============================================
# ETAPA 7: BUILD E DEPLOY
# ============================================
log_step "7" "Construindo e iniciando containers"

log_info "Construindo imagens Docker..."
docker compose build --no-cache

log_info "Iniciando containers..."
docker compose up -d

# ============================================
# ETAPA 8: AGUARDAR SERVIÇOS
# ============================================
log_step "8" "Aguardando serviços iniciarem"
sleep 10

RETRIES=30
COUNT=0
while [ $COUNT -lt $RETRIES ]; do
    if docker compose ps | grep -q "healthy"; then
        break
    fi
    sleep 2
    COUNT=$((COUNT + 1))
    echo -n "."
done
echo ""

# ============================================
# ETAPA 9: VERIFICAR DEPLOY
# ============================================
log_step "9" "Verificando deploy"

if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/health | grep -q "200"; then
    log_success "Aplicação rodando na porta 3000"
else
    log_warning "Aplicação pode estar iniciando ainda..."
fi

if curl -s -o /dev/null -w "%{http_code}" https://$DOMAIN/health | grep -q "200"; then
    log_success "HTTPS rodando com certificado válido"
else
    log_warning "HTTPS pode estar iniciando ainda..."
fi

# ============================================
# ETAPA 10: CONFIGURAR FIREWALL
# ============================================
log_step "10" "Configurando firewall"
if command -v ufw &> /dev/null; then
    ufw allow 80/tcp comment "HTTP Captive Portal"
    ufw allow 443/tcp comment "HTTPS Captive Portal"
    log_success "Portas liberadas no firewall"
fi

# ============================================
# STATUS FINAL
# ============================================
echo ""
echo -e "${GREEN}"
cat << "EOF"
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   ✅ DEPLOY CONCLUÍDO COM SUCESSO!                       ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

echo ""
log_info "Status dos containers:"
docker compose ps

echo ""
echo -e "${GREEN}═══ URLs DE ACESSO ═══${NC}"
echo "   🌐 Portal HTTP:  http://$PUBLIC_IP"
echo "   🔒 Portal HTTPS: https://$DOMAIN"
echo "   👤 Admin:        https://$DOMAIN/admin-login"
echo "   💚 Health Check: https://$DOMAIN/health"
echo ""
echo -e "${YELLOW}═══ WEBHOOK ABACATEPAY ═══${NC}"
echo "   Configure esta URL no painel do AbacatePay:"
echo "   📍 $WEBHOOK_URL"
echo ""
echo -e "${BLUE}═══ CREDENCIAIS ADMIN ═══${NC}"
echo "   CPF:   11111111111"
echo "   Senha: Admin@Carnaval2026!"
echo ""
echo -e "${YELLOW}═══ IMPORTANTE ═══${NC}"
echo "   1. Configure o MikroTik com o script em:"
echo "      scripts/mikrotik-setup.rsc"
echo ""
echo "   2. Configure o webhook no painel do AbacatePay:"
echo "      URL: $WEBHOOK_URL"
echo "      Secret: $WEBHOOK_SECRET"
echo ""
echo "   3. O certificado SSL será renovado automaticamente"
echo "      Renovação diária às 2AM via cron"
echo ""
echo -e "${PURPLE}═══ COMANDOS ÚTEIS ═══${NC}"
echo "   Ver logs:       docker compose logs -f app"
echo "   Ver logs nginx: docker compose logs -f nginx"
echo "   Reiniciar:      docker compose restart"
echo "   Parar:          docker compose down"
echo "   Atualizar:      docker compose build && docker compose up -d"
echo ""
echo -e "${GREEN}═══ INFORMAÇÕES SSL ═══${NC}"
echo "   Domínio:    $DOMAIN"
echo "   Certificado válido até: $(openssl x509 -in $SSL_DIR/server.crt -noout -enddate | cut -d= -f2)"
echo "   Renovação automática: Configurada"
echo ""

log_success "Deploy concluído! Portal pronto para uso."
