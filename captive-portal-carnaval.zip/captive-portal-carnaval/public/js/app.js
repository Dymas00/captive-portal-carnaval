/**
 * CAPTIVE PORTAL - CARNAVAL DE RECIFE
 * JavaScript Principal
 */

// ===== CONFIGURAÇÃO =====
const API_URL = '/api';
let authToken = localStorage.getItem('authToken');
let currentUser = JSON.parse(localStorage.getItem('currentUser') || 'null');
let paymentCheckInterval = null;
let sessionCheckInterval = null;

// URLs de redirecionamento após pagamento (captive portal success)
// Usar URL externa para forçar fechamento do captive portal
const REDIRECT_URLS = [
    'https://www.google.com',
    'https://www.youtube.com',
    'http://www.google.com'
];
const REDIRECT_URL = REDIRECT_URLS[0]; // Google como padrão

// ===== ELEMENTOS DOM =====
const elements = {
    // Tabs
    tabs: document.querySelectorAll('.tab-btn'),
    tabContents: document.querySelectorAll('.tab-content'),

    // Forms
    loginForm: document.getElementById('loginForm'),
    registerForm: document.getElementById('registerForm'),

    // Plans
    plansGrid: document.getElementById('plansGrid'),

    // Modals
    paymentModal: document.getElementById('paymentModal'),
    successModal: document.getElementById('successModal'),

    // Payment
    qrCodeContainer: document.getElementById('qrCodeContainer'),
    pixCopiaColaInput: document.getElementById('pixCopiaColaInput'),
    copyPixBtn: document.getElementById('copyPixBtn'),
    paymentExpiry: document.getElementById('paymentExpiry'),
    paymentAmount: document.getElementById('paymentAmount'),
    paymentPlanName: document.getElementById('paymentPlanName'),
    paymentStatus: document.getElementById('paymentStatus'),

    // Success
    sessionPlan: document.getElementById('sessionPlan'),
    sessionTime: document.getElementById('sessionTime'),

    // Active Session
    activeSessionPanel: document.getElementById('activeSessionPanel'),
    sessionUserName: document.getElementById('sessionUserName'),
    sessionPlanName: document.getElementById('sessionPlanName'),
    sessionTimeRemaining: document.getElementById('sessionTimeRemaining'),
    sessionProgressBar: document.getElementById('sessionProgressBar'),
    logoutBtn: document.getElementById('logoutBtn'),

    // Toast
    toastContainer: document.getElementById('toastContainer')
};

// ===== INICIALIZAÇÃO =====
document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    initForms();
    initModals();
    loadPlans();
    checkAuthStatus();
    initCPFMask();
    initPhoneMask();
    initPasswordToggle();
});

// ===== TABS =====
function initTabs() {
    elements.tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetId = tab.dataset.tab;
            switchTab(targetId);
        });
    });

    // Links de navegação entre tabs
    document.querySelectorAll('[data-goto]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            switchTab(link.dataset.goto);
        });
    });
}

function switchTab(tabId) {
    elements.tabs.forEach(t => t.classList.remove('active'));
    elements.tabContents.forEach(c => c.classList.remove('active'));

    const tab = document.querySelector(`[data-tab="${tabId}"]`);
    const content = document.getElementById(tabId);

    if (tab) tab.classList.add('active');
    if (content) content.classList.add('active');
}

// ===== FORMULÁRIOS =====
function initForms() {
    // Login
    if (elements.loginForm) {
        elements.loginForm.addEventListener('submit', handleLogin);
    }

    // Registro
    if (elements.registerForm) {
        elements.registerForm.addEventListener('submit', handleRegister);
    }

    // Logout
    if (elements.logoutBtn) {
        elements.logoutBtn.addEventListener('click', handleLogout);
    }
}

async function handleLogin(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const cpf = formData.get('cpf').replace(/\D/g, '');
    const password = formData.get('password');
    const macAddress = getMacAddress();

    if (!validateCPF(cpf)) {
        showToast('CPF inválido', 'error');
        return;
    }

    const btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<span>Entrando...</span> <i class="fas fa-spinner fa-spin"></i>';

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cpf, password, mac_address: macAddress })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Erro ao fazer login');
        }

        authToken = data.token;
        currentUser = data.user;
        localStorage.setItem('authToken', authToken);
        localStorage.setItem('currentUser', JSON.stringify(currentUser));

        showToast('Login realizado com sucesso!', 'success');
        checkAuthStatus();
        switchTab('plans');

    } catch (error) {
        showToast(error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<span>Entrar</span> <i class="fas fa-arrow-right"></i>';
    }
}

async function handleRegister(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const data = {
        name: formData.get('name'),
        cpf: formData.get('cpf').replace(/\D/g, ''),
        email: formData.get('email') || undefined,
        phone: formData.get('phone')?.replace(/\D/g, '') || undefined,
        password: formData.get('password'),
        mac_address: getMacAddress()
    };

    if (!validateCPF(data.cpf)) {
        showToast('CPF inválido', 'error');
        return;
    }

    if (data.password.length < 6) {
        showToast('Senha deve ter no mínimo 6 caracteres', 'error');
        return;
    }

    const btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<span>Cadastrando...</span> <i class="fas fa-spinner fa-spin"></i>';

    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || 'Erro ao cadastrar');
        }

        authToken = result.token;
        currentUser = result.user;
        localStorage.setItem('authToken', authToken);
        localStorage.setItem('currentUser', JSON.stringify(currentUser));

        showToast('Cadastro realizado com sucesso!', 'success');
        e.target.reset();
        checkAuthStatus();
        switchTab('plans');

    } catch (error) {
        showToast(error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<span>Cadastrar</span> <i class="fas fa-arrow-right"></i>';
    }
}

async function handleLogout() {
    try {
        if (authToken) {
            await fetch(`${API_URL}/auth/logout`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${authToken}` }
            });
        }
    } catch (error) {
        console.error('Logout error:', error);
    }

    authToken = null;
    currentUser = null;
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');

    if (sessionCheckInterval) {
        clearInterval(sessionCheckInterval);
    }

    elements.activeSessionPanel.classList.add('hidden');
    showToast('Logout realizado', 'info');
    switchTab('login');
}

// ===== PLANOS =====
async function loadPlans() {
    try {
        const response = await fetch(`${API_URL}/plans`);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Erro ao carregar planos');
        }

        renderPlans(data.plans);

    } catch (error) {
        elements.plansGrid.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <p>Erro ao carregar planos</p>
                <button onclick="loadPlans()" class="btn btn-secondary">
                    <i class="fas fa-redo"></i> Tentar novamente
                </button>
            </div>
        `;
    }
}

function renderPlans(plans) {
    elements.plansGrid.innerHTML = plans.map((plan, index) => `
        <div class="plan-card ${index === 1 ? 'popular' : ''}" data-plan-id="${plan.id}">
            <div class="plan-info">
                <div class="plan-details">
                    <h3>${plan.name}</h3>
                    <p>${plan.description || plan.duration_formatted}</p>
                </div>
                <div class="plan-price">
                    <span class="price">${plan.price_formatted}</span>
                    <span class="duration">${plan.duration_formatted}</span>
                </div>
            </div>
        </div>
    `).join('');

    // Event listeners para cards
    document.querySelectorAll('.plan-card').forEach(card => {
        card.addEventListener('click', () => selectPlan(card.dataset.planId));
    });
}

async function selectPlan(planId) {
    if (!authToken) {
        showToast('Faça login para continuar', 'warning');
        switchTab('login');
        return;
    }

    // Verificar se já tem sessão ativa
    try {
        const sessionResponse = await fetch(`${API_URL}/sessions/my`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        const sessionData = await sessionResponse.json();

        if (sessionData.active) {
            showToast('Você já possui uma sessão ativa!', 'warning');
            checkAuthStatus();
            return;
        }
    } catch (error) {
        console.error('Session check error:', error);
    }

    // Criar pagamento
    createPayment(planId);
}

// ===== PAGAMENTO =====
async function createPayment(planId) {
    showModal('paymentModal');

    elements.qrCodeContainer.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
    elements.pixCopiaColaInput.value = '';
    elements.paymentStatus.innerHTML = `
        <div class="status-icon pending">
            <i class="fas fa-hourglass-half"></i>
        </div>
        <p>Gerando QR Code...</p>
    `;

    try {
        const response = await fetch(`${API_URL}/payments/create`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                plan_id: planId,
                mac_address: getMacAddress()
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Erro ao criar pagamento');
        }

        renderPaymentData(data.payment);
        startPaymentCheck(data.payment.payment_id);

    } catch (error) {
        showToast(error.message, 'error');
        closeModal('paymentModal');
    }
}

function renderPaymentData(payment) {
    // QR Code
    if (payment.qr_code_base64) {
        elements.qrCodeContainer.innerHTML = `<img src="data:image/png;base64,${payment.qr_code_base64}" alt="QR Code Pix">`;
    } else {
        elements.qrCodeContainer.innerHTML = '<p>QR Code indisponível</p>';
    }

    // Pix Copia e Cola
    elements.pixCopiaColaInput.value = payment.pix_copia_cola || '';

    // Info
    elements.paymentPlanName.textContent = payment.plan?.name || 'Plano';
    elements.paymentAmount.textContent = payment.plan?.price_formatted || 'R$ 0,00';

    // Timer
    startExpiryTimer(payment.expires_at);

    // Status
    elements.paymentStatus.innerHTML = `
        <div class="status-icon pending">
            <i class="fas fa-hourglass-half"></i>
        </div>
        <p>Aguardando pagamento...</p>
    `;

    // Copy button
    elements.copyPixBtn.onclick = () => {
        navigator.clipboard.writeText(payment.pix_copia_cola || '');
        showToast('Código copiado!', 'success');
    };
}

function startExpiryTimer(expiresAt) {
    const endTime = new Date(expiresAt).getTime();

    const updateTimer = () => {
        const now = Date.now();
        const remaining = endTime - now;

        if (remaining <= 0) {
            elements.paymentExpiry.textContent = '00:00';
            return;
        }

        const minutes = Math.floor(remaining / 60000);
        const seconds = Math.floor((remaining % 60000) / 1000);
        elements.paymentExpiry.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    };

    updateTimer();
    const timerInterval = setInterval(updateTimer, 1000);

    // Limpar quando fechar modal
    elements.paymentModal.dataset.timerInterval = timerInterval;
}

function startPaymentCheck(paymentId) {
    if (paymentCheckInterval) {
        clearInterval(paymentCheckInterval);
    }

    // Guardar o ID do pagamento atual para verificação
    const currentPaymentId = paymentId;
    let checkCount = 0;
    const maxChecks = 120; // 120 x 3s = 6 minutos máximo

    paymentCheckInterval = setInterval(async () => {
        checkCount++;

        // Verificar se ainda estamos no mesmo pagamento
        if (!document.getElementById('paymentModal')?.classList.contains('active')) {
            clearInterval(paymentCheckInterval);
            return;
        }

        try {
            const response = await fetch(`${API_URL}/payments/status/${currentPaymentId}`, {
                headers: { 'Authorization': `Bearer ${authToken}` }
            });

            if (!response.ok) {
                console.error('Payment status check failed:', response.status);
                return;
            }

            const data = await response.json();

            // Verificar se o payment_id retornado é o mesmo que estamos monitorando
            if (data.payment_id !== currentPaymentId) {
                console.warn('Payment ID mismatch, ignoring response');
                return;
            }

            if (data.status === 'approved') {
                clearInterval(paymentCheckInterval);
                paymentApproved(data);
            } else if (data.status === 'expired' || data.status === 'cancelled') {
                clearInterval(paymentCheckInterval);
                showToast('Pagamento expirado ou cancelado', 'error');
                closeModal('paymentModal');
            }

            // Timeout após maxChecks
            if (checkCount >= maxChecks) {
                clearInterval(paymentCheckInterval);
                showToast('Tempo limite excedido. Tente novamente.', 'error');
                closeModal('paymentModal');
            }
        } catch (error) {
            console.error('Payment check error:', error);
        }
    }, 3000); // Check a cada 3 segundos
}

function paymentApproved(paymentData) {
    closeModal('paymentModal');

    // Salvar informação da sessão ativa no localStorage
    const sessionInfo = {
        plan_name: paymentData.plan_name,
        remaining_formatted: paymentData.remaining_formatted,
        approved_at: new Date().toISOString()
    };
    localStorage.setItem('activeSession', JSON.stringify(sessionInfo));

    // Mostrar modal de sucesso
    elements.sessionPlan.textContent = paymentData.plan_name || 'Plano';
    elements.sessionTime.textContent = paymentData.remaining_formatted || '-';

    showModal('successModal');

    // Aguardar criação da sessão e verificar status
    showToast('Pagamento aprovado! Aguardando liberação...', 'success');

    // Verificar periodicamente se a sessão foi criada (webhook pode demorar alguns segundos)
    let checkAttempts = 0;
    const maxAttempts = 30; // 30 tentativas x 2 segundos = 60 segundos
    let sessionConfirmed = false;

    const sessionCheckInterval = setInterval(async () => {
        checkAttempts++;

        // Atualizar mensagem de status
        elements.paymentStatus.innerHTML = `
            <div class="status-icon pending">
                <i class="fas fa-spinner fa-spin"></i>
            </div>
            <p>Verificando sessão... (${checkAttempts}/${maxAttempts})</p>
        `;

        try {
            // Verificar se há sessão ativa
            const response = await fetch(`${API_URL}/sessions/my`, {
                headers: { 'Authorization': `Bearer ${authToken}` }
            });

            if (response.ok) {
                const data = await response.json();

                if (data.session && data.session.status === 'active') {
                    clearInterval(sessionCheckInterval);
                    sessionConfirmed = true;

                    // Atualizar status e UI
                    await checkAuthStatus();

                    // Mostrar sucesso
                    showToast('Internet liberada! Redirecionando...', 'success');

                    // Redirecionar após 5 segundos
                    let countdown = 5;
                    const redirectInterval = setInterval(() => {
                        countdown--;
                        if (countdown <= 0) {
                            clearInterval(redirectInterval);
                            closeModal('successModal');
                            window.location.href = REDIRECT_URL;
                        } else {
                            showToast(`Redirecionando em ${countdown}s...`, 'info');
                        }
                    }, 1000);
                }
            }
        } catch (error) {
            console.error('Session check error:', error);
        }

        // Se exceder tentativas SEM sessão confirmada, NÃO redirecionar automaticamente
        if (checkAttempts >= maxAttempts && !sessionConfirmed) {
            clearInterval(sessionCheckInterval);
            showToast('Sessão ainda não confirmada. Clique no botão para tentar navegar.', 'warning');

            // Atualizar botão do modal
            const closeBtn = document.getElementById('closeSuccessModal');
            if (closeBtn) {
                closeBtn.innerHTML = '<span>Tentar Navegar</span> <i class="fas fa-globe"></i>';
            }
        }
    }, 2000); // Verifica a cada 2 segundos
}

// ===== MODAIS =====
function initModals() {
    // Fechar payment modal
    document.getElementById('closePaymentModal')?.addEventListener('click', () => {
        closeModal('paymentModal');
    });

    // Fechar success modal e redirecionar
    document.getElementById('closeSuccessModal')?.addEventListener('click', () => {
        closeModal('successModal');
        // Redirecionar para o Google para fechar o captive portal
        window.location.href = REDIRECT_URL;
    });

    // Fechar ao clicar fora
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal(modal.id);
            }
        });
    });
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add('active');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');

        // Limpar timer se existir
        if (modal.dataset.timerInterval) {
            clearInterval(modal.dataset.timerInterval);
        }
    }

    // Limpar interval de verificação de pagamento
    if (modalId === 'paymentModal' && paymentCheckInterval) {
        clearInterval(paymentCheckInterval);
    }
}

// ===== CONTROLE DE VISIBILIDADE DAS ABAS =====
function updateTabsVisibility() {
    const loginTab = document.querySelector('[data-tab="login"]');
    const registerTab = document.querySelector('[data-tab="register"]');
    const plansTab = document.querySelector('[data-tab="plans"]');

    if (authToken && currentUser) {
        // Usuário logado: esconder login e cadastro
        if (loginTab) loginTab.style.display = 'none';
        if (registerTab) registerTab.style.display = 'none';
        if (plansTab) plansTab.style.display = 'inline-block';
    } else {
        // Usuário não logado: mostrar todas as abas
        if (loginTab) loginTab.style.display = 'inline-block';
        if (registerTab) registerTab.style.display = 'inline-block';
        if (plansTab) plansTab.style.display = 'inline-block';
    }
}

// ===== AUTENTICAÇÃO =====
async function checkAuthStatus() {
    if (!authToken) {
        elements.activeSessionPanel.classList.add('hidden');
        updateTabsVisibility();
        return;
    }

    try {
        const response = await fetch(`${API_URL}/auth/me`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (!response.ok) {
            throw new Error('Token inválido');
        }

        const data = await response.json();
        currentUser = data.user;

        // Salvar usuário no localStorage para persistência
        localStorage.setItem('currentUser', JSON.stringify(currentUser));

        // Atualizar visibilidade das abas (esconder login/registro)
        updateTabsVisibility();

        // Verificar sessão ativa
        if (data.activeSession) {
            showActiveSession(data.user, data.activeSession);

            // Ir para a aba de planos (o painel de sessão ativa será visível)
            switchTab('plans');
        } else {
            elements.activeSessionPanel.classList.add('hidden');

            // Mostrar grid de planos e header
            const plansGrid = document.getElementById('plansGrid');
            const plansHeader = document.querySelector('.plans-header');
            if (plansGrid) plansGrid.style.display = 'grid';
            if (plansHeader) plansHeader.style.display = 'block';

            if (currentUser) {
                switchTab('plans');
            }
        }

    } catch (error) {
        console.error('Auth check error:', error);
        authToken = null;
        currentUser = null;
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
        elements.activeSessionPanel.classList.add('hidden');
        updateTabsVisibility();
    }
}

function showActiveSession(user, session) {
    elements.activeSessionPanel.classList.remove('hidden');
    elements.sessionUserName.textContent = user.name;
    elements.sessionPlanName.textContent = session.plan_name;

    // Esconder grid de planos e header dentro da tab
    const plansGrid = document.getElementById('plansGrid');
    const plansHeader = document.querySelector('.plans-header');
    if (plansGrid) plansGrid.style.display = 'none';
    if (plansHeader) plansHeader.style.display = 'none';

    updateSessionTimer(session);

    // Atualizar a cada minuto
    if (sessionCheckInterval) clearInterval(sessionCheckInterval);
    sessionCheckInterval = setInterval(() => {
        checkAuthStatus();
    }, 60000);
}

function updateSessionTimer(session) {
    const remaining = session.remaining_minutes;
    const hours = Math.floor(remaining / 60);
    const minutes = remaining % 60;

    let timeText = '';
    if (hours > 0) {
        timeText = `${hours}h ${minutes}min`;
    } else {
        timeText = `${minutes} minutos`;
    }

    elements.sessionTimeRemaining.textContent = timeText;

    // Progress bar (assumindo plano máximo de 7 dias = 10080 min)
    const totalMinutes = 10080; // Ajustar conforme necessário
    const progress = Math.min(100, (remaining / totalMinutes) * 100);
    elements.sessionProgressBar.style.width = `${progress}%`;
}

// ===== UTILITÁRIOS =====
function validateCPF(cpf) {
    cpf = cpf.replace(/\D/g, '');

    if (cpf.length !== 11) return false;
    if (/^(\d)\1+$/.test(cpf)) return false;

    let sum = 0;
    for (let i = 0; i < 9; i++) {
        sum += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let digit = 11 - (sum % 11);
    if (digit >= 10) digit = 0;
    if (digit !== parseInt(cpf.charAt(9))) return false;

    sum = 0;
    for (let i = 0; i < 10; i++) {
        sum += parseInt(cpf.charAt(i)) * (11 - i);
    }
    digit = 11 - (sum % 11);
    if (digit >= 10) digit = 0;
    if (digit !== parseInt(cpf.charAt(10))) return false;

    return true;
}

function getMacAddress() {
    // Em ambiente real, isso viria do MikroTik via redirect
    // Por ora, retornamos um valor do localStorage ou null
    return localStorage.getItem('deviceMac') || null;
}

function initCPFMask() {
    document.querySelectorAll('input[name="cpf"]').forEach(input => {
        input.addEventListener('input', (e) => {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 11) value = value.slice(0, 11);

            if (value.length > 9) {
                value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, '$1.$2.$3-$4');
            } else if (value.length > 6) {
                value = value.replace(/(\d{3})(\d{3})(\d{1,3})/, '$1.$2.$3');
            } else if (value.length > 3) {
                value = value.replace(/(\d{3})(\d{1,3})/, '$1.$2');
            }

            e.target.value = value;
        });
    });
}

function initPhoneMask() {
    document.querySelectorAll('input[name="phone"]').forEach(input => {
        input.addEventListener('input', (e) => {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 11) value = value.slice(0, 11);

            if (value.length > 10) {
                value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
            } else if (value.length > 6) {
                value = value.replace(/(\d{2})(\d{4,5})(\d{0,4})/, '($1) $2-$3');
            } else if (value.length > 2) {
                value = value.replace(/(\d{2})(\d{0,5})/, '($1) $2');
            }

            e.target.value = value;
        });
    });
}

function initPasswordToggle() {
    document.querySelectorAll('.toggle-password').forEach(btn => {
        btn.addEventListener('click', () => {
            const input = btn.previousElementSibling;
            const icon = btn.querySelector('i');

            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });
    });
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };

    toast.innerHTML = `
        <i class="fas ${icons[type] || icons.info}"></i>
        <span>${message}</span>
    `;

    elements.toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'toastSlideIn 0.3s ease reverse';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// ===== EXPORTAR FUNÇÕES GLOBAIS =====
window.loadPlans = loadPlans;
