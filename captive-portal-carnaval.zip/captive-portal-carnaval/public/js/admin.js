/**
 * ADMIN DASHBOARD - CARNAVAL DE RECIFE
 */

const API_URL = '/api';
let adminToken = localStorage.getItem('adminToken');
let adminUser = JSON.parse(localStorage.getItem('adminUser') || '{}');

// Verificar autenticação
if (!adminToken) {
    window.location.href = '/admin-login';
}

// Elementos DOM
const elements = {
    pageTitle: document.getElementById('pageTitle'),
    adminName: document.getElementById('adminName'),
    toastContainer: document.getElementById('toastContainer'),

    // Stats
    totalUsers: document.getElementById('totalUsers'),
    activeSessions: document.getElementById('activeSessions'),
    todayRevenue: document.getElementById('todayRevenue'),
    totalRevenue: document.getElementById('totalRevenue'),

    // Tables
    recentUsersTable: document.getElementById('recentUsersTable'),
    activeSessionsList: document.getElementById('activeSessionsList'),
    usersTable: document.getElementById('usersTable'),
    sessionsTable: document.getElementById('sessionsTable'),
    revenueTable: document.getElementById('revenueTable'),
    logsTable: document.getElementById('logsTable'),

    // Revenue
    reportTotalRevenue: document.getElementById('reportTotalRevenue'),
    reportTransactions: document.getElementById('reportTransactions'),
    reportAvgTicket: document.getElementById('reportAvgTicket')
};

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    elements.adminName.textContent = adminUser.name || 'Administrador';

    initNavigation();
    initLogout();
    initMenuToggle();

    loadDashboard();
});

// Navegação
function initNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.dataset.section;
            switchSection(section);
        });
    });
}

function switchSection(sectionId) {
    // Atualizar nav
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelector(`[data-section="${sectionId}"]`)?.classList.add('active');

    // Atualizar sections
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.getElementById(sectionId)?.classList.add('active');

    // Atualizar título
    const titles = {
        dashboard: 'Dashboard',
        users: 'Usuários',
        sessions: 'Sessões',
        payments: 'Pagamentos',
        logs: 'Logs'
    };
    elements.pageTitle.textContent = titles[sectionId] || 'Dashboard';

    // Carregar dados da seção
    switch(sectionId) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'users':
            loadUsers();
            break;
        case 'sessions':
            loadSessions();
            break;
        case 'payments':
            loadRevenueReport();
            break;
        case 'logs':
            loadLogs();
            break;
    }
}

// Menu toggle mobile
function initMenuToggle() {
    const toggle = document.getElementById('menuToggle');
    const sidebar = document.querySelector('.sidebar');

    toggle?.addEventListener('click', () => {
        sidebar.classList.toggle('active');
    });
}

// Logout
function initLogout() {
    document.getElementById('logoutBtn')?.addEventListener('click', async () => {
        try {
            await fetch(`${API_URL}/auth/logout`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${adminToken}` }
            });
        } catch (e) {}

        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminUser');
        window.location.href = '/admin-login';
    });
}

// API Request helper
async function apiRequest(endpoint, options = {}) {
    const response = await fetch(`${API_URL}${endpoint}`, {
        ...options,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${adminToken}`,
            ...options.headers
        }
    });

    if (response.status === 401) {
        localStorage.removeItem('adminToken');
        window.location.href = '/admin-login';
        return;
    }

    return response.json();
}

// Dashboard
async function loadDashboard() {
    try {
        const data = await apiRequest('/admin/dashboard');

        elements.totalUsers.textContent = data.stats.totalUsers;
        elements.activeSessions.textContent = data.stats.activeSessions;
        elements.todayRevenue.textContent = data.stats.todayRevenueFormatted;
        elements.totalRevenue.textContent = data.stats.totalRevenueFormatted;

        // Recent users
        if (data.recentUsers.length > 0) {
            elements.recentUsersTable.innerHTML = data.recentUsers.map(user => `
                <tr>
                    <td>${user.name}</td>
                    <td>${user.cpf}</td>
                    <td>${formatDate(user.created_at)}</td>
                </tr>
            `).join('');
        } else {
            elements.recentUsersTable.innerHTML = '<tr><td colspan="3">Nenhum usuário recente</td></tr>';
        }

        // Load active sessions for dashboard
        loadDashboardSessions();

    } catch (error) {
        showToast('Erro ao carregar dashboard', 'error');
    }
}

async function loadDashboardSessions() {
    try {
        const data = await apiRequest('/sessions/active?limit=5');

        if (data.sessions && data.sessions.length > 0) {
            elements.activeSessionsList.innerHTML = data.sessions.map(session => `
                <div class="session-item">
                    <div class="session-info">
                        <h4>${session.user_name}</h4>
                        <p>${session.mac_address}</p>
                    </div>
                    <div class="session-time">
                        <span class="time">${session.remaining_formatted}</span>
                        <span class="plan">${session.plan_name}</span>
                    </div>
                </div>
            `).join('');
        } else {
            elements.activeSessionsList.innerHTML = '<p class="text-muted">Nenhuma sessão ativa</p>';
        }
    } catch (error) {
        elements.activeSessionsList.innerHTML = '<p class="text-muted">Erro ao carregar</p>';
    }
}

// Users
let usersPage = 1;

async function loadUsers(page = 1) {
    usersPage = page;
    const search = document.getElementById('userSearch')?.value || '';

    try {
        const data = await apiRequest(`/admin/users?page=${page}&limit=20&search=${encodeURIComponent(search)}`);

        if (data.users.length > 0) {
            elements.usersTable.innerHTML = data.users.map(user => `
                <tr>
                    <td>${user.id}</td>
                    <td>${user.name}</td>
                    <td>${user.cpf}</td>
                    <td><span class="badge badge-${user.status}">${user.status}</span></td>
                    <td>${formatDate(user.created_at)}</td>
                    <td>
                        <button class="btn btn-sm btn-secondary" onclick="viewUser(${user.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        ${user.status === 'active' ?
                            `<button class="btn btn-sm btn-danger" onclick="blockUser(${user.id})">
                                <i class="fas fa-ban"></i>
                            </button>` :
                            `<button class="btn btn-sm btn-primary" onclick="unblockUser(${user.id})">
                                <i class="fas fa-check"></i>
                            </button>`
                        }
                    </td>
                </tr>
            `).join('');

            renderPagination('usersPagination', data.pagination, loadUsers);
        } else {
            elements.usersTable.innerHTML = '<tr><td colspan="6">Nenhum usuário encontrado</td></tr>';
        }
    } catch (error) {
        showToast('Erro ao carregar usuários', 'error');
    }
}

function searchUsers() {
    loadUsers(1);
}

async function viewUser(userId) {
    try {
        const data = await apiRequest(`/admin/users/${userId}`);

        // Montar informações do usuário
        let details = `
=== INFORMAÇÕES DO USUÁRIO ===

Nome: ${data.user.name}
CPF: ${data.user.cpf}
Email: ${data.user.email || 'Não informado'}
Telefone: ${data.user.phone || 'Não informado'}
Status: ${data.user.status}
Cadastro: ${formatDateTime(data.user.created_at)}
Último Login: ${data.user.last_login ? formatDateTime(data.user.last_login) : 'Nunca'}
`;

        if (data.activeSession) {
            details += `
=== SESSÃO ATIVA ===

Plano: ${data.activeSession.plan_name}
MAC: ${data.activeSession.mac_address}
IP: ${data.activeSession.ip_address}
Início: ${formatDateTime(data.activeSession.start_time)}
Término: ${formatDateTime(data.activeSession.expected_end_time)}
`;
        }

        if (data.payments && data.payments.length > 0) {
            details += `
=== ÚLTIMOS PAGAMENTOS ===

`;
            data.payments.slice(0, 5).forEach(p => {
                details += `${formatDateTime(p.created_at)} - ${p.plan_name} - R$ ${(p.amount_cents / 100).toFixed(2)} - ${p.status}\n`;
            });
        }

        if (data.devices && data.devices.length > 0) {
            details += `
=== DISPOSITIVOS ===

`;
            data.devices.forEach(d => {
                details += `MAC: ${d.mac_address} - Último acesso: ${formatDateTime(d.last_seen)}\n`;
            });
        }

        alert(details);
    } catch (error) {
        showToast('Erro ao buscar usuário', 'error');
    }
}

async function blockUser(userId) {
    if (!confirm('Deseja bloquear este usuário?')) return;

    try {
        await apiRequest(`/admin/users/${userId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status: 'blocked' })
        });
        showToast('Usuário bloqueado', 'success');
        loadUsers(usersPage);
    } catch (error) {
        showToast('Erro ao bloquear usuário', 'error');
    }
}

async function unblockUser(userId) {
    try {
        await apiRequest(`/admin/users/${userId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status: 'active' })
        });
        showToast('Usuário desbloqueado', 'success');
        loadUsers(usersPage);
    } catch (error) {
        showToast('Erro ao desbloquear usuário', 'error');
    }
}

// Sessions
async function loadSessions() {
    try {
        const data = await apiRequest('/sessions/active');

        if (data.sessions && data.sessions.length > 0) {
            elements.sessionsTable.innerHTML = data.sessions.map(session => `
                <tr>
                    <td>${session.user_name}</td>
                    <td>${session.plan_name}</td>
                    <td><code>${session.mac_address}</code></td>
                    <td>${session.ip_address}</td>
                    <td><strong style="color: #2ECC71">${session.remaining_formatted}</strong></td>
                    <td>
                        <button class="btn btn-sm btn-danger" onclick="disconnectSession(${session.id})">
                            <i class="fas fa-power-off"></i> Desconectar
                        </button>
                    </td>
                </tr>
            `).join('');
        } else {
            elements.sessionsTable.innerHTML = '<tr><td colspan="6">Nenhuma sessão ativa</td></tr>';
        }
    } catch (error) {
        showToast('Erro ao carregar sessões', 'error');
    }
}

function refreshSessions() {
    loadSessions();
    showToast('Sessões atualizadas', 'info');
}

async function disconnectSession(sessionId) {
    if (!confirm('Deseja desconectar esta sessão?')) return;

    try {
        await apiRequest(`/sessions/${sessionId}/disconnect`, {
            method: 'POST',
            body: JSON.stringify({ reason: 'admin_action' })
        });
        showToast('Sessão desconectada', 'success');
        loadSessions();
    } catch (error) {
        showToast('Erro ao desconectar sessão', 'error');
    }
}

// Revenue
async function loadRevenueReport() {
    const period = document.getElementById('revenuePeriod')?.value || 'month';

    try {
        const data = await apiRequest(`/admin/reports/revenue?period=${period}`);

        elements.reportTotalRevenue.textContent = data.summary.totalRevenueFormatted;
        elements.reportTransactions.textContent = data.summary.totalTransactions;
        elements.reportAvgTicket.textContent = data.summary.avgTicketFormatted;

        if (data.daily.length > 0) {
            elements.revenueTable.innerHTML = data.daily.map(day => `
                <tr>
                    <td>${formatDate(day.date)}</td>
                    <td>${day.transactions}</td>
                    <td><strong>${day.revenueFormatted}</strong></td>
                </tr>
            `).join('');
        } else {
            elements.revenueTable.innerHTML = '<tr><td colspan="3">Nenhum dado disponível</td></tr>';
        }
    } catch (error) {
        showToast('Erro ao carregar relatório', 'error');
    }
}

// Logs
let logsPage = 1;

async function loadLogs(page = 1) {
    logsPage = page;
    const startDate = document.getElementById('logStartDate')?.value || '';
    const endDate = document.getElementById('logEndDate')?.value || '';

    // Aumentado de 50 para 500 logs por página
    let url = `/admin/logs?page=${page}&limit=500`;
    if (startDate) url += `&start_date=${startDate}`;
    if (endDate) url += `&end_date=${endDate}`;

    try {
        const data = await apiRequest(url);

        if (data.logs.length > 0) {
            elements.logsTable.innerHTML = data.logs.map(log => `
                <tr>
                    <td>${formatDateTime(log.timestamp)}</td>
                    <td>${log.user_name || log.cpf || '-'}</td>
                    <td><code>${log.mac_address}</code></td>
                    <td>${log.ip_address}</td>
                    <td><span class="badge badge-${getLogBadge(log.action)}">${log.action}</span></td>
                </tr>
            `).join('');

            renderPagination('logsPagination', data.pagination, loadLogs);
        } else {
            elements.logsTable.innerHTML = '<tr><td colspan="5">Nenhum log encontrado</td></tr>';
        }
    } catch (error) {
        showToast('Erro ao carregar logs', 'error');
    }
}

// Exportar todos os logs em CSV
async function exportAllLogs() {
    const startDate = document.getElementById('logStartDate')?.value || '';
    const endDate = document.getElementById('logEndDate')?.value || '';

    let url = `/admin/logs?page=1&limit=999999`; // Sem limite prático
    if (startDate) url += `&start_date=${startDate}`;
    if (endDate) url += `&end_date=${endDate}`;

    try {
        showToast('Exportando logs...', 'info');
        const data = await apiRequest(url);

        if (data.logs.length === 0) {
            showToast('Nenhum log para exportar', 'warning');
            return;
        }

        // Gerar CSV
        const csvHeader = 'Data/Hora,Usuário,CPF,MAC Address,IP Address,Ação\n';
        const csvRows = data.logs.map(log => {
            const timestamp = new Date(log.timestamp).toLocaleString('pt-BR');
            const userName = (log.user_name || '').replace(/,/g, ';');
            const cpf = (log.cpf || '').replace(/,/g, '');
            const mac = log.mac_address;
            const ip = log.ip_address;
            const action = log.action;
            return `"${timestamp}","${userName}","${cpf}","${mac}","${ip}","${action}"`;
        }).join('\n');

        const csv = csvHeader + csvRows;

        // Download do CSV
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url_blob = URL.createObjectURL(blob);
        link.setAttribute('href', url_blob);
        link.setAttribute('download', `logs_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        showToast(`${data.logs.length} logs exportados com sucesso!`, 'success');
    } catch (error) {
        showToast('Erro ao exportar logs', 'error');
    }
}

function getLogBadge(action) {
    if (action.includes('STARTED') || action.includes('SUCCESS') || action.includes('GRANTED')) return 'active';
    if (action.includes('FAILED') || action.includes('DENIED') || action.includes('EXPIRED')) return 'blocked';
    return 'pending';
}

// Pagination
function renderPagination(containerId, pagination, callback) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const { page, totalPages } = pagination;

    let html = '';

    html += `<button ${page <= 1 ? 'disabled' : ''} onclick="${callback.name}(${page - 1})">
        <i class="fas fa-chevron-left"></i>
    </button>`;

    for (let i = 1; i <= totalPages; i++) {
        if (i === 1 || i === totalPages || (i >= page - 2 && i <= page + 2)) {
            html += `<button class="${i === page ? 'active' : ''}" onclick="${callback.name}(${i})">${i}</button>`;
        } else if (i === page - 3 || i === page + 3) {
            html += '<button disabled>...</button>';
        }
    }

    html += `<button ${page >= totalPages ? 'disabled' : ''} onclick="${callback.name}(${page + 1})">
        <i class="fas fa-chevron-right"></i>
    </button>`;

    container.innerHTML = html;
}

// Utilities
function formatDate(dateStr) {
    if (!dateStr) return '-';
    return new Date(dateStr).toLocaleDateString('pt-BR');
}

function formatDateTime(dateStr) {
    if (!dateStr) return '-';
    return new Date(dateStr).toLocaleString('pt-BR');
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };

    toast.innerHTML = `
        <i class="fas ${icons[type] || icons.info}"></i>
        <span>${message}</span>
    `;

    elements.toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 4000);
}

// Exportar para global
window.loadUsers = loadUsers;
window.searchUsers = searchUsers;
window.viewUser = viewUser;
window.blockUser = blockUser;
window.unblockUser = unblockUser;
window.refreshSessions = refreshSessions;
window.disconnectSession = disconnectSession;
window.loadRevenueReport = loadRevenueReport;
window.loadLogs = loadLogs;
window.exportAllLogs = exportAllLogs;
