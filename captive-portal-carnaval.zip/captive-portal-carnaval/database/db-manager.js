/**
 * Database Manager - PostgreSQL
 * Gerenciamento de conexões e operações do banco de dados
 */

const { Pool } = require('pg');
const pino = require('pino');
const bcrypt = require('bcryptjs');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

let pool = null;

/**
 * Configuração do pool de conexões
 */
const poolConfig = {
    connectionString: process.env.DATABASE_URL,
    max: 100,                    // Máximo de conexões no pool
    min: 10,                     // Mínimo de conexões
    idleTimeoutMillis: 30000,    // Tempo máximo de conexão ociosa
    connectionTimeoutMillis: 10000, // Timeout de conexão
    ssl: process.env.NODE_ENV === 'production' && process.env.DB_SSL === 'true'
        ? { rejectUnauthorized: false }
        : false
};

/**
 * Inicializar banco de dados
 */
async function initDatabase() {
    try {
        pool = new Pool(poolConfig);

        // Testar conexão
        const client = await pool.connect();
        logger.info('Conexão com PostgreSQL estabelecida');
        client.release();

        // Criar schema
        await createSchema();

        // Criar admin padrão
        await seedAdmin();

        // Criar planos padrão
        await seedPlans();

        return pool;
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao conectar ao PostgreSQL');
        throw error;
    }
}

/**
 * Obter pool de conexões
 */
function getPool() {
    if (!pool) {
        throw new Error('Database não inicializado. Chame initDatabase() primeiro.');
    }
    return pool;
}

/**
 * Executar query com retry
 */
async function query(text, params, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const result = await pool.query(text, params);
            return result;
        } catch (error) {
            if (i === retries - 1) throw error;
            logger.warn(`Query falhou, tentativa ${i + 1}/${retries}`);
            await new Promise(r => setTimeout(r, 1000 * (i + 1)));
        }
    }
}

/**
 * Criar schema do banco de dados
 */
async function createSchema() {
    const schema = `
        -- Tabela de usuários
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            cpf VARCHAR(11) NOT NULL UNIQUE,
            email VARCHAR(255),
            phone VARCHAR(20),
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(20) DEFAULT 'user' CHECK (role IN ('user', 'admin', 'manager')),
            active_mac_address VARCHAR(17),
            active_session_id INTEGER,
            status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'blocked', 'suspended')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Tabela de planos
        CREATE TABLE IF NOT EXISTS plans (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            duration_minutes INTEGER NOT NULL,
            price_cents INTEGER NOT NULL,
            description TEXT,
            speed_limit VARCHAR(20),
            active BOOLEAN DEFAULT true,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Tabela de sessões
        CREATE TABLE IF NOT EXISTS sessions (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            mac_address VARCHAR(17) NOT NULL,
            ip_address VARCHAR(45) NOT NULL,
            plan_id INTEGER NOT NULL REFERENCES plans(id),
            start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            end_time TIMESTAMP,
            expected_end_time TIMESTAMP NOT NULL,
            status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'expired', 'disconnected', 'cancelled')),
            mikrotik_synced BOOLEAN DEFAULT false,
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Tabela de pagamentos
        CREATE TABLE IF NOT EXISTS payments (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            plan_id INTEGER NOT NULL REFERENCES plans(id),
            session_id INTEGER REFERENCES sessions(id),
            amount_cents INTEGER NOT NULL,
            payment_method VARCHAR(20) DEFAULT 'pix',
            payment_gateway VARCHAR(30) DEFAULT 'abacatepay',
            payment_id VARCHAR(255) UNIQUE,
            qr_code TEXT,
            qr_code_base64 TEXT,
            pix_copia_cola TEXT,
            status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'cancelled', 'expired', 'refunded')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            paid_at TIMESTAMP,
            expires_at TIMESTAMP,
            gateway_fee_cents INTEGER DEFAULT 0,
            raw_response TEXT
        );

        -- Tabela de dispositivos
        CREATE TABLE IF NOT EXISTS devices (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            mac_address VARCHAR(17) NOT NULL,
            device_name VARCHAR(100),
            first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, mac_address)
        );

        -- Tabela de logs de conexão (Marco Civil)
        CREATE TABLE IF NOT EXISTS connection_logs (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL,
            session_id INTEGER,
            mac_address VARCHAR(17) NOT NULL,
            ip_address VARCHAR(45) NOT NULL,
            action VARCHAR(50) NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            details JSONB,
            cpf VARCHAR(11)
        );

        -- Tabela de logs de segurança
        CREATE TABLE IF NOT EXISTS security_logs (
            id SERIAL PRIMARY KEY,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            event VARCHAR(100) NOT NULL,
            ip VARCHAR(45),
            user_agent TEXT,
            user_id INTEGER,
            method VARCHAR(10),
            path VARCHAR(255),
            details JSONB,
            severity VARCHAR(20) DEFAULT 'INFO' CHECK (severity IN ('DEBUG', 'INFO', 'WARN', 'ERROR', 'CRITICAL'))
        );

        -- Índices para performance
        CREATE INDEX IF NOT EXISTS idx_users_cpf ON users(cpf);
        CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
        CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
        CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);

        CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
        CREATE INDEX IF NOT EXISTS idx_sessions_status ON sessions(status);
        CREATE INDEX IF NOT EXISTS idx_sessions_expected_end ON sessions(expected_end_time);
        CREATE INDEX IF NOT EXISTS idx_sessions_mac ON sessions(mac_address);
        CREATE INDEX IF NOT EXISTS idx_sessions_status_end ON sessions(status, expected_end_time);

        CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments(user_id);
        CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
        CREATE INDEX IF NOT EXISTS idx_payments_payment_id ON payments(payment_id);

        CREATE INDEX IF NOT EXISTS idx_connection_logs_user_id ON connection_logs(user_id);
        CREATE INDEX IF NOT EXISTS idx_connection_logs_timestamp ON connection_logs(timestamp);
        CREATE INDEX IF NOT EXISTS idx_connection_logs_mac ON connection_logs(mac_address);

        CREATE INDEX IF NOT EXISTS idx_security_logs_timestamp ON security_logs(timestamp);
        CREATE INDEX IF NOT EXISTS idx_security_logs_event ON security_logs(event);
        CREATE INDEX IF NOT EXISTS idx_security_logs_severity ON security_logs(severity);

        CREATE INDEX IF NOT EXISTS idx_devices_user_id ON devices(user_id);
        CREATE INDEX IF NOT EXISTS idx_devices_mac ON devices(mac_address);
    `;

    try {
        await pool.query(schema);
        logger.info('Schema do banco de dados criado/verificado');
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao criar schema');
        throw error;
    }
}

/**
 * Criar admin padrão
 */
async function seedAdmin() {
    try {
        const adminCpf = process.env.ADMIN_CPF || '11111111111';
        const adminPassword = process.env.ADMIN_PASSWORD || 'Admin@Carnaval2026!';
        const adminName = process.env.ADMIN_NAME || 'Administrador';
        const adminEmail = process.env.ADMIN_EMAIL || 'admin@captive.local';

        // Verificar se admin já existe
        const existing = await pool.query('SELECT id FROM users WHERE cpf = $1', [adminCpf]);

        if (existing.rows.length === 0) {
            const passwordHash = await bcrypt.hash(adminPassword, 10);

            await pool.query(`
                INSERT INTO users (name, cpf, email, password_hash, role, status)
                VALUES ($1, $2, $3, $4, 'admin', 'active')
            `, [adminName, adminCpf, adminEmail, passwordHash]);

            logger.info(`Admin criado com CPF: ${adminCpf}`);
        } else {
            logger.info('Admin já existe no banco');
        }
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao criar admin');
    }
}

/**
 * Criar planos padrão
 */
async function seedPlans() {
    try {
        const existingPlans = await pool.query('SELECT id FROM plans LIMIT 1');

        if (existingPlans.rows.length === 0) {
            const plans = [
                { name: '1 Hora', duration: 60, price: 500, desc: 'Acesso básico por 1 hora', speed: '10Mbps' },
                { name: '3 Horas', duration: 180, price: 1000, desc: 'Acesso padrão por 3 horas', speed: '15Mbps' },
                { name: '24 Horas', duration: 1440, price: 2000, desc: 'Acesso diário completo', speed: '20Mbps' },
                { name: '7 Dias', duration: 10080, price: 5000, desc: 'Acesso semanal ilimitado', speed: '25Mbps' }
            ];

            for (const plan of plans) {
                await pool.query(`
                    INSERT INTO plans (name, duration_minutes, price_cents, description, speed_limit, active)
                    VALUES ($1, $2, $3, $4, $5, true)
                `, [plan.name, plan.duration, plan.price, plan.desc, plan.speed]);
            }

            logger.info('Planos padrão criados');
        } else {
            logger.info('Planos já existem no banco');
        }
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao criar planos');
    }
}

/**
 * Log de segurança
 */
async function logSecurityEvent(event, data) {
    try {
        await pool.query(`
            INSERT INTO security_logs (event, ip, user_agent, user_id, method, path, details, severity)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        `, [
            event,
            data.ip || null,
            data.userAgent || null,
            data.userId || null,
            data.method || null,
            data.path || null,
            JSON.stringify(data.details || {}),
            data.severity || 'INFO'
        ]);
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao registrar log de segurança');
    }
}

/**
 * Log de conexão (Marco Civil)
 */
async function logConnection(data) {
    try {
        await pool.query(`
            INSERT INTO connection_logs (user_id, session_id, mac_address, ip_address, action, details, cpf)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
        `, [
            data.userId,
            data.sessionId || null,
            data.macAddress,
            data.ipAddress,
            data.action,
            JSON.stringify(data.details || {}),
            data.cpf || null
        ]);
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao registrar log de conexão');
    }
}

module.exports = {
    initDatabase,
    getPool,
    query,
    logSecurityEvent,
    logConnection
};
