# 🎭 Captive Portal Carnaval de Recife

Sistema de Captive Portal para gestão e monetização de acesso Wi-Fi com tema do **Carnaval de Recife**.

## 📋 Características

- **Tema Visual**: Design inspirado no Carnaval de Recife (Frevo, Maracatu, Bonecos de Olinda)
- **Monetização**: Pagamentos via Pix através do AbacatePay
- **Escalabilidade**: Suporte para 4000+ usuários simultâneos
- **Integração MikroTik**: Controle de acesso via RouterOS API
- **Conformidade Legal**: Logs de conexão conforme Marco Civil da Internet
- **Deploy Docker**: Configuração completa para deploy em Ubuntu

## 🚀 Deploy Rápido

### Pré-requisitos
- Ubuntu 20.04+ ou Debian 11+
- 2GB+ RAM
- 20GB+ disco
- Acesso root

### Instalação

```bash
# Clone ou copie o projeto para o servidor
cd /opt
git clone [seu-repositorio] captive-portal-carnaval
cd captive-portal-carnaval

# Execute o script de deploy
chmod +x scripts/deploy.sh
sudo ./scripts/deploy.sh
```

O script irá:
1. Instalar Docker e Docker Compose
2. Gerar certificados SSL auto-assinados
3. Criar arquivo `.env` (você deverá editar)
4. Construir e iniciar os containers
5. Configurar firewall

### Configuração Pós-Deploy

1. **Edite o arquivo `.env`**:
   ```bash
   nano .env
   ```
   Configure especialmente:
   - `PUBLIC_URL`: URL pública do seu servidor
   - `ABACATEPAY_API_KEY`: Sua chave de API
   - `ROUTER_IP` e `ROUTER_PASSWORD`: Credenciais do MikroTik

2. **Configure o MikroTik**:
   - Acesse o MikroTik via Winbox/SSH
   - Execute o script em `scripts/mikrotik-setup.rsc`

3. **Configure o Webhook no AbacatePay**:
   - URL: `https://SEU_IP:443/api/webhooks/abacatepay`

## 📁 Estrutura do Projeto

```
captive-portal-carnaval/
├── server.js              # Servidor principal Express.js
├── package.json           # Dependências Node.js
├── Dockerfile             # Build da aplicação
├── docker-compose.yml     # Orquestração dos serviços
├── .env                   # Configurações (não versionado)
├── config/                # Configurações adicionais
├── database/              # Schema e gerenciamento do banco
├── routes/                # Rotas da API
│   ├── auth.js           # Autenticação
│   ├── plans.js          # Planos de acesso
│   ├── payments.js       # Pagamentos
│   ├── sessions.js       # Sessões de usuário
│   ├── admin.js          # Dashboard admin
│   └── webhooks.js       # Webhooks de pagamento
├── services/              # Serviços de negócio
│   ├── abacatepay.js     # Integração AbacatePay
│   ├── mikrotik.js       # Integração MikroTik
│   ├── cache.js          # Redis cache
│   └── session-manager.js # Gerenciamento de sessões
├── middleware/            # Middlewares Express
│   └── security.js       # Rate limiting, validação
├── public/                # Frontend
│   ├── index.html        # Portal principal
│   ├── admin.html        # Dashboard admin
│   ├── css/              # Estilos
│   └── js/               # JavaScript
├── nginx/                 # Configuração Nginx
│   ├── nginx.conf        # Config principal
│   └── ssl/              # Certificados SSL
├── scripts/               # Scripts de automação
│   ├── deploy.sh         # Deploy automático
│   └── mikrotik-setup.rsc # Config MikroTik
└── monitoring/            # Prometheus/Grafana
```

## 🔌 Portas

| Porta | Serviço | Descrição |
|-------|---------|-----------|
| 80 | HTTP | Portal (Captive Portal redirect) |
| 443 | HTTPS | Portal + Webhooks |
| 3000 | App | Aplicação Node.js (interno) |
| 5432 | PostgreSQL | Banco de dados (interno) |
| 6379 | Redis | Cache (interno) |
| 9090 | Prometheus | Métricas (opcional) |
| 3001 | Grafana | Dashboards (opcional) |

## 💳 Planos de Acesso

| Plano | Duração | Preço |
|-------|---------|-------|
| Básico | 1 hora | R$ 5,00 |
| Padrão | 3 horas | R$ 10,00 |
| Diário | 24 horas | R$ 20,00 |
| Semanal | 7 dias | R$ 50,00 |

## 👤 Credenciais Admin Padrão

- **CPF**: 11111111111
- **Senha**: Admin@Carnaval2026!

> ⚠️ **IMPORTANTE**: Altere a senha após o primeiro login!

## 🔧 Comandos Úteis

```bash
# Ver logs da aplicação
docker compose logs -f app

# Reiniciar serviços
docker compose restart

# Parar tudo
docker compose down

# Atualizar e rebuild
docker compose build && docker compose up -d

# Acessar banco de dados
docker compose exec postgres psql -U captive captive_portal

# Verificar health
curl -k https://localhost:443/health
```

## 🔒 Segurança

- ✅ Rate limiting em todas as rotas
- ✅ Validação de CPF com algoritmo verificador
- ✅ Hash de senhas com bcrypt (10 rounds)
- ✅ JWT com expiração configurável
- ✅ Headers de segurança via Helmet.js
- ✅ HTTPS obrigatório para webhooks
- ✅ Proteção contra SQL Injection
- ✅ Proteção contra XSS

## 📊 Monitoramento

Para habilitar Prometheus e Grafana:

```bash
docker compose --profile monitoring up -d
```

Acesse:
- Prometheus: http://SEU_IP:9090
- Grafana: http://SEU_IP:3001 (admin/GrafanaAdmin2026!)

## 🛠️ Suporte

Em caso de problemas:

1. Verifique os logs: `docker compose logs -f`
2. Verifique o health: `curl http://localhost:3000/health`
3. Reinicie os serviços: `docker compose restart`

## 📜 Licença

Desenvolvido para uso privado.

---

**🎭 Carnaval de Recife 2026 - Frevo, Maracatu e Wi-Fi! 🎭**
