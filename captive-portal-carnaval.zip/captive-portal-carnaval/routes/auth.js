/**
 * Authentication Routes
 * Registro, login e logout de usuários
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pino = require('pino');
const router = express.Router();

const { getPool, logSecurityEvent, logConnection } = require('../database/db-manager');
const {
    loginRateLimit,
    registerValidation,
    loginValidation,
    handleValidationErrors,
    authenticate,
    validateCPF
} = require('../middleware/security');
const { recordAuthAttempt } = require('../services/monitoring');
const { cacheUser, invalidateUserCache } = require('../services/cache');
const mikrotik = require('../services/mikrotik');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

/**
 * POST /api/auth/register
 * Registrar novo usuário
 */
router.post('/register', registerValidation, handleValidationErrors, async (req, res) => {
    const pool = getPool();

    try {
        const { name, cpf, email, phone, password, mac_address } = req.body;

        // Limpar CPF
        const cpfClean = cpf.replace(/\D/g, '');

        // Verificar se CPF já existe
        const existing = await pool.query(
            'SELECT id FROM users WHERE cpf = $1',
            [cpfClean]
        );

        if (existing.rows.length > 0) {
            recordAuthAttempt('register', false);
            return res.status(409).json({
                error: 'CPF já cadastrado no sistema'
            });
        }

        // Hash da senha
        const passwordHash = await bcrypt.hash(password, 10);

        // Inserir usuário
        const result = await pool.query(`
            INSERT INTO users (name, cpf, email, phone, password_hash, role, status, active_mac_address)
            VALUES ($1, $2, $3, $4, $5, 'user', 'active', $6)
            RETURNING id, name, cpf, email, phone, role, created_at
        `, [name, cpfClean, email || null, phone || null, passwordHash, mac_address?.toLowerCase() || null]);

        const user = result.rows[0];

        // Registrar dispositivo se MAC fornecido
        if (mac_address) {
            await pool.query(`
                INSERT INTO devices (user_id, mac_address)
                VALUES ($1, $2)
                ON CONFLICT (user_id, mac_address) DO UPDATE
                SET last_seen = CURRENT_TIMESTAMP
            `, [user.id, mac_address.toLowerCase()]);
        }

        // Log de segurança
        await logSecurityEvent('USER_REGISTERED', {
            ip: req.ip,
            userId: user.id,
            userAgent: req.get('user-agent'),
            severity: 'INFO'
        });

        // Gerar token
        const token = jwt.sign(
            { id: user.id, cpf: user.cpf, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRATION || '24h' }
        );

        recordAuthAttempt('register', true);

        logger.info({ userId: user.id, cpf: cpfClean.substring(0, 3) + '***' }, 'Usuário registrado');

        res.status(201).json({
            success: true,
            message: 'Cadastro realizado com sucesso!',
            token,
            user: {
                id: user.id,
                name: user.name,
                cpf: user.cpf,
                email: user.email,
                role: user.role
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro no registro');
        recordAuthAttempt('register', false);

        res.status(500).json({
            error: 'Erro ao realizar cadastro. Tente novamente.'
        });
    }
});

/**
 * POST /api/auth/login
 * Login de usuário
 */
router.post('/login', loginRateLimit, loginValidation, handleValidationErrors, async (req, res) => {
    const pool = getPool();

    try {
        const { cpf, password, mac_address } = req.body;

        // Limpar CPF
        const cpfClean = cpf.replace(/\D/g, '');

        // Buscar usuário
        const result = await pool.query(`
            SELECT id, name, cpf, email, password_hash, role, status, active_mac_address
            FROM users
            WHERE cpf = $1
        `, [cpfClean]);

        if (result.rows.length === 0) {
            recordAuthAttempt('login', false);

            await logSecurityEvent('LOGIN_FAILED', {
                ip: req.ip,
                userAgent: req.get('user-agent'),
                details: { reason: 'CPF não encontrado' },
                severity: 'WARN'
            });

            return res.status(401).json({
                error: 'CPF ou senha incorretos'
            });
        }

        const user = result.rows[0];

        // Verificar status
        if (user.status === 'blocked') {
            recordAuthAttempt('login', false);

            return res.status(403).json({
                error: 'Usuário bloqueado. Entre em contato com o suporte.'
            });
        }

        // Verificar senha
        const passwordValid = await bcrypt.compare(password, user.password_hash);

        if (!passwordValid) {
            recordAuthAttempt('login', false);

            await logSecurityEvent('LOGIN_FAILED', {
                ip: req.ip,
                userId: user.id,
                userAgent: req.get('user-agent'),
                details: { reason: 'Senha incorreta' },
                severity: 'WARN'
            });

            return res.status(401).json({
                error: 'CPF ou senha incorretos'
            });
        }

        // Atualizar último login e MAC
        await pool.query(`
            UPDATE users
            SET last_login = CURRENT_TIMESTAMP,
                active_mac_address = COALESCE($1, active_mac_address)
            WHERE id = $2
        `, [mac_address?.toLowerCase(), user.id]);

        // Registrar dispositivo
        if (mac_address) {
            await pool.query(`
                INSERT INTO devices (user_id, mac_address)
                VALUES ($1, $2)
                ON CONFLICT (user_id, mac_address) DO UPDATE
                SET last_seen = CURRENT_TIMESTAMP
            `, [user.id, mac_address.toLowerCase()]);
        }

        // === TRANSFERÊNCIA DE SESSÃO ===
        // Se o usuário tem sessão ativa e está logando de outro dispositivo, transferir a sessão
        if (mac_address) {
            const newMac = mac_address.toLowerCase();

            // Verificar se há sessão ativa
            const activeSessionResult = await pool.query(`
                SELECT s.*, p.name as plan_name
                FROM sessions s
                JOIN plans p ON s.plan_id = p.id
                WHERE s.user_id = $1 AND s.status = 'active'
                AND s.expected_end_time > NOW()
                ORDER BY s.start_time DESC
                LIMIT 1
            `, [user.id]);

            if (activeSessionResult.rows.length > 0) {
                const session = activeSessionResult.rows[0];
                const oldMac = session.mac_address?.toLowerCase();

                // Se o MAC é diferente, transferir a sessão
                if (oldMac && oldMac !== newMac) {
                    logger.info({
                        userId: user.id,
                        sessionId: session.id,
                        oldMac,
                        newMac
                    }, '🔄 Transferindo sessão para novo dispositivo');

                    // 1. Revogar acesso do MAC antigo no MikroTik
                    try {
                        await mikrotik.removeUserAccess(oldMac);
                        logger.info({ oldMac }, '✅ Acesso revogado do dispositivo antigo');
                    } catch (mkError) {
                        logger.warn({ error: mkError.message, oldMac }, 'Falha ao revogar MAC antigo');
                    }

                    // 2. Atualizar sessão com novo MAC
                    await pool.query(`
                        UPDATE sessions
                        SET mac_address = $1, ip_address = COALESCE($2, ip_address), mikrotik_synced = false
                        WHERE id = $3
                    `, [newMac, req.ip, session.id]);

                    // 3. Autorizar novo MAC no MikroTik
                    try {
                        await mikrotik.authorizeUser(newMac, req.ip || '0.0.0.0');

                        // Marcar como sincronizado
                        await pool.query(
                            'UPDATE sessions SET mikrotik_synced = true WHERE id = $1',
                            [session.id]
                        );

                        logger.info({
                            sessionId: session.id,
                            newMac,
                            planName: session.plan_name
                        }, '✅ Sessão transferida e internet liberada no novo dispositivo!');
                    } catch (mkError) {
                        logger.error({ error: mkError.message, newMac }, 'Falha ao autorizar novo MAC');
                    }

                    // Log de segurança
                    await logSecurityEvent('SESSION_TRANSFERRED', {
                        ip: req.ip,
                        userId: user.id,
                        details: {
                            sessionId: session.id,
                            oldMac,
                            newMac,
                            planName: session.plan_name
                        },
                        severity: 'INFO'
                    });
                }
            }
        }

        // Gerar token
        const token = jwt.sign(
            { id: user.id, cpf: user.cpf, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRATION || '24h' }
        );

        // Cache do usuário
        await cacheUser(user.id, {
            id: user.id,
            name: user.name,
            cpf: user.cpf,
            role: user.role
        });

        // Log de segurança
        await logSecurityEvent('LOGIN_SUCCESS', {
            ip: req.ip,
            userId: user.id,
            userAgent: req.get('user-agent'),
            severity: 'INFO'
        });

        recordAuthAttempt('login', true);

        logger.info({ userId: user.id }, 'Login realizado');

        res.json({
            success: true,
            token,
            user: {
                id: user.id,
                name: user.name,
                cpf: user.cpf,
                email: user.email,
                role: user.role
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro no login');
        recordAuthAttempt('login', false);

        res.status(500).json({
            error: 'Erro ao realizar login. Tente novamente.'
        });
    }
});

/**
 * POST /api/auth/admin-login
 * Login de administrador
 */
router.post('/admin-login', loginRateLimit, loginValidation, handleValidationErrors, async (req, res) => {
    const pool = getPool();

    try {
        const { cpf, password } = req.body;
        const cpfClean = cpf.replace(/\D/g, '');

        // Buscar admin
        const result = await pool.query(`
            SELECT id, name, cpf, email, password_hash, role, status
            FROM users
            WHERE cpf = $1 AND role IN ('admin', 'manager')
        `, [cpfClean]);

        if (result.rows.length === 0) {
            recordAuthAttempt('admin_login', false);

            await logSecurityEvent('ADMIN_LOGIN_FAILED', {
                ip: req.ip,
                userAgent: req.get('user-agent'),
                details: { reason: 'Credenciais inválidas ou não é admin' },
                severity: 'WARN'
            });

            return res.status(401).json({
                error: 'Credenciais inválidas'
            });
        }

        const user = result.rows[0];

        // Verificar senha
        const passwordValid = await bcrypt.compare(password, user.password_hash);

        if (!passwordValid) {
            recordAuthAttempt('admin_login', false);

            await logSecurityEvent('ADMIN_LOGIN_FAILED', {
                ip: req.ip,
                userId: user.id,
                userAgent: req.get('user-agent'),
                details: { reason: 'Senha incorreta' },
                severity: 'WARN'
            });

            return res.status(401).json({
                error: 'Credenciais inválidas'
            });
        }

        // Atualizar último login
        await pool.query(
            'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1',
            [user.id]
        );

        // Gerar token
        const token = jwt.sign(
            { id: user.id, cpf: user.cpf, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: '12h' }
        );

        // Log de segurança
        await logSecurityEvent('ADMIN_LOGIN_SUCCESS', {
            ip: req.ip,
            userId: user.id,
            userAgent: req.get('user-agent'),
            severity: 'INFO'
        });

        recordAuthAttempt('admin_login', true);

        logger.info({ userId: user.id, role: user.role }, 'Admin login realizado');

        res.json({
            success: true,
            token,
            user: {
                id: user.id,
                name: user.name,
                role: user.role
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro no admin login');
        recordAuthAttempt('admin_login', false);

        res.status(500).json({
            error: 'Erro ao realizar login'
        });
    }
});

/**
 * POST /api/auth/logout
 * Logout de usuário
 */
router.post('/logout', authenticate, async (req, res) => {
    try {
        // Invalidar cache do usuário
        await invalidateUserCache(req.user.id);

        // Log de segurança
        await logSecurityEvent('LOGOUT', {
            ip: req.ip,
            userId: req.user.id,
            userAgent: req.get('user-agent'),
            severity: 'INFO'
        });

        logger.info({ userId: req.user.id }, 'Logout realizado');

        res.json({
            success: true,
            message: 'Logout realizado com sucesso'
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro no logout');
        res.status(500).json({ error: 'Erro ao realizar logout' });
    }
});

/**
 * GET /api/auth/me
 * Obter dados do usuário autenticado
 */
router.get('/me', authenticate, async (req, res) => {
    const pool = getPool();

    try {
        const result = await pool.query(`
            SELECT id, name, cpf, email, phone, role, created_at, last_login, active_mac_address
            FROM users
            WHERE id = $1
        `, [req.user.id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }

        const user = result.rows[0];

        // Buscar sessão ativa
        const sessionResult = await pool.query(`
            SELECT s.*, p.name as plan_name
            FROM sessions s
            JOIN plans p ON s.plan_id = p.id
            WHERE s.user_id = $1 AND s.status = 'active'
            ORDER BY s.start_time DESC
            LIMIT 1
        `, [user.id]);

        let activeSession = null;

        if (sessionResult.rows.length > 0) {
            const session = sessionResult.rows[0];
            const now = new Date();
            const endTime = new Date(session.expected_end_time);
            const remainingMs = endTime - now;

            if (remainingMs > 0) {
                activeSession = {
                    id: session.id,
                    plan_name: session.plan_name,
                    start_time: session.start_time,
                    expected_end_time: session.expected_end_time,
                    remaining_minutes: Math.floor(remainingMs / 60000)
                };
            }
        }

        res.json({
            user: {
                id: user.id,
                name: user.name,
                cpf: user.cpf,
                email: user.email,
                phone: user.phone,
                role: user.role,
                created_at: user.created_at,
                last_login: user.last_login
            },
            activeSession
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao obter dados do usuário');
        res.status(500).json({ error: 'Erro ao obter dados' });
    }
});

/**
 * PUT /api/auth/password
 * Alterar senha do usuário
 */
router.put('/password', authenticate, async (req, res) => {
    const pool = getPool();

    try {
        const { current_password, new_password } = req.body;

        if (!current_password || !new_password) {
            return res.status(400).json({
                error: 'Senha atual e nova senha são obrigatórias'
            });
        }

        if (new_password.length < 6) {
            return res.status(400).json({
                error: 'Nova senha deve ter no mínimo 6 caracteres'
            });
        }

        // Buscar senha atual
        const result = await pool.query(
            'SELECT password_hash FROM users WHERE id = $1',
            [req.user.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }

        // Verificar senha atual
        const passwordValid = await bcrypt.compare(
            current_password,
            result.rows[0].password_hash
        );

        if (!passwordValid) {
            await logSecurityEvent('PASSWORD_CHANGE_FAILED', {
                ip: req.ip,
                userId: req.user.id,
                details: { reason: 'Senha atual incorreta' },
                severity: 'WARN'
            });

            return res.status(401).json({ error: 'Senha atual incorreta' });
        }

        // Atualizar senha
        const newHash = await bcrypt.hash(new_password, 10);

        await pool.query(
            'UPDATE users SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
            [newHash, req.user.id]
        );

        // Log de segurança
        await logSecurityEvent('PASSWORD_CHANGED', {
            ip: req.ip,
            userId: req.user.id,
            userAgent: req.get('user-agent'),
            severity: 'INFO'
        });

        logger.info({ userId: req.user.id }, 'Senha alterada');

        res.json({
            success: true,
            message: 'Senha alterada com sucesso'
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao alterar senha');
        res.status(500).json({ error: 'Erro ao alterar senha' });
    }
});

module.exports = router;
