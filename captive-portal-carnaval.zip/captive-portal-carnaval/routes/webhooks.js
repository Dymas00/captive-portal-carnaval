/**
 * Webhooks Routes
 * Recebimento de notificações de pagamento
 */

const express = require('express');
const pino = require('pino');
const router = express.Router();

const { getPool, logSecurityEvent } = require('../database/db-manager');
const { webhookRateLimit } = require('../middleware/security');
const abacatepay = require('../services/abacatepay');
const { createSession } = require('../services/session-manager');
const { recordPayment, updateRevenue } = require('../services/monitoring');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

/**
 * POST /api/webhooks/abacatepay
 * Webhook do AbacatePay
 */
router.post('/abacatepay', webhookRateLimit, async (req, res) => {
    const pool = getPool();

    try {
        const signature = req.headers['x-webhook-signature'] ||
            req.headers['x-abacatepay-signature'] ||
            req.headers['authorization'];

        logger.info({
            event: req.body.event || req.body.type,
            hasSignature: !!signature,
            paymentId: req.body.data?.pixQrCode?.id || req.body.data?.id,
            amount: req.body.data?.pixQrCode?.amount || req.body.data?.amount
        }, '🔔 WEBHOOK ABACATEPAY RECEBIDO');

        // Validar assinatura (se configurado)
        if (process.env.ABACATEPAY_WEBHOOK_SECRET) {
            const isValid = abacatepay.validateWebhookSignature(req.body, req.headers, req.query);

            if (!isValid) {
                logger.warn({ ip: req.ip }, 'Webhook com assinatura inválida');

                await logSecurityEvent('WEBHOOK_INVALID_SIGNATURE', {
                    ip: req.ip,
                    details: { gateway: 'abacatepay' },
                    severity: 'WARN'
                });

                return res.status(401).json({ error: 'Assinatura inválida' });
            }
        }

        // Processar webhook
        const result = await abacatepay.processWebhook(req.body, req.headers);

        if (!result) {
            logger.warn('Webhook não processado - evento não reconhecido');
            return res.status(200).json({ received: true, processed: false });
        }

        const { paymentId, status, paidAt } = result;

        // Buscar pagamento no banco
        const paymentResult = await pool.query(`
            SELECT p.*, u.active_mac_address, u.name as user_name
            FROM payments p
            JOIN users u ON p.user_id = u.id
            WHERE p.payment_id = $1
        `, [paymentId]);

        if (paymentResult.rows.length === 0) {
            logger.warn({ paymentId }, 'Pagamento não encontrado no banco');
            return res.status(200).json({ received: true, processed: false });
        }

        const payment = paymentResult.rows[0];

        // Verificar idempotência - já processado?
        if (payment.status === status) {
            logger.info({ paymentId, status }, 'Pagamento já processado (idempotência)');
            return res.status(200).json({ received: true, already_processed: true });
        }

        // Processar de acordo com o status
        if (status === 'approved') {
            // Atualizar status do pagamento
            await pool.query(`
                UPDATE payments
                SET status = 'approved', paid_at = $1
                WHERE id = $2
            `, [paidAt || new Date(), payment.id]);

            // Criar sessão
            const macAddress = payment.active_mac_address || 'AA:BB:CC:DD:EE:FF';

            // Tentar obter IP real do MikroTik pelo MAC
            let ipAddress = '0.0.0.0';
            const mikrotik = require('../services/mikrotik');

            if (macAddress !== 'AA:BB:CC:DD:EE:FF') {
                try {
                    const realIp = await mikrotik.getIpByMac(macAddress);
                    if (realIp) {
                        ipAddress = realIp;
                        logger.info({ macAddress, ipAddress: realIp }, 'IP obtido do MikroTik');
                    }
                } catch (ipError) {
                    logger.warn({ error: ipError.message }, 'Não foi possível obter IP do MikroTik');
                }
            }

            try {
                const session = await createSession(
                    payment.user_id,
                    macAddress,
                    ipAddress,
                    payment.plan_id
                );

                // Atualizar pagamento com sessão
                await pool.query(
                    'UPDATE payments SET session_id = $1 WHERE id = $2',
                    [session.id, payment.id]
                );

                logger.info({
                    paymentId,
                    sessionId: session.id,
                    userId: payment.user_id,
                    macAddress: macAddress,
                    ipAddress: ipAddress,
                    userName: payment.user_name
                }, '✅ SESSÃO CRIADA VIA WEBHOOK - Internet liberada!');

            } catch (sessionError) {
                logger.error({
                    error: sessionError.message,
                    paymentId
                }, 'Erro ao criar sessão após webhook');
            }

            // Log de segurança
            await logSecurityEvent('PAYMENT_APPROVED_WEBHOOK', {
                details: {
                    paymentId,
                    userId: payment.user_id,
                    amount: payment.amount_cents
                },
                severity: 'INFO'
            });

            // Atualizar métricas
            recordPayment('approved', 'abacatepay');

            // Atualizar receita total
            const revenueResult = await pool.query(
                "SELECT SUM(amount_cents) as total FROM payments WHERE status = 'approved'"
            );
            updateRevenue(parseInt(revenueResult.rows[0].total) || 0);

        } else if (status === 'expired') {
            await pool.query(
                "UPDATE payments SET status = 'expired' WHERE id = $1",
                [payment.id]
            );

            logger.info({ paymentId }, 'Pagamento expirado via webhook');
            recordPayment('expired', 'abacatepay');

        } else if (status === 'cancelled') {
            await pool.query(
                "UPDATE payments SET status = 'cancelled' WHERE id = $1",
                [payment.id]
            );

            logger.info({ paymentId }, 'Pagamento cancelado via webhook');
            recordPayment('cancelled', 'abacatepay');
        }

        res.status(200).json({
            received: true,
            processed: true,
            payment_id: paymentId,
            status
        });

    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao processar webhook');

        await logSecurityEvent('WEBHOOK_ERROR', {
            ip: req.ip,
            details: { error: error.message, gateway: 'abacatepay' },
            severity: 'ERROR'
        });

        // Retornar 200 para evitar retentativas do gateway
        res.status(200).json({
            received: true,
            processed: false,
            error: 'Internal error'
        });
    }
});

/**
 * POST /api/webhooks/test
 * Webhook de teste (apenas desenvolvimento)
 */
router.post('/test', async (req, res) => {
    if (process.env.NODE_ENV === 'production') {
        return res.status(404).json({ error: 'Not found' });
    }

    logger.info({ body: req.body }, 'Webhook de teste recebido');

    res.json({
        received: true,
        timestamp: new Date().toISOString(),
        body: req.body
    });
});

/**
 * GET /api/webhooks/health
 * Health check do endpoint de webhook
 */
router.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        endpoint: '/api/webhooks/abacatepay'
    });
});

module.exports = router;
