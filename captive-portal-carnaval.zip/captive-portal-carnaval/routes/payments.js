/**
 * Payments Routes
 * Processamento de pagamentos via Pix
 */

const express = require('express');
const pino = require('pino');
const router = express.Router();

const { getPool, logSecurityEvent } = require('../database/db-manager');
const {
    paymentRateLimit,
    paymentValidation,
    handleValidationErrors,
    authenticate
} = require('../middleware/security');
const abacatepay = require('../services/abacatepay');
const { createSession } = require('../services/session-manager');
const { recordPayment, updateRevenue } = require('../services/monitoring');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

/**
 * POST /api/payments/create
 * Criar pagamento Pix
 */
router.post('/create', authenticate, paymentRateLimit, paymentValidation, handleValidationErrors, async (req, res) => {
    const pool = getPool();

    try {
        const { plan_id, mac_address } = req.body;
        const userId = req.user.id;

        // Buscar plano
        const planResult = await pool.query(
            'SELECT * FROM plans WHERE id = $1 AND active = true',
            [plan_id]
        );

        if (planResult.rows.length === 0) {
            return res.status(404).json({ error: 'Plano não encontrado' });
        }

        const plan = planResult.rows[0];

        // Buscar dados do usuário
        const userResult = await pool.query(
            'SELECT id, name, cpf, email FROM users WHERE id = $1',
            [userId]
        );

        if (userResult.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }

        const user = userResult.rows[0];

        // Verificar se já tem pagamento pendente para este plano
        const pendingResult = await pool.query(`
            SELECT id, payment_id, qr_code_base64, pix_copia_cola, expires_at
            FROM payments
            WHERE user_id = $1 AND plan_id = $2 AND status = 'pending'
            AND expires_at > CURRENT_TIMESTAMP
            ORDER BY created_at DESC
            LIMIT 1
        `, [userId, plan_id]);

        // Se já existe pagamento pendente válido, retornar ele
        if (pendingResult.rows.length > 0) {
            const pending = pendingResult.rows[0];
            const ABACATEPAY_FEE = 80;
            const totalPendingAmount = plan.price_cents + ABACATEPAY_FEE;

            return res.json({
                success: true,
                payment: {
                    id: pending.id,
                    payment_id: pending.payment_id,
                    status: 'pending',
                    qr_code_base64: pending.qr_code_base64,
                    pix_copia_cola: pending.pix_copia_cola,
                    expires_at: pending.expires_at,
                    plan: {
                        id: plan.id,
                        name: plan.name,
                        plan_price: plan.price_cents,
                        fee: ABACATEPAY_FEE,
                        total_amount: totalPendingAmount,
                        price_formatted: `R$ ${(totalPendingAmount / 100).toFixed(2).replace('.', ',')}`,
                        breakdown: `Plano: R$ ${(plan.price_cents / 100).toFixed(2)} + Taxa: R$ 0,80`
                    }
                },
                message: 'Pagamento pendente encontrado'
            });
        }

        // Calcular valor total com taxa do AbacatePay (R$ 0,80)
        const ABACATEPAY_FEE = 80; // 80 centavos conforme documentação
        const totalAmountCents = plan.price_cents + ABACATEPAY_FEE;

        logger.info({
            planPrice: plan.price_cents,
            fee: ABACATEPAY_FEE,
            total: totalAmountCents,
            totalFormatted: `R$ ${(totalAmountCents / 100).toFixed(2)}`
        }, 'Valor do pagamento com taxa AbacatePay');

        // Criar pagamento no AbacatePay
        const paymentData = await abacatepay.createPixPayment({
            userId: user.id,
            planId: plan.id,
            amount: totalAmountCents, // Valor do plano + taxa de R$ 0,80
            payer: {
                name: user.name,
                cpf: user.cpf,
                email: user.email,
                phone: user.phone || ''
            },
            description: `Wi-Fi ${plan.name} - Carnaval de Recife (taxa inclusa)`
        });

        // Salvar pagamento no banco
        const expiresAt = new Date(Date.now() + 3600000); // 1 hora

        const insertResult = await pool.query(`
            INSERT INTO payments (
                user_id, plan_id, amount_cents, payment_method, payment_gateway,
                payment_id, qr_code, qr_code_base64, pix_copia_cola,
                status, expires_at, gateway_fee_cents, raw_response
            )
            VALUES ($1, $2, $3, 'pix', 'abacatepay', $4, $5, $6, $7, 'pending', $8, $9, $10)
            RETURNING id
        `, [
            userId,
            plan.id,
            totalAmountCents, // Valor total (plano + taxa)
            paymentData.paymentId,
            paymentData.qrCode,
            paymentData.qrCodeBase64,
            paymentData.pixKey || paymentData.qrCode, // pixKey é o código copia e cola
            expiresAt,
            ABACATEPAY_FEE, // Taxa fixa AbacatePay (R$ 0,80)
            JSON.stringify(paymentData.raw || {})
        ]);

        // Atualizar MAC do usuário se fornecido
        if (mac_address) {
            await pool.query(
                'UPDATE users SET active_mac_address = $1 WHERE id = $2',
                [mac_address.toLowerCase(), userId]
            );
        }

        // Log de segurança
        await logSecurityEvent('PAYMENT_CREATED', {
            ip: req.ip,
            userId,
            details: {
                paymentId: paymentData.paymentId,
                planId: plan.id,
                planAmount: plan.price_cents,
                fee: ABACATEPAY_FEE,
                totalAmount: totalAmountCents
            },
            severity: 'INFO'
        });

        logger.info({
            userId,
            paymentId: paymentData.paymentId,
            planId: plan.id,
            planAmount: plan.price_cents,
            fee: ABACATEPAY_FEE,
            totalAmount: totalAmountCents
        }, 'Pagamento criado com taxa AbacatePay');

        res.json({
            success: true,
            payment: {
                id: insertResult.rows[0].id,
                payment_id: paymentData.paymentId,
                status: 'pending',
                qr_code_base64: paymentData.qrCodeBase64,
                pix_copia_cola: paymentData.pixKey || paymentData.qrCode, // Código copia e cola
                expires_at: expiresAt.toISOString(),
                plan: {
                    id: plan.id,
                    name: plan.name,
                    duration_minutes: plan.duration_minutes,
                    plan_price: plan.price_cents,
                    fee: ABACATEPAY_FEE,
                    total_amount: totalAmountCents,
                    price_formatted: `R$ ${(totalAmountCents / 100).toFixed(2).replace('.', ',')}`,
                    breakdown: `Plano: R$ ${(plan.price_cents / 100).toFixed(2)} + Taxa: R$ 0,80`
                }
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao criar pagamento');

        await logSecurityEvent('PAYMENT_ERROR', {
            ip: req.ip,
            userId: req.user.id,
            details: { error: error.message },
            severity: 'ERROR'
        });

        res.status(500).json({
            error: 'Erro ao processar pagamento. Tente novamente.'
        });
    }
});

/**
 * GET /api/payments/status/:paymentId
 * Verificar status do pagamento
 */
router.get('/status/:paymentId', authenticate, async (req, res) => {
    const pool = getPool();

    try {
        const { paymentId } = req.params;

        // Buscar pagamento no banco
        const result = await pool.query(`
            SELECT p.*, pl.name as plan_name, pl.duration_minutes
            FROM payments p
            JOIN plans pl ON p.plan_id = pl.id
            WHERE p.payment_id = $1 AND p.user_id = $2
        `, [paymentId, req.user.id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Pagamento não encontrado' });
        }

        const payment = result.rows[0];

        // Se ainda pendente, verificar no gateway (APENAS CONSULTA, NÃO CRIA SESSÃO)
        // A sessão será criada SOMENTE pelo webhook
        if (payment.status === 'pending') {
            try {
                const gatewayStatus = await abacatepay.getPaymentStatus(paymentId);

                if (gatewayStatus.status === 'approved' && payment.status !== 'approved') {
                    // APENAS atualizar status do pagamento no banco
                    // NÃO criar sessão - isso é responsabilidade do webhook!
                    await pool.query(`
                        UPDATE payments
                        SET status = 'approved', paid_at = $1
                        WHERE id = $2
                    `, [gatewayStatus.paidAt || new Date(), payment.id]);

                    logger.info({
                        paymentId,
                        userId: req.user.id
                    }, 'Pagamento aprovado detectado via polling - aguardando webhook para criar sessão');

                    return res.json({
                        payment_id: paymentId,
                        status: 'approved',
                        message: 'Pagamento aprovado! Aguardando confirmação...'
                    });
                }
            } catch (gatewayError) {
                logger.warn({ error: gatewayError.message }, 'Erro ao consultar gateway');
            }
        }

        res.json({
            payment_id: paymentId,
            status: payment.status,
            plan_name: payment.plan_name,
            amount_formatted: `R$ ${(payment.amount_cents / 100).toFixed(2).replace('.', ',')}`,
            created_at: payment.created_at,
            paid_at: payment.paid_at
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao verificar status');
        res.status(500).json({ error: 'Erro ao verificar status do pagamento' });
    }
});

/**
 * GET /api/payments/history
 * Histórico de pagamentos do usuário
 */
router.get('/history', authenticate, async (req, res) => {
    const pool = getPool();

    try {
        const { page = 1, limit = 10 } = req.query;
        const offset = (page - 1) * limit;

        const countResult = await pool.query(
            'SELECT COUNT(*) FROM payments WHERE user_id = $1',
            [req.user.id]
        );
        const total = parseInt(countResult.rows[0].count);

        const result = await pool.query(`
            SELECT p.id, p.payment_id, p.amount_cents, p.status, p.created_at, p.paid_at,
                   pl.name as plan_name, pl.duration_minutes
            FROM payments p
            JOIN plans pl ON p.plan_id = pl.id
            WHERE p.user_id = $1
            ORDER BY p.created_at DESC
            LIMIT $2 OFFSET $3
        `, [req.user.id, limit, offset]);

        const payments = result.rows.map(p => ({
            id: p.id,
            payment_id: p.payment_id,
            plan_name: p.plan_name,
            amount_formatted: `R$ ${(p.amount_cents / 100).toFixed(2).replace('.', ',')}`,
            status: p.status,
            status_label: getStatusLabel(p.status),
            created_at: p.created_at,
            paid_at: p.paid_at
        }));

        res.json({
            payments,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                totalPages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao buscar histórico');
        res.status(500).json({ error: 'Erro ao buscar histórico de pagamentos' });
    }
});

/**
 * Processar pagamento aprovado
 */
async function processApprovedPayment(paymentId, paidAt = null) {
    const pool = getPool();

    try {
        // Buscar detalhes do pagamento
        const paymentResult = await pool.query(`
            SELECT p.*, u.active_mac_address, u.name as user_name
            FROM payments p
            JOIN users u ON p.user_id = u.id
            WHERE p.id = $1
        `, [paymentId]);

        if (paymentResult.rows.length === 0) {
            throw new Error('Pagamento não encontrado');
        }

        const payment = paymentResult.rows[0];

        // Verificar se já foi processado
        if (payment.status === 'approved') {
            logger.info({ paymentId }, 'Pagamento já processado');
            return payment;
        }

        // Atualizar status do pagamento
        await pool.query(`
            UPDATE payments
            SET status = 'approved', paid_at = $1
            WHERE id = $2
        `, [paidAt || new Date(), paymentId]);

        // Criar sessão
        const macAddress = payment.active_mac_address || 'AA:BB:CC:DD:EE:FF';
        const ipAddress = '0.0.0.0'; // Será atualizado pelo MikroTik

        const session = await createSession(
            payment.user_id,
            macAddress,
            ipAddress,
            payment.plan_id
        );

        // Atualizar pagamento com sessão
        await pool.query(
            'UPDATE payments SET session_id = $1 WHERE id = $2',
            [session.id, paymentId]
        );

        // Log de segurança
        await logSecurityEvent('PAYMENT_APPROVED', {
            userId: payment.user_id,
            details: {
                paymentId: payment.payment_id,
                sessionId: session.id,
                amount: payment.amount_cents
            },
            severity: 'INFO'
        });

        // Atualizar métricas
        recordPayment('approved', 'abacatepay');

        // Atualizar receita total
        const revenueResult = await pool.query(
            "SELECT SUM(amount_cents) as total FROM payments WHERE status = 'approved'"
        );
        updateRevenue(parseInt(revenueResult.rows[0].total) || 0);

        logger.info({
            paymentId: payment.payment_id,
            sessionId: session.id,
            userId: payment.user_id
        }, 'Pagamento aprovado e sessão criada');

        return { payment, session };
    } catch (error) {
        logger.error({ error: error.message, paymentId }, 'Erro ao processar pagamento aprovado');
        throw error;
    }
}

/**
 * Obter label do status
 */
function getStatusLabel(status) {
    const labels = {
        pending: 'Aguardando Pagamento',
        approved: 'Aprovado',
        cancelled: 'Cancelado',
        expired: 'Expirado',
        refunded: 'Reembolsado'
    };
    return labels[status] || status;
}

// Exportar função para uso no webhook
module.exports = router;
module.exports.processApprovedPayment = processApprovedPayment;
