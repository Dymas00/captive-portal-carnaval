/**
 * Admin Routes
 * Dashboard e gerenciamento administrativo
 */

const express = require('express');
const pino = require('pino');
const router = express.Router();

const { getPool, logSecurityEvent } = require('../database/db-manager');
const { authenticate, authorize } = require('../middleware/security');
const { updateActiveSessions, updateTotalUsers } = require('../services/monitoring');
const { disconnectSession } = require('../services/session-manager');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

/**
 * GET /api/admin/dashboard
 * Dados do dashboard
 */
router.get('/dashboard', authenticate, authorize('admin', 'manager'), async (req, res) => {
    const pool = getPool();

    try {
        // Estatísticas em paralelo
        const [
            usersResult,
            sessionsResult,
            revenueResult,
            todayRevenueResult,
            pendingPaymentsResult,
            recentUsersResult
        ] = await Promise.all([
            pool.query('SELECT COUNT(*) FROM users'),
            pool.query("SELECT COUNT(*) FROM sessions WHERE status = 'active'"),
            pool.query("SELECT COALESCE(SUM(amount_cents), 0) as total FROM payments WHERE status = 'approved'"),
            pool.query(`
                SELECT COALESCE(SUM(amount_cents), 0) as total
                FROM payments
                WHERE status = 'approved'
                AND paid_at >= CURRENT_DATE
            `),
            pool.query("SELECT COUNT(*) FROM payments WHERE status = 'pending'"),
            pool.query(`
                SELECT id, name, cpf, created_at
                FROM users
                WHERE role = 'user'
                ORDER BY created_at DESC
                LIMIT 5
            `)
        ]);

        const totalUsers = parseInt(usersResult.rows[0].count);
        const activeSessions = parseInt(sessionsResult.rows[0].count);

        // Atualizar métricas
        updateTotalUsers(totalUsers);
        updateActiveSessions(activeSessions);

        // Dados de crescimento (últimos 7 dias)
        const growthResult = await pool.query(`
            SELECT
                DATE(created_at) as date,
                COUNT(*) as users
            FROM users
            WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
            GROUP BY DATE(created_at)
            ORDER BY date
        `);

        // Receita dos últimos 7 dias
        const revenueGrowthResult = await pool.query(`
            SELECT
                DATE(paid_at) as date,
                COALESCE(SUM(amount_cents), 0) as revenue
            FROM payments
            WHERE status = 'approved'
            AND paid_at >= CURRENT_DATE - INTERVAL '7 days'
            GROUP BY DATE(paid_at)
            ORDER BY date
        `);

        res.json({
            stats: {
                totalUsers,
                activeSessions,
                totalRevenue: parseInt(revenueResult.rows[0].total),
                totalRevenueFormatted: formatMoney(parseInt(revenueResult.rows[0].total)),
                todayRevenue: parseInt(todayRevenueResult.rows[0].total),
                todayRevenueFormatted: formatMoney(parseInt(todayRevenueResult.rows[0].total)),
                pendingPayments: parseInt(pendingPaymentsResult.rows[0].count)
            },
            recentUsers: recentUsersResult.rows.map(u => ({
                ...u,
                cpf: maskCPF(u.cpf)
            })),
            charts: {
                userGrowth: growthResult.rows,
                revenueGrowth: revenueGrowthResult.rows.map(r => ({
                    date: r.date,
                    revenue: parseInt(r.revenue),
                    revenueFormatted: formatMoney(parseInt(r.revenue))
                }))
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao buscar dados do dashboard');
        res.status(500).json({ error: 'Erro ao buscar dados' });
    }
});

/**
 * GET /api/admin/users
 * Listar usuários
 */
router.get('/users', authenticate, authorize('admin', 'manager'), async (req, res) => {
    const pool = getPool();

    try {
        const {
            page = 1,
            limit = 50,
            search = '',
            status = '',
            role = ''
        } = req.query;

        const offset = (page - 1) * limit;

        let whereClause = "WHERE role != 'admin'";
        const params = [];
        let paramIndex = 1;

        if (search) {
            whereClause += ` AND (name ILIKE $${paramIndex} OR cpf LIKE $${paramIndex + 1} OR email ILIKE $${paramIndex})`;
            params.push(`%${search}%`, `%${search.replace(/\D/g, '')}%`);
            paramIndex += 2;
        }

        if (status) {
            whereClause += ` AND status = $${paramIndex}`;
            params.push(status);
            paramIndex++;
        }

        if (role) {
            whereClause += ` AND role = $${paramIndex}`;
            params.push(role);
            paramIndex++;
        }

        const countResult = await pool.query(
            `SELECT COUNT(*) FROM users ${whereClause}`,
            params
        );
        const total = parseInt(countResult.rows[0].count);

        const result = await pool.query(`
            SELECT id, name, cpf, email, phone, role, status, created_at, last_login, active_mac_address
            FROM users
            ${whereClause}
            ORDER BY created_at DESC
            LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
        `, [...params, limit, offset]);

        const users = result.rows.map(u => ({
            ...u,
            cpf: maskCPF(u.cpf)
        }));

        res.json({
            users,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                totalPages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao listar usuários');
        res.status(500).json({ error: 'Erro ao buscar usuários' });
    }
});

/**
 * GET /api/admin/users/:id
 * Detalhes de um usuário
 */
router.get('/users/:id', authenticate, authorize('admin', 'manager'), async (req, res) => {
    const pool = getPool();

    try {
        const { id } = req.params;

        const userResult = await pool.query(`
            SELECT id, name, cpf, email, phone, role, status, created_at, last_login, active_mac_address
            FROM users WHERE id = $1
        `, [id]);

        if (userResult.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }

        // Sessão ativa
        const sessionResult = await pool.query(`
            SELECT s.*, p.name as plan_name
            FROM sessions s
            JOIN plans p ON s.plan_id = p.id
            WHERE s.user_id = $1 AND s.status = 'active'
            ORDER BY s.start_time DESC
            LIMIT 1
        `, [id]);

        // Histórico de pagamentos
        const paymentsResult = await pool.query(`
            SELECT p.id, p.amount_cents, p.status, p.created_at, p.paid_at, pl.name as plan_name
            FROM payments p
            JOIN plans pl ON p.plan_id = pl.id
            WHERE p.user_id = $1
            ORDER BY p.created_at DESC
            LIMIT 10
        `, [id]);

        // Dispositivos
        const devicesResult = await pool.query(`
            SELECT mac_address, device_name, first_seen, last_seen
            FROM devices
            WHERE user_id = $1
            ORDER BY last_seen DESC
        `, [id]);

        const user = userResult.rows[0];

        res.json({
            user: {
                ...user,
                cpf: maskCPF(user.cpf)
            },
            activeSession: sessionResult.rows[0] || null,
            payments: paymentsResult.rows.map(p => ({
                ...p,
                amount_formatted: formatMoney(p.amount_cents)
            })),
            devices: devicesResult.rows
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao buscar usuário');
        res.status(500).json({ error: 'Erro ao buscar usuário' });
    }
});

/**
 * POST /api/admin/users/:id/disconnect
 * Desconectar usuário
 */
router.post('/users/:id/disconnect', authenticate, authorize('admin'), async (req, res) => {
    const pool = getPool();

    try {
        const { id } = req.params;
        const { reason } = req.body;

        // Buscar sessão ativa
        const sessionResult = await pool.query(`
            SELECT id FROM sessions
            WHERE user_id = $1 AND status = 'active'
        `, [id]);

        if (sessionResult.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não possui sessão ativa' });
        }

        // Desconectar
        await disconnectSession(sessionResult.rows[0].id, reason || 'admin_disconnect');

        await logSecurityEvent('USER_DISCONNECTED_BY_ADMIN', {
            ip: req.ip,
            userId: req.user.id,
            details: { targetUserId: id, reason },
            severity: 'INFO'
        });

        logger.info({
            adminId: req.user.id,
            userId: id,
            reason
        }, 'Usuário desconectado por admin');

        res.json({
            success: true,
            message: 'Usuário desconectado com sucesso'
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao desconectar usuário');
        res.status(500).json({ error: 'Erro ao desconectar usuário' });
    }
});

/**
 * PUT /api/admin/users/:id/status
 * Alterar status do usuário (bloquear/desbloquear)
 */
router.put('/users/:id/status', authenticate, authorize('admin'), async (req, res) => {
    const pool = getPool();

    try {
        const { id } = req.params;
        const { status } = req.body;

        if (!['active', 'blocked', 'suspended'].includes(status)) {
            return res.status(400).json({ error: 'Status inválido' });
        }

        const result = await pool.query(`
            UPDATE users SET status = $1, updated_at = CURRENT_TIMESTAMP
            WHERE id = $2 AND role != 'admin'
            RETURNING id, name, status
        `, [status, id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }

        // Se bloqueou, desconectar sessão ativa
        if (status === 'blocked') {
            const sessionResult = await pool.query(
                "SELECT id FROM sessions WHERE user_id = $1 AND status = 'active'",
                [id]
            );

            if (sessionResult.rows.length > 0) {
                await disconnectSession(sessionResult.rows[0].id, 'user_blocked');
            }
        }

        await logSecurityEvent('USER_STATUS_CHANGED', {
            ip: req.ip,
            userId: req.user.id,
            details: { targetUserId: id, newStatus: status },
            severity: 'INFO'
        });

        res.json({
            success: true,
            user: result.rows[0]
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao alterar status');
        res.status(500).json({ error: 'Erro ao alterar status' });
    }
});

/**
 * DELETE /api/admin/users/:id
 * Remover usuário
 */
router.delete('/users/:id', authenticate, authorize('admin'), async (req, res) => {
    const pool = getPool();

    try {
        const { id } = req.params;

        // Verificar se existe e não é admin
        const userResult = await pool.query(
            'SELECT id, role FROM users WHERE id = $1',
            [id]
        );

        if (userResult.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }

        if (userResult.rows[0].role === 'admin') {
            return res.status(403).json({ error: 'Não é possível remover administradores' });
        }

        // Desconectar se tiver sessão ativa
        const sessionResult = await pool.query(
            "SELECT id FROM sessions WHERE user_id = $1 AND status = 'active'",
            [id]
        );

        if (sessionResult.rows.length > 0) {
            await disconnectSession(sessionResult.rows[0].id, 'user_deleted');
        }

        // Remover usuário (cascade remove sessions, payments, devices)
        await pool.query('DELETE FROM users WHERE id = $1', [id]);

        await logSecurityEvent('USER_DELETED', {
            ip: req.ip,
            userId: req.user.id,
            details: { deletedUserId: id },
            severity: 'WARN'
        });

        logger.info({
            adminId: req.user.id,
            deletedUserId: id
        }, 'Usuário removido');

        res.json({
            success: true,
            message: 'Usuário removido com sucesso'
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao remover usuário');
        res.status(500).json({ error: 'Erro ao remover usuário' });
    }
});

/**
 * GET /api/admin/logs
 * Logs de conexão (Marco Civil)
 */
router.get('/logs', authenticate, authorize('admin', 'manager'), async (req, res) => {
    const pool = getPool();

    try {
        const {
            page = 1,
            limit = 100,
            user_id,
            mac,
            action,
            start_date,
            end_date
        } = req.query;

        const offset = (page - 1) * limit;

        let whereClause = 'WHERE 1=1';
        const params = [];
        let paramIndex = 1;

        if (user_id) {
            whereClause += ` AND cl.user_id = $${paramIndex}`;
            params.push(user_id);
            paramIndex++;
        }

        if (mac) {
            whereClause += ` AND cl.mac_address ILIKE $${paramIndex}`;
            params.push(`%${mac}%`);
            paramIndex++;
        }

        if (action) {
            whereClause += ` AND cl.action = $${paramIndex}`;
            params.push(action);
            paramIndex++;
        }

        if (start_date) {
            whereClause += ` AND cl.timestamp >= $${paramIndex}`;
            params.push(start_date);
            paramIndex++;
        }

        if (end_date) {
            whereClause += ` AND cl.timestamp <= $${paramIndex}`;
            params.push(end_date);
            paramIndex++;
        }

        const countResult = await pool.query(
            `SELECT COUNT(*) FROM connection_logs cl ${whereClause}`,
            params
        );
        const total = parseInt(countResult.rows[0].count);

        const result = await pool.query(`
            SELECT cl.*, u.name as user_name
            FROM connection_logs cl
            LEFT JOIN users u ON cl.user_id = u.id
            ${whereClause}
            ORDER BY cl.timestamp DESC
            LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
        `, [...params, limit, offset]);

        res.json({
            logs: result.rows.map(log => ({
                ...log,
                cpf: log.cpf ? maskCPF(log.cpf) : null
            })),
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                totalPages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao buscar logs');
        res.status(500).json({ error: 'Erro ao buscar logs' });
    }
});

/**
 * GET /api/admin/reports/revenue
 * Relatório de receita
 */
router.get('/reports/revenue', authenticate, authorize('admin', 'manager'), async (req, res) => {
    const pool = getPool();

    try {
        const { period = 'month' } = req.query;

        let interval;
        switch (period) {
            case 'today':
                interval = '1 day';
                break;
            case 'week':
                interval = '7 days';
                break;
            case 'month':
                interval = '30 days';
                break;
            case 'year':
                interval = '365 days';
                break;
            default:
                interval = '30 days';
        }

        const result = await pool.query(`
            SELECT
                DATE(paid_at) as date,
                COUNT(*) as transactions,
                SUM(amount_cents) as revenue,
                AVG(amount_cents) as avg_ticket
            FROM payments
            WHERE status = 'approved'
            AND paid_at >= CURRENT_DATE - INTERVAL '${interval}'
            GROUP BY DATE(paid_at)
            ORDER BY date
        `);

        const totalResult = await pool.query(`
            SELECT
                COUNT(*) as total_transactions,
                COALESCE(SUM(amount_cents), 0) as total_revenue,
                COALESCE(AVG(amount_cents), 0) as avg_ticket
            FROM payments
            WHERE status = 'approved'
            AND paid_at >= CURRENT_DATE - INTERVAL '${interval}'
        `);

        res.json({
            period,
            summary: {
                totalTransactions: parseInt(totalResult.rows[0].total_transactions),
                totalRevenue: parseInt(totalResult.rows[0].total_revenue),
                totalRevenueFormatted: formatMoney(parseInt(totalResult.rows[0].total_revenue)),
                avgTicket: parseInt(totalResult.rows[0].avg_ticket),
                avgTicketFormatted: formatMoney(parseInt(totalResult.rows[0].avg_ticket))
            },
            daily: result.rows.map(r => ({
                date: r.date,
                transactions: parseInt(r.transactions),
                revenue: parseInt(r.revenue),
                revenueFormatted: formatMoney(parseInt(r.revenue)),
                avgTicket: parseInt(r.avg_ticket)
            }))
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao gerar relatório');
        res.status(500).json({ error: 'Erro ao gerar relatório' });
    }
});

/**
 * Formatar valor em centavos para reais
 */
function formatMoney(cents) {
    return `R$ ${(cents / 100).toFixed(2).replace('.', ',')}`;
}

/**
 * Mascarar CPF
 */
function maskCPF(cpf) {
    if (!cpf || cpf.length !== 11) return cpf;
    return `${cpf.substring(0, 3)}.***.***-${cpf.substring(9)}`;
}

module.exports = router;
