/**
 * Sessions Routes
 * Gerenciamento de sessões de acesso
 */

const express = require('express');
const pino = require('pino');
const router = express.Router();

const { getPool } = require('../database/db-manager');
const { authenticate, authorize, validateMacAddress } = require('../middleware/security');
const {
    checkSession,
    getActiveSessions,
    disconnectSession,
    extendSession
} = require('../services/session-manager');
const mikrotik = require('../services/mikrotik');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

/**
 * GET /api/sessions/check
 * Verificar sessão ativa por MAC address
 */
router.get('/check', async (req, res) => {
    try {
        const { mac } = req.query;

        if (!mac) {
            return res.status(400).json({ error: 'MAC address é obrigatório' });
        }

        // Validar formato do MAC
        if (!validateMacAddress(mac)) {
            return res.status(400).json({ error: 'MAC address inválido' });
        }

        const session = await checkSession(mac);

        if (!session) {
            return res.json({
                active: false,
                message: 'Nenhuma sessão ativa encontrada'
            });
        }

        res.json({
            active: true,
            session: {
                id: session.id,
                user_name: session.user_name,
                plan_name: session.plan_name,
                start_time: session.start_time,
                expected_end_time: session.expected_end_time,
                remaining_minutes: session.remaining_minutes,
                remaining_formatted: session.remaining_formatted
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao verificar sessão');
        res.status(500).json({ error: 'Erro ao verificar sessão' });
    }
});

/**
 * GET /api/sessions/active
 * Listar sessões ativas (admin)
 */
router.get('/active', authenticate, authorize('admin', 'manager'), async (req, res) => {
    try {
        const { page = 1, limit = 50 } = req.query;

        const result = await getActiveSessions(parseInt(page), parseInt(limit));

        res.json(result);
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao listar sessões ativas');
        res.status(500).json({ error: 'Erro ao listar sessões' });
    }
});

/**
 * GET /api/sessions/my
 * Sessão ativa do usuário autenticado
 */
router.get('/my', authenticate, async (req, res) => {
    const pool = getPool();

    try {
        const result = await pool.query(`
            SELECT s.*, p.name as plan_name, p.duration_minutes
            FROM sessions s
            JOIN plans p ON s.plan_id = p.id
            WHERE s.user_id = $1 AND s.status = 'active'
            ORDER BY s.start_time DESC
            LIMIT 1
        `, [req.user.id]);

        if (result.rows.length === 0) {
            return res.json({
                active: false,
                message: 'Você não possui sessão ativa'
            });
        }

        const session = result.rows[0];

        // Verificar se expirou
        const now = new Date();
        const endTime = new Date(session.expected_end_time);

        if (endTime < now) {
            await disconnectSession(session.id, 'expired');

            return res.json({
                active: false,
                message: 'Sua sessão expirou'
            });
        }

        const remainingMs = endTime - now;
        const remainingMinutes = Math.floor(remainingMs / 60000);

        // Verificar status no MikroTik
        let mikrotikAuthorized = false;
        try {
            mikrotikAuthorized = await mikrotik.isAuthorized(session.mac_address);
        } catch (mkError) {
            logger.warn({ error: mkError.message }, 'Erro ao verificar autorização MikroTik');
        }

        res.json({
            active: true,
            session: {
                id: session.id,
                plan_name: session.plan_name,
                mac_address: session.mac_address,
                ip_address: session.ip_address,
                start_time: session.start_time,
                expected_end_time: session.expected_end_time,
                remaining_minutes: remainingMinutes,
                remaining_formatted: formatDuration(remainingMinutes),
                mikrotik_synced: session.mikrotik_synced,
                mikrotik_authorized: mikrotikAuthorized,
                status: session.status
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao buscar sessão do usuário');
        res.status(500).json({ error: 'Erro ao buscar sessão' });
    }
});

/**
 * GET /api/sessions/my/connection-status
 * Verificar status de conectividade real
 */
router.get('/my/connection-status', authenticate, async (req, res) => {
    const pool = getPool();

    try {
        // Buscar sessão ativa do usuário
        const result = await pool.query(`
            SELECT s.*, u.active_mac_address
            FROM sessions s
            JOIN users u ON s.user_id = u.id
            WHERE s.user_id = $1 AND s.status = 'active'
            ORDER BY s.start_time DESC
            LIMIT 1
        `, [req.user.id]);

        if (result.rows.length === 0) {
            return res.json({
                connected: false,
                reason: 'no_session',
                message: 'Nenhuma sessão ativa'
            });
        }

        const session = result.rows[0];

        // Verificar se sessão expirou
        const now = new Date();
        const endTime = new Date(session.expected_end_time);
        if (endTime < now) {
            return res.json({
                connected: false,
                reason: 'expired',
                message: 'Sessão expirada'
            });
        }

        // Verificar autorização no MikroTik
        let mikrotikStatus = {
            authorized: false,
            checked: false
        };

        try {
            mikrotikStatus.authorized = await mikrotik.isAuthorized(session.mac_address);
            mikrotikStatus.checked = true;
        } catch (mkError) {
            logger.warn({ error: mkError.message }, 'Erro ao verificar MikroTik');
        }

        const remainingMs = endTime - now;
        const remainingMinutes = Math.floor(remainingMs / 60000);

        res.json({
            connected: mikrotikStatus.authorized || session.mikrotik_synced,
            session_active: true,
            mikrotik: mikrotikStatus,
            session: {
                id: session.id,
                mac_address: session.mac_address,
                ip_address: session.ip_address,
                remaining_minutes: remainingMinutes,
                remaining_formatted: formatDuration(remainingMinutes),
                mikrotik_synced: session.mikrotik_synced
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao verificar status de conexão');
        res.status(500).json({ error: 'Erro ao verificar conexão' });
    }
});

/**
 * GET /api/sessions/:id
 * Detalhes de uma sessão (admin)
 */
router.get('/:id', authenticate, authorize('admin', 'manager'), async (req, res) => {
    const pool = getPool();

    try {
        const { id } = req.params;

        const result = await pool.query(`
            SELECT s.*, p.name as plan_name, p.duration_minutes, p.price_cents,
                   u.name as user_name, u.cpf, u.email
            FROM sessions s
            JOIN plans p ON s.plan_id = p.id
            JOIN users u ON s.user_id = u.id
            WHERE s.id = $1
        `, [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Sessão não encontrada' });
        }

        const session = result.rows[0];

        // Calcular tempo restante se ativa
        let remainingMinutes = 0;
        if (session.status === 'active') {
            const now = new Date();
            const endTime = new Date(session.expected_end_time);
            remainingMinutes = Math.max(0, Math.floor((endTime - now) / 60000));
        }

        res.json({
            session: {
                ...session,
                remaining_minutes: remainingMinutes,
                remaining_formatted: formatDuration(remainingMinutes),
                price_formatted: `R$ ${(session.price_cents / 100).toFixed(2).replace('.', ',')}`
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao buscar sessão');
        res.status(500).json({ error: 'Erro ao buscar sessão' });
    }
});

/**
 * POST /api/sessions/:id/disconnect
 * Desconectar sessão (admin)
 */
router.post('/:id/disconnect', authenticate, authorize('admin'), async (req, res) => {
    try {
        const { id } = req.params;
        const { reason } = req.body;

        const session = await disconnectSession(id, reason || 'admin_action');

        if (!session) {
            return res.status(404).json({ error: 'Sessão não encontrada' });
        }

        logger.info({
            sessionId: id,
            adminId: req.user.id,
            reason
        }, 'Sessão desconectada por admin');

        res.json({
            success: true,
            message: 'Sessão desconectada com sucesso'
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao desconectar sessão');
        res.status(500).json({ error: 'Erro ao desconectar sessão' });
    }
});

/**
 * POST /api/sessions/:id/extend
 * Estender tempo da sessão (admin)
 */
router.post('/:id/extend', authenticate, authorize('admin'), async (req, res) => {
    try {
        const { id } = req.params;
        const { minutes } = req.body;

        if (!minutes || minutes < 1) {
            return res.status(400).json({ error: 'Minutos deve ser maior que 0' });
        }

        const session = await extendSession(id, parseInt(minutes));

        if (!session) {
            return res.status(404).json({ error: 'Sessão não encontrada ou não está ativa' });
        }

        logger.info({
            sessionId: id,
            adminId: req.user.id,
            minutes
        }, 'Sessão estendida por admin');

        res.json({
            success: true,
            message: `Sessão estendida em ${minutes} minutos`,
            new_end_time: session.expected_end_time
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao estender sessão');
        res.status(500).json({ error: 'Erro ao estender sessão' });
    }
});

/**
 * GET /api/sessions/history/:userId
 * Histórico de sessões de um usuário (admin)
 */
router.get('/history/:userId', authenticate, authorize('admin', 'manager'), async (req, res) => {
    const pool = getPool();

    try {
        const { userId } = req.params;
        const { page = 1, limit = 20 } = req.query;
        const offset = (page - 1) * limit;

        const countResult = await pool.query(
            'SELECT COUNT(*) FROM sessions WHERE user_id = $1',
            [userId]
        );
        const total = parseInt(countResult.rows[0].count);

        const result = await pool.query(`
            SELECT s.*, p.name as plan_name
            FROM sessions s
            JOIN plans p ON s.plan_id = p.id
            WHERE s.user_id = $1
            ORDER BY s.start_time DESC
            LIMIT $2 OFFSET $3
        `, [userId, limit, offset]);

        res.json({
            sessions: result.rows,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                totalPages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao buscar histórico');
        res.status(500).json({ error: 'Erro ao buscar histórico' });
    }
});

/**
 * GET /api/sessions/mikrotik/active
 * Usuários ativos no MikroTik Hotspot
 */
router.get('/mikrotik/active', authenticate, authorize('admin'), async (req, res) => {
    try {
        const activeUsers = await mikrotik.getActiveHotspotUsers();

        res.json({
            count: activeUsers.length,
            users: activeUsers
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao buscar usuários do MikroTik');
        res.status(500).json({ error: 'Erro ao buscar usuários ativos no MikroTik' });
    }
});

/**
 * POST /api/sessions/reauthorize
 * Reautorizar sessão (verificar se ainda válida e liberar no MikroTik)
 */
router.post('/reauthorize', async (req, res) => {
    try {
        const { mac_address, ip_address } = req.body;

        if (!mac_address) {
            return res.status(400).json({ error: 'MAC address é obrigatório' });
        }

        // Verificar sessão
        const session = await checkSession(mac_address);

        if (!session) {
            return res.json({
                authorized: false,
                message: 'Nenhuma sessão ativa encontrada'
            });
        }

        // Reautorizar no MikroTik
        try {
            await mikrotik.authorizeUser(mac_address, ip_address || session.ip_address);
        } catch (mkError) {
            logger.warn({ error: mkError.message }, 'Falha ao reautorizar no MikroTik');
        }

        res.json({
            authorized: true,
            session: {
                remaining_minutes: session.remaining_minutes,
                expected_end_time: session.expected_end_time
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao reautorizar');
        res.status(500).json({ error: 'Erro ao reautorizar sessão' });
    }
});

/**
 * Formatar duração
 */
function formatDuration(minutes) {
    if (minutes < 1) return 'Menos de 1 minuto';
    if (minutes < 60) return `${minutes} min`;

    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;

    if (hours < 24) {
        return mins > 0 ? `${hours}h ${mins}min` : `${hours}h`;
    }

    const days = Math.floor(hours / 24);
    const remainingHours = hours % 24;

    return remainingHours > 0 ? `${days}d ${remainingHours}h` : `${days}d`;
}

module.exports = router;
