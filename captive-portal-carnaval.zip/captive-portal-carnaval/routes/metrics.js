/**
 * Metrics Routes
 * Métricas Prometheus e health checks
 */

const express = require('express');
const router = express.Router();

const { getMetrics, getContentType } = require('../services/monitoring');
const { getPool } = require('../database/db-manager');
const { getRedisClient } = require('../services/cache');
const mikrotik = require('../services/mikrotik');

/**
 * GET /api/metrics
 * Métricas Prometheus
 */
router.get('/', async (req, res) => {
    try {
        const metrics = await getMetrics();
        res.set('Content-Type', getContentType());
        res.send(metrics);
    } catch (error) {
        res.status(500).send('Erro ao coletar métricas');
    }
});

/**
 * GET /api/metrics/health
 * Health check detalhado
 */
router.get('/health', async (req, res) => {
    const checks = {
        database: { status: 'unknown', latency: null },
        redis: { status: 'unknown', latency: null },
        mikrotik: { status: 'unknown' }
    };

    // Check PostgreSQL
    try {
        const startDb = Date.now();
        const pool = getPool();
        await pool.query('SELECT 1');
        checks.database.status = 'healthy';
        checks.database.latency = Date.now() - startDb;
    } catch (error) {
        checks.database.status = 'unhealthy';
        checks.database.error = error.message;
    }

    // Check Redis
    try {
        const startRedis = Date.now();
        const redis = getRedisClient();
        await redis.ping();
        checks.redis.status = 'healthy';
        checks.redis.latency = Date.now() - startRedis;
    } catch (error) {
        checks.redis.status = 'unhealthy';
        checks.redis.error = error.message;
    }

    // Check MikroTik
    const mkStatus = mikrotik.getConnectionStatus();
    checks.mikrotik = {
        status: mkStatus.isSimulated ? 'simulated' : (mkStatus.isConnected ? 'healthy' : 'disconnected'),
        host: mkStatus.host
    };

    // Determinar status geral
    const isHealthy = checks.database.status === 'healthy' &&
        checks.redis.status === 'healthy';

    res.status(isHealthy ? 200 : 503).json({
        status: isHealthy ? 'healthy' : 'degraded',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        version: '1.0.0',
        checks
    });
});

/**
 * GET /api/metrics/stats
 * Estatísticas rápidas
 */
router.get('/stats', async (req, res) => {
    try {
        const pool = getPool();

        const [users, sessions, revenue] = await Promise.all([
            pool.query('SELECT COUNT(*) FROM users'),
            pool.query("SELECT COUNT(*) FROM sessions WHERE status = 'active'"),
            pool.query("SELECT COALESCE(SUM(amount_cents), 0) as total FROM payments WHERE status = 'approved'")
        ]);

        res.json({
            users: parseInt(users.rows[0].count),
            activeSessions: parseInt(sessions.rows[0].count),
            revenue: parseInt(revenue.rows[0].total),
            uptime: process.uptime(),
            memory: process.memoryUsage()
        });
    } catch (error) {
        res.status(500).json({ error: 'Erro ao buscar estatísticas' });
    }
});

module.exports = router;
