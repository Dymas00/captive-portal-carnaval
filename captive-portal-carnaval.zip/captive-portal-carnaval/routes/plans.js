/**
 * Plans Routes
 * Gerenciamento de planos de acesso
 */

const express = require('express');
const pino = require('pino');
const router = express.Router();

const { getPool } = require('../database/db-manager');
const { authenticate, authorize } = require('../middleware/security');
const { getCache, setCache } = require('../services/cache');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

/**
 * GET /api/plans
 * Listar planos disponíveis
 */
router.get('/', async (req, res) => {
    try {
        // Tentar cache primeiro
        const cached = await getCache('plans:active');
        if (cached) {
            return res.json({ plans: cached });
        }

        const pool = getPool();

        const result = await pool.query(`
            SELECT id, name, duration_minutes, price_cents, description, speed_limit
            FROM plans
            WHERE active = true
            ORDER BY price_cents ASC
        `);

        const plans = result.rows.map(plan => ({
            id: plan.id,
            name: plan.name,
            duration_minutes: plan.duration_minutes,
            duration_formatted: formatDuration(plan.duration_minutes),
            price_cents: plan.price_cents,
            price_formatted: formatPrice(plan.price_cents),
            description: plan.description,
            speed_limit: plan.speed_limit
        }));

        // Cache por 5 minutos
        await setCache('plans:active', plans, 300);

        res.json({ plans });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao listar planos');
        res.status(500).json({ error: 'Erro ao buscar planos' });
    }
});

/**
 * GET /api/plans/:id
 * Obter detalhes de um plano
 */
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = getPool();

        const result = await pool.query(`
            SELECT id, name, duration_minutes, price_cents, description, speed_limit, active
            FROM plans
            WHERE id = $1
        `, [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Plano não encontrado' });
        }

        const plan = result.rows[0];

        res.json({
            plan: {
                id: plan.id,
                name: plan.name,
                duration_minutes: plan.duration_minutes,
                duration_formatted: formatDuration(plan.duration_minutes),
                price_cents: plan.price_cents,
                price_formatted: formatPrice(plan.price_cents),
                description: plan.description,
                speed_limit: plan.speed_limit,
                active: plan.active
            }
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao buscar plano');
        res.status(500).json({ error: 'Erro ao buscar plano' });
    }
});

/**
 * POST /api/plans
 * Criar novo plano (admin)
 */
router.post('/', authenticate, authorize('admin'), async (req, res) => {
    try {
        const { name, duration_minutes, price_cents, description, speed_limit } = req.body;

        if (!name || !duration_minutes || !price_cents) {
            return res.status(400).json({
                error: 'Nome, duração e preço são obrigatórios'
            });
        }

        const pool = getPool();

        const result = await pool.query(`
            INSERT INTO plans (name, duration_minutes, price_cents, description, speed_limit, active)
            VALUES ($1, $2, $3, $4, $5, true)
            RETURNING *
        `, [name, duration_minutes, price_cents, description || null, speed_limit || null]);

        // Invalidar cache
        await setCache('plans:active', null, 0);

        logger.info({ planId: result.rows[0].id, name }, 'Plano criado');

        res.status(201).json({
            success: true,
            plan: result.rows[0]
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao criar plano');
        res.status(500).json({ error: 'Erro ao criar plano' });
    }
});

/**
 * PUT /api/plans/:id
 * Atualizar plano (admin)
 */
router.put('/:id', authenticate, authorize('admin'), async (req, res) => {
    try {
        const { id } = req.params;
        const { name, duration_minutes, price_cents, description, speed_limit, active } = req.body;

        const pool = getPool();

        // Verificar se existe
        const existing = await pool.query('SELECT id FROM plans WHERE id = $1', [id]);
        if (existing.rows.length === 0) {
            return res.status(404).json({ error: 'Plano não encontrado' });
        }

        const result = await pool.query(`
            UPDATE plans
            SET name = COALESCE($1, name),
                duration_minutes = COALESCE($2, duration_minutes),
                price_cents = COALESCE($3, price_cents),
                description = COALESCE($4, description),
                speed_limit = COALESCE($5, speed_limit),
                active = COALESCE($6, active)
            WHERE id = $7
            RETURNING *
        `, [name, duration_minutes, price_cents, description, speed_limit, active, id]);

        // Invalidar cache
        await setCache('plans:active', null, 0);

        logger.info({ planId: id }, 'Plano atualizado');

        res.json({
            success: true,
            plan: result.rows[0]
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao atualizar plano');
        res.status(500).json({ error: 'Erro ao atualizar plano' });
    }
});

/**
 * DELETE /api/plans/:id
 * Desativar plano (admin)
 */
router.delete('/:id', authenticate, authorize('admin'), async (req, res) => {
    try {
        const { id } = req.params;
        const pool = getPool();

        // Soft delete - apenas desativar
        const result = await pool.query(`
            UPDATE plans SET active = false WHERE id = $1 RETURNING id
        `, [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Plano não encontrado' });
        }

        // Invalidar cache
        await setCache('plans:active', null, 0);

        logger.info({ planId: id }, 'Plano desativado');

        res.json({
            success: true,
            message: 'Plano desativado com sucesso'
        });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao desativar plano');
        res.status(500).json({ error: 'Erro ao desativar plano' });
    }
});

/**
 * GET /api/plans/admin/all
 * Listar todos os planos (admin)
 */
router.get('/admin/all', authenticate, authorize('admin', 'manager'), async (req, res) => {
    try {
        const pool = getPool();

        const result = await pool.query(`
            SELECT id, name, duration_minutes, price_cents, description, speed_limit, active, created_at
            FROM plans
            ORDER BY created_at DESC
        `);

        const plans = result.rows.map(plan => ({
            ...plan,
            duration_formatted: formatDuration(plan.duration_minutes),
            price_formatted: formatPrice(plan.price_cents)
        }));

        res.json({ plans });
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao listar planos');
        res.status(500).json({ error: 'Erro ao buscar planos' });
    }
});

/**
 * Formatar duração em minutos
 */
function formatDuration(minutes) {
    if (minutes < 60) {
        return `${minutes} minutos`;
    }

    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;

    if (hours < 24) {
        return mins > 0 ? `${hours}h ${mins}min` : `${hours} hora${hours > 1 ? 's' : ''}`;
    }

    const days = Math.floor(hours / 24);
    const remainingHours = hours % 24;

    if (days === 1) {
        return remainingHours > 0 ? `1 dia e ${remainingHours}h` : '24 horas';
    }

    return `${days} dias`;
}

/**
 * Formatar preço em centavos
 */
function formatPrice(cents) {
    return `R$ ${(cents / 100).toFixed(2).replace('.', ',')}`;
}

module.exports = router;
