# 🚀 GUIA DE DEPLOY - CAPTIVE PORTAL CARNAVAL DE RECIFE

Este guia explica como fazer o deploy completo do sistema com certificado SSL válido.

---

## 📋 PRÉ-REQUISITOS

### 1. Servidor Ubuntu/Debian
- Ubuntu 20.04 LTS ou superior
- Debian 10 ou superior
- Acesso root (sudo)

### 2. Domínio Configurado
**IMPORTANTE:** Você PRECISA ter um domínio apontando para o IP do servidor!

**Como configurar:**
1. Registre um domínio (ex: captive.seudominio.com)
2. No painel do seu provedor de domínio (GoDaddy, Hostgator, etc):
   - Crie um registro **A** apontando para o IP público do servidor
   - Exemplo:
     ```
     Tipo: A
     Nome: captive
     Valor: 206.42.50.83
     TTL: 3600
     ```
3. Aguarde propagação DNS (pode levar até 24h, geralmente 5-10 minutos)

**Verificar se o DNS propagou:**
```bash
nslookup captive.seudominio.com
# Deve retornar o IP do seu servidor
```

### 3. Portas Liberadas no Firewall/Router
- Porta **80** (HTTP) - Para geração do certificado SSL
- Porta **443** (HTTPS) - Para o portal e webhook

### 4. Informações Necessárias
Tenha em mãos:
- ✅ Domínio configurado (ex: captive.seudominio.com)
- ✅ Email para notificações SSL
- ✅ IP público do servidor
- ✅ API Key do AbacatePay
- ✅ Webhook Secret do AbacatePay
- ✅ IP do roteador MikroTik
- ✅ Usuário e senha do MikroTik

---

## 🎯 EXECUTANDO O DEPLOY

### Passo 1: Fazer Upload do Projeto

```bash
# No seu servidor Ubuntu/Debian
cd /opt
sudo git clone <URL_DO_REPOSITORIO> captive-portal
cd captive-portal
```

### Passo 2: Dar Permissão ao Script

```bash
sudo chmod +x scripts/deploy.sh
```

### Passo 3: Executar Deploy

```bash
sudo ./scripts/deploy.sh
```

O script irá solicitar as seguintes informações:

```
═══ CONFIGURAÇÃO DO DOMÍNIO E SSL ═══
Digite o domínio para o certificado SSL: captive.seudominio.com
Digite o email para notificações do Let's Encrypt: admin@seudominio.com
Digite o IP público do servidor: 206.42.50.83

═══ CONFIGURAÇÃO DO ABACATEPAY ═══
Digite a API Key do AbacatePay: abc_dev_XXXXXXXXXX
Digite o Webhook Secret do AbacatePay: seu_secret_123

═══ CONFIGURAÇÃO DO MIKROTIK ═══
Digite o IP do roteador MikroTik: 192.168.10.1
Digite o usuário do MikroTik: admin
Digite a senha do MikroTik: ******
```

---

## ✅ O QUE O SCRIPT FAZ AUTOMATICAMENTE

### 1. Instala Dependências
- ✅ Docker e Docker Compose
- ✅ Certbot (Let's Encrypt)
- ✅ Todas as bibliotecas necessárias

### 2. Gera Certificado SSL Válido
- ✅ Certificado Let's Encrypt para o domínio
- ✅ Válido por 90 dias
- ✅ Renovação automática configurada (diariamente às 2AM)

### 3. Configura o Sistema
- ✅ Cria arquivo `.env` com todas as variáveis
- ✅ Gera secrets seguros (JWT, Session, DB Password)
- ✅ Configura URL do webhook com HTTPS

### 4. Faz Deploy dos Containers
- ✅ PostgreSQL (banco de dados)
- ✅ Redis (cache)
- ✅ Nginx (proxy reverso com SSL)
- ✅ Aplicação Node.js
- ✅ Prometheus e Grafana (opcional)

### 5. Configura Firewall
- ✅ Libera portas 80 e 443
- ✅ Configura UFW se disponível

---

## 🔧 CONFIGURAÇÃO PÓS-DEPLOY

### 1. Configurar Webhook no AbacatePay

Após o deploy, você verá a URL do webhook. Configure no painel do AbacatePay:

```
URL: https://captive.seudominio.com/api/webhooks/abacatepay
Secret: (o secret que você informou no deploy)
```

**Passos:**
1. Acesse https://dashboard.abacatepay.com
2. Vá em **Configurações** → **Webhooks**
3. Cole a URL mostrada no final do deploy
4. Cole o secret
5. Salve

### 2. Configurar MikroTik

Execute o script de configuração do MikroTik:

```bash
# No servidor
cat scripts/mikrotik-setup.rsc
```

Copie o conteúdo e execute no terminal do MikroTik.

### 3. Acessar o Portal

- **Portal (usuários):** https://captive.seudominio.com
- **Admin:** https://captive.seudominio.com/admin-login
  - CPF: 11111111111
  - Senha: Admin@Carnaval2026!

---

## 📊 VERIFICAÇÃO DO DEPLOY

### Verificar Containers

```bash
docker compose ps
```

Todos devem estar **healthy**.

### Verificar Logs

```bash
# Logs da aplicação
docker compose logs -f app

# Logs do nginx
docker compose logs -f nginx

# Logs do PostgreSQL
docker compose logs -f postgres
```

### Testar Webhook

```bash
curl -X POST https://captive.seudominio.com/api/webhooks/abacatepay \
  -H "Content-Type: application/json" \
  -d '{
    "event": "billing.paid",
    "data": {
      "pixQrCode": {
        "id": "test_123",
        "amount": 500,
        "status": "PAID"
      }
    }
  }'
```

### Verificar Certificado SSL

```bash
openssl s_client -connect captive.seudominio.com:443 -servername captive.seudominio.com
```

Deve mostrar:
- Issuer: Let's Encrypt
- Verify return code: 0 (ok)

---

## 🔄 RENOVAÇÃO AUTOMÁTICA DE CERTIFICADO

O script configura renovação automática do certificado SSL:

- **Frequência:** Diária às 2AM
- **Localização:** `/etc/cron.d/certbot-renew`
- **Ação:** Renova certificado + copia para nginx + reinicia nginx

**Verificar renovação manual:**
```bash
sudo certbot renew --dry-run
```

---

## ⚠️ TROUBLESHOOTING

### Problema: "Certificado SSL não foi gerado"

**Causa:** Domínio não está apontando para o servidor

**Solução:**
```bash
# Verificar DNS
nslookg captive.seudominio.com

# Se não resolver, aguarde propagação DNS
# Depois execute novamente o deploy
```

### Problema: "Porta 80 já está em uso"

**Causa:** Outro serviço usando porta 80

**Solução:**
```bash
# Parar serviço conflitante
sudo systemctl stop apache2  # Se for Apache
sudo systemctl stop nginx     # Se for Nginx

# Executar deploy novamente
```

### Problema: "Webhook retorna erro 'self signed certificate'"

**Causa:** Certificado SSL não foi gerado corretamente

**Solução:**
```bash
# Verificar certificado
ls -la /etc/letsencrypt/live/captive.seudominio.com/

# Se não existir, gerar manualmente
sudo certbot certonly --standalone -d captive.seudominio.com

# Copiar certificados
sudo cp /etc/letsencrypt/live/captive.seudominio.com/fullchain.pem nginx/ssl/server.crt
sudo cp /etc/letsencrypt/live/captive.seudominio.com/privkey.pem nginx/ssl/server.key

# Reiniciar nginx
docker compose restart nginx
```

---

## 📝 COMANDOS ÚTEIS

### Gerenciamento de Containers

```bash
# Ver logs em tempo real
docker compose logs -f app

# Reiniciar todos os containers
docker compose restart

# Parar tudo
docker compose down

# Atualizar após mudanças no código
docker compose build && docker compose up -d

# Ver uso de recursos
docker stats
```

### Gerenciamento de Certificados

```bash
# Listar certificados
sudo certbot certificates

# Renovar manualmente
sudo certbot renew

# Revogar certificado
sudo certbot revoke --cert-path /etc/letsencrypt/live/captive.seudominio.com/cert.pem
```

### Backup

```bash
# Backup do banco de dados
docker compose exec postgres pg_dump -U captive captive_portal > backup.sql

# Backup dos volumes
docker run --rm -v captive-portal-carnaval_postgres_data:/data -v $(pwd):/backup ubuntu tar czf /backup/postgres-backup.tar.gz /data
```

---

## 🎉 SUCESSO!

Se tudo correu bem, você deve ver:

```
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   ✅ DEPLOY CONCLUÍDO COM SUCESSO!                       ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝

═══ URLs DE ACESSO ═══
   🌐 Portal HTTP:  http://206.42.50.83
   🔒 Portal HTTPS: https://captive.seudominio.com
   👤 Admin:        https://captive.seudominio.com/admin-login
   💚 Health Check: https://captive.seudominio.com/health

═══ WEBHOOK ABACATEPAY ═══
   Configure esta URL no painel do AbacatePay:
   📍 https://captive.seudominio.com/api/webhooks/abacatepay
```

**O sistema está pronto para receber usuários!** 🎭🎉
