# 🖥️ REQUISITOS DE SERVIDOR - CAPTIVE PORTAL CARNAVAL

Especificações de hardware e configuração para suportar **4.000+ usuários simultâneos**.

---

## 📊 ESTIMATIVAS DE CARGA

### Cenário: 4.000 Usuários Simultâneos

- **Usuários ativos:** 4.000
- **Requisições por segundo (RPS):** ~500-1000 RPS
- **Banda:** ~100-200 Mbps
- **Conexões simultâneas:** ~5.000-8.000
- **Sessões de banco de dados:** ~200-500
- **Memória Redis:** ~2-4 GB
- **Armazenamento de logs:** ~10-50 GB/dia

---

## 💻 OPÇÕES DE SERVIDOR

### OPÇÃO 1: SERVIDOR DEDICADO (RECOMENDADO)

#### Especificação Mínima para 4.000 usuários:

**CPU:**
- 8 cores / 16 threads
- Recomendado: Intel Xeon E-2288G ou AMD EPYC 7302P
- Clock: 3.0 GHz+

**RAM:**
- Mínimo: 16 GB DDR4
- Recomendado: 32 GB DDR4
- Ideal: 64 GB DDR4 (para cache e buffer)

**Armazenamento:**
- SSD NVMe: 500 GB+
- IOPS: 10.000+
- Recomendado: RAID 1 ou RAID 10 para redundância

**Rede:**
- 1 Gbps dedicado
- Ideal: 10 Gbps se disponível
- Latência: < 5ms

**Sistema Operacional:**
- Ubuntu Server 22.04 LTS
- Debian 11 (Bullseye)
- CentOS Stream 9

#### Exemplos de Servidores:

**OVH / SoYouStart:**
- **Advance-2 SATA** - €69/mês
  - Intel Xeon E-2288G (8c/16t)
  - 32 GB DDR4 ECC
  - 2x 2TB SATA (RAID 1)
  - 1 Gbps

**Hetzner:**
- **AX102** - €99/mês
  - AMD Ryzen 9 5950X (16c/32t)
  - 64 GB DDR4
  - 2x 3.84 TB NVMe (RAID 1)
  - 1 Gbps

**DigitalOcean (Dedicated CPU):**
- **CPU-Optimized 16 vCPU** - $240/mês
  - 16 vCPUs
  - 32 GB RAM
  - 200 GB SSD
  - 6 TB bandwidth

---

### OPÇÃO 2: VPS DE ALTA PERFORMANCE

#### Especificação Mínima:

**vCPU:** 8 cores dedicados
**RAM:** 16 GB
**Armazenamento:** 200 GB SSD
**Banda:** 10 TB/mês

#### Exemplos de Provedores:

**Vultr (High Frequency):**
- **8 vCore, 16 GB RAM** - $96/mês
  - 8 vCPUs @ 3+ GHz
  - 16 GB RAM
  - 250 GB NVMe
  - 5 TB bandwidth

**Linode (Dedicated CPU):**
- **8 vCPU, 16 GB RAM** - $120/mês
  - 8 vCPUs
  - 16 GB RAM
  - 320 GB SSD
  - 8 TB bandwidth

**AWS EC2:**
- **c6a.2xlarge** - ~$250/mês
  - 8 vCPUs (AMD EPYC)
  - 16 GB RAM
  - Network optimized

---

### OPÇÃO 3: CLUSTER (Para 10.000+ usuários)

Para cargas extremas, utilize um cluster:

#### Configuração Recomendada:

**Load Balancer:**
- Nginx ou HAProxy
- 2 vCPUs, 4 GB RAM

**Application Servers (3x):**
- 4 vCPUs, 8 GB RAM cada
- Node.js + Redis local

**Database Server (Primary + Replica):**
- 8 vCPUs, 32 GB RAM
- PostgreSQL 15
- SSD NVMe RAID 10

**Redis Cluster (3 nodes):**
- 4 vCPUs, 16 GB RAM cada
- Redis 7

**Custo estimado:** $800-1200/mês

---

## ⚙️ CONFIGURAÇÕES DE SOFTWARE

### 1. Sistema Operacional

#### Limites de Arquivo (File Descriptors)

```bash
# /etc/security/limits.conf
* soft nofile 65535
* hard nofile 65535
* soft nproc 65535
* hard nproc 65535
```

#### Parâmetros do Kernel

```bash
# /etc/sysctl.conf
net.core.somaxconn = 65535
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 30
net.core.netdev_max_backlog = 5000
vm.swappiness = 10
```

Aplicar:
```bash
sudo sysctl -p
```

---

### 2. PostgreSQL

#### Configuração para 4.000 usuários (`postgresql.conf`)

```ini
# Conexões
max_connections = 500
shared_buffers = 8GB         # 25% da RAM
effective_cache_size = 24GB  # 75% da RAM
work_mem = 16MB
maintenance_work_mem = 2GB

# Checkpoint
checkpoint_completion_target = 0.9
wal_buffers = 16MB
default_statistics_target = 100

# Parallel queries
max_worker_processes = 8
max_parallel_workers_per_gather = 4
max_parallel_workers = 8

# WAL
wal_level = replica
max_wal_size = 4GB
min_wal_size = 1GB

# Logging
log_min_duration_statement = 1000
log_line_prefix = '%t [%p]: [%l-1] user=%u,db=%d,app=%a,client=%h '
log_checkpoints = on
log_connections = on
log_disconnections = on
log_lock_waits = on
```

#### Pool de Conexões (PgBouncer)

```ini
# /etc/pgbouncer/pgbouncer.ini
[databases]
captive_portal = host=127.0.0.1 port=5432 dbname=captive_portal

[pgbouncer]
listen_addr = 127.0.0.1
listen_port = 6432
auth_type = md5
auth_file = /etc/pgbouncer/userlist.txt
pool_mode = transaction
max_client_conn = 10000
default_pool_size = 100
reserve_pool_size = 25
```

---

### 3. Redis

#### Configuração (`redis.conf`)

```conf
# Memória
maxmemory 8gb
maxmemory-policy allkeys-lru

# Persistência (desabilitar para melhor performance)
save ""
appendonly no

# Network
tcp-backlog 511
timeout 0
tcp-keepalive 300

# Threads
io-threads 4
io-threads-do-reads yes

# Limits
maxclients 10000
```

---

### 4. Nginx

#### Configuração de Performance

```nginx
# nginx.conf
user nginx;
worker_processes auto;
worker_rlimit_nofile 65535;

events {
    worker_connections 10000;
    use epoll;
    multi_accept on;
}

http {
    # Buffers
    client_body_buffer_size 128k;
    client_max_body_size 10m;
    client_header_buffer_size 1k;
    large_client_header_buffers 4 16k;
    output_buffers 1 32k;
    postpone_output 1460;

    # Timeouts
    client_header_timeout 30s;
    client_body_timeout 30s;
    keepalive_timeout 65s;
    send_timeout 30s;

    # Gzip
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript
               application/json application/javascript application/xml+rss;

    # Cache
    open_file_cache max=10000 inactive=30s;
    open_file_cache_valid 60s;
    open_file_cache_min_uses 2;
    open_file_cache_errors on;

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=general:10m rate=100r/s;
    limit_req zone=general burst=200 nodelay;

    # Connection limiting
    limit_conn_zone $binary_remote_addr zone=addr:10m;
    limit_conn addr 50;
}
```

---

### 5. Node.js / PM2

#### Configuração PM2 (`ecosystem.config.js`)

```javascript
module.exports = {
    apps: [{
        name: 'captive-portal',
        script: './server.js',
        instances: 'max',  // Usa todos os cores disponíveis
        exec_mode: 'cluster',
        max_memory_restart: '2G',
        env: {
            NODE_ENV: 'production',
            PORT: 3000,
        },
        node_args: [
            '--max-old-space-size=2048',
            '--optimize-for-size',
        ],
        error_file: './logs/pm2-error.log',
        out_file: './logs/pm2-out.log',
        log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
        merge_logs: true,
        autorestart: true,
        watch: false,
    }]
};
```

Iniciar:
```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

---

### 6. Docker (Alternativo)

#### Configurações para Produção (`docker-compose.yml`)

```yaml
services:
  app:
    deploy:
      replicas: 4  # 4 instâncias da aplicação
      resources:
        limits:
          cpus: '2'
          memory: 2G
        reservations:
          cpus: '1'
          memory: 1G

  postgres:
    deploy:
      resources:
        limits:
          cpus: '4'
          memory: 16G
        reservations:
          cpus: '2'
          memory: 8G
    command: postgres -c max_connections=500 -c shared_buffers=8GB

  redis:
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 8G
        reservations:
          cpus: '1'
          memory: 4G
    command: redis-server --maxmemory 8gb --maxmemory-policy allkeys-lru

  nginx:
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 1G
```

---

## 📈 MONITORAMENTO

### Ferramentas Recomendadas:

1. **Prometheus + Grafana** (incluído no projeto)
   ```bash
   docker compose --profile monitoring up -d
   ```
   - Dashboard: http://localhost:3001
   - Usuário: admin
   - Senha: GrafanaAdmin2026!

2. **htop** - Monitoramento de recursos
   ```bash
   sudo apt install htop
   htop
   ```

3. **pgAdmin 4** - Gerenciamento PostgreSQL
   ```bash
   docker run -p 5050:80 -e 'PGADMIN_DEFAULT_EMAIL=admin@admin.com' \
     -e 'PGADMIN_DEFAULT_PASSWORD=admin' dpage/pgadmin4
   ```

4. **Redis Commander**
   ```bash
   docker run -p 8081:8081 -e REDIS_HOSTS=local:redis:6379 \
     rediscommander/redis-commander
   ```

---

## 🔧 OTIMIZAÇÕES ADICIONAIS

### 1. CDN para Arquivos Estáticos

Use Cloudflare, AWS CloudFront ou Bunny CDN para servir:
- CSS, JavaScript
- Imagens
- Fontes

**Redução de carga:** 30-50%

### 2. Cache de API

Implemente cache Redis para endpoints frequentes:
```javascript
// Cache de planos por 5 minutos
const cachedPlans = await redis.get('plans:all');
if (cachedPlans) return JSON.parse(cachedPlans);
```

### 3. Database Read Replicas

Configure réplicas de leitura do PostgreSQL:
- Escrita: Primary
- Leitura: Réplicas (2-3)

### 4. Sessão Sticky (Load Balancer)

Configure sticky sessions no load balancer:
```nginx
upstream backend {
    ip_hash;
    server app1:3000;
    server app2:3000;
    server app3:3000;
}
```

---

## 💰 RESUMO DE CUSTOS MENSAIS

| Configuração | Capacidade | Custo/Mês | Provedor |
|--------------|------------|-----------|----------|
| VPS Básico | 500 usuários | $40 | Vultr, Linode |
| VPS Médio | 2.000 usuários | $96 | Vultr HF |
| **VPS Alta Performance** | **4.000 usuários** | **$120-240** | **Linode, OVH** |
| Servidor Dedicado | 10.000+ usuários | $99-300 | Hetzner, OVH |
| Cluster AWS | 20.000+ usuários | $800-1200 | AWS, GCP |

---

## ✅ CHECKLIST DE PREPARAÇÃO

Antes do lançamento:

- [ ] Servidor com specs mínimas
- [ ] PostgreSQL configurado e otimizado
- [ ] Redis configurado com maxmemory
- [ ] Nginx com rate limiting
- [ ] SSL/TLS configurado (Let's Encrypt)
- [ ] Backups automáticos configurados
- [ ] Monitoramento instalado (Prometheus + Grafana)
- [ ] Logs centralizados
- [ ] Alertas configurados
- [ ] Teste de carga executado com sucesso
- [ ] Plano de disaster recovery documentado
- [ ] Equipe treinada

---

## 🚨 TROUBLESHOOTING COMUM

### Alta latência (> 5s)

**Causas:**
- CPU saturada (> 80%)
- RAM insuficiente (swap ativo)
- Disco lento (IOPS baixo)
- PostgreSQL sem índices

**Soluções:**
1. Upgrade de CPU/RAM
2. Adicionar índices no banco
3. Implementar cache Redis
4. Usar SSD NVMe

### Conexões rejeitadas

**Causas:**
- max_connections atingido (PostgreSQL)
- worker_connections atingido (Nginx)
- file descriptors esgotados

**Soluções:**
1. Aumentar max_connections
2. Configurar PgBouncer
3. Aumentar file descriptors

### Out of Memory (OOM)

**Causas:**
- Node.js sem limite de heap
- PostgreSQL shared_buffers muito alto
- Redis sem maxmemory

**Soluções:**
1. Limitar heap do Node.js (--max-old-space-size)
2. Ajustar shared_buffers PostgreSQL
3. Configurar maxmemory Redis
4. Adicionar mais RAM

---

## 📞 SUPORTE

Para dimensionamento personalizado ou dúvidas:
- Consulte a documentação oficial do PostgreSQL
- PostgreSQL Performance Tuning: https://wiki.postgresql.org/wiki/Performance_Optimization
- Node.js Best Practices: https://github.com/goldbergyoni/nodebestpractices

---

**Última atualização:** Janeiro 2026
**Versão do documento:** 1.0
