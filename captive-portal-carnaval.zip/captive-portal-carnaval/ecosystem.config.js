/**
 * PM2 Ecosystem Configuration
 * Para rodar em modo cluster com múltiplas instâncias
 */

module.exports = {
    apps: [
        {
            name: 'captive-portal-carnaval',
            script: 'server.js',
            instances: 'max', // Usar todos os CPUs disponíveis
            exec_mode: 'cluster',
            watch: false,
            max_memory_restart: '500M',

            // Environment Variables
            env: {
                NODE_ENV: 'development',
                PORT: 3000
            },
            env_production: {
                NODE_ENV: 'production',
                PORT: 3000
            },

            // Logs
            log_file: './logs/combined.log',
            out_file: './logs/out.log',
            error_file: './logs/error.log',
            log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
            merge_logs: true,

            // Graceful shutdown
            kill_timeout: 5000,
            wait_ready: true,
            listen_timeout: 10000,

            // Auto restart
            autorestart: true,
            max_restarts: 10,
            min_uptime: '10s',

            // Exponential backoff restart delay
            exp_backoff_restart_delay: 100
        }
    ]
};
