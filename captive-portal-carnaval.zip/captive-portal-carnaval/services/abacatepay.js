/**
 * Gateway de Pagamento - AbacatePay
 * https://docs.abacatepay.com/
 * Taxa fixa de R$ 0,80 por transação
 */

const axios = require('axios');
const QRCode = require('qrcode');
const PaymentGatewayBase = require('./payment-gateway-base');

class AbacatePayGateway extends PaymentGatewayBase {
  constructor(config) {
    super(config);
    this.name = 'abacatepay';
    this.friendlyName = 'AbacatePay';
    this.enabled = config.enabled || false;
    this.apiUrl = 'https://api.abacatepay.com/v1';
  }

  validateConfig() {
    return !!(this.config.apiKey);
  }

  /**
   * Valida e formata CPF
   * @param {string} cpf - CPF com ou sem formatação
   * @returns {string|null} CPF apenas com números ou null se inválido
   */
  validateAndFormatCPF(cpf) {
    if (!cpf) return null;

    // Remove caracteres não numéricos
    const cleanCPF = cpf.replace(/\D/g, '');

    // Verifica se tem 11 dígitos
    if (cleanCPF.length !== 11) return null;

    // Verifica se todos os dígitos são iguais (CPF inválido)
    if (/^(\d)\1{10}$/.test(cleanCPF)) return null;

    // Validação do primeiro dígito verificador
    let sum = 0;
    for (let i = 0; i < 9; i++) {
      sum += parseInt(cleanCPF[i]) * (10 - i);
    }
    let remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cleanCPF[9])) return null;

    // Validação do segundo dígito verificador
    sum = 0;
    for (let i = 0; i < 10; i++) {
      sum += parseInt(cleanCPF[i]) * (11 - i);
    }
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cleanCPF[10])) return null;

    return cleanCPF;
  }

  async createPixPayment(data) {
    if (!this.isEnabled()) {
      throw new Error('AbacatePay não está configurado');
    }

    try {
      console.log('🥑 Criando pagamento via AbacatePay');

      // Validar CPF
      const validCPF = this.validateAndFormatCPF(data.payer?.cpf);
      if (!validCPF) {
        console.error('❌ CPF inválido:', data.payer?.cpf);
        throw new Error('CPF inválido ou não informado. Por favor, verifique seus dados cadastrais.');
      }

      console.log('🥑 CPF validado:', validCPF.substring(0, 3) + '***' + validCPF.substring(9));


      // Payload conforme documentação oficial AbacatePay
      // https://docs.abacatepay.com/pages/pix-qrcode/create
      const payload = {
        amount: data.amount, // valor em centavos
        expiresIn: 3600, // 1 hora em segundos
        description: data.description || 'Wi-Fi Captive Portal - Carnaval de Recife',
        customer: {
          name: data.payer.name || 'Cliente',
          cellphone: data.payer.phone || '(00) 00000-0000',
          email: data.payer.email || 'cliente@example.com',
          taxId: validCPF
        },
        metadata: {
          externalId: String((data.userId || 'user') + '-' + Date.now())
        }
      };

      console.log('🥑 Payload enviado:', JSON.stringify(payload, null, 2));

      const response = await axios.post(`${this.apiUrl}/pixQrCode/create`, payload, {
        headers: {
          'Authorization': `Bearer ${this.config.apiKey}`,
          'Content-Type': 'application/json'
        }
      });

      console.log('🥑 Response AbacatePay:', JSON.stringify(response.data, null, 2));

      if (response.data.error && response.data.error !== '<unknown>') {
        throw new Error(response.data.error.message || response.data.error || 'Erro ao criar pagamento');
      }

      const pixData = response.data.data;

      if (!pixData) {
        throw new Error('Resposta inválida da API AbacatePay');
      }

      // Usar o QR Code base64 da API se disponível, senão gerar manualmente
      let qrCodeBase64 = null;
      if (pixData.brCodeBase64) {
        // A API retorna com prefixo "data:image/png;base64,", remover se presente
        qrCodeBase64 = pixData.brCodeBase64.replace(/^data:image\/png;base64,/, '');
        console.log('🥑 QR Code recebido da API');
      } else if (pixData.brCode) {
        // Gerar QR Code manualmente se a API não retornou
        try {
          const qrCodeDataUrl = await QRCode.toDataURL(pixData.brCode, {
            width: 300,
            margin: 2,
            color: {
              dark: '#000000',
              light: '#FFFFFF'
            }
          });
          qrCodeBase64 = qrCodeDataUrl.replace(/^data:image\/png;base64,/, '');
          console.log('🥑 QR Code gerado localmente');
        } catch (qrError) {
          console.error('⚠️ Erro ao gerar QR Code:', qrError.message);
        }
      }

      return {
        gateway: this.name,
        paymentId: pixData.id,
        status: this.mapStatus(pixData.status),
        amount: data.amount,
        qrCode: pixData.brCode,
        qrCodeBase64: qrCodeBase64,
        pixKey: pixData.brCode, // brCode é o código copia e cola do PIX
        expiresAt: pixData.expiresAt || new Date(Date.now() + 3600000).toISOString(),
        createdAt: pixData.createdAt || new Date().toISOString(),
        raw: pixData
      };
    } catch (error) {
      console.error('❌ Erro AbacatePay:', error.response?.data || error.message);

      // Tratar erro específico de taxId inválido
      const errorData = error.response?.data;
      if (errorData?.error === 'Invalid taxId') {
        throw new Error('CPF inválido ou não cadastrado na Receita Federal. Use um CPF real para pagamentos.');
      }

      throw new Error(`Erro ao criar pagamento Pix: ${errorData?.error?.message || errorData?.error || error.message}`);
    }
  }

  async getPaymentStatus(paymentId) {
    if (!this.isEnabled()) {
      throw new Error('AbacatePay não está configurado');
    }

    try {
      const response = await axios.get(`${this.apiUrl}/pixQrCode/check`, {
        params: { id: paymentId },
        headers: {
          'Authorization': `Bearer ${this.config.apiKey}`
        }
      });

      if (response.data.error) {
        throw new Error(response.data.error.message || 'Erro ao consultar pagamento');
      }

      const pixData = response.data.data;

      return {
        gateway: this.name,
        paymentId: pixData.id,
        status: this.mapStatus(pixData.status),
        amount: pixData.amount,
        paidAt: pixData.paidAt || null,
        raw: pixData
      };
    } catch (error) {
      console.error('❌ Erro ao consultar pagamento AbacatePay:', error.response?.data || error.message);
      throw new Error('Erro ao consultar status do pagamento');
    }
  }

  async processWebhook(body, headers) {
    // AbacatePay envia evento no body
    // Eventos: billing.paid, billing.expired, etc.
    if (body.event === 'billing.paid' || body.event === 'BILLING_PAID') {
      const billingData = body.data || body.billing;

      return {
        gateway: this.name,
        paymentId: billingData?.id || body.id,
        status: 'approved',
        amount: billingData?.amount || body.amount,
        paidAt: new Date().toISOString(),
        raw: body
      };
    }

    return null;
  }

  validateWebhookSignature(body, headers, query) {
    // AbacatePay usa webhookSecret como query parameter
    const webhookSecret = query?.webhookSecret;

    if (!this.config.webhookSecret) {
      // Se não configurou secret, aceita qualquer request
      return true;
    }

    return webhookSecret === this.config.webhookSecret;
  }

  mapStatus(abacateStatus) {
    const statusMap = {
      'PENDING': 'pending',
      'pending': 'pending',
      'PAID': 'approved',
      'paid': 'approved',
      'EXPIRED': 'cancelled',
      'expired': 'cancelled',
      'CANCELLED': 'cancelled',
      'cancelled': 'cancelled',
      'REFUNDED': 'refunded',
      'refunded': 'refunded'
    };

    return statusMap[abacateStatus] || 'pending';
  }

  getFee() {
    // AbacatePay cobra taxa fixa de R$ 0,80 por transação
    return this.config.fee || 0.80;
  }

  // AbacatePay usa taxa fixa, não percentual
  calculateFee(amountCents) {
    // Taxa fixa de R$ 0,80 = 80 centavos
    return this.config.fixedFee || 80;
  }

  getFriendlyName() {
    return this.friendlyName;
  }

  // Simular pagamento (apenas em modo desenvolvimento)
  async simulatePayment(paymentId) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('Simulação de pagamento não permitida em produção');
    }

    try {
      const response = await axios.post(`${this.apiUrl}/pixQrCode/simulate-payment`,
        { id: paymentId },
        {
          headers: {
            'Authorization': `Bearer ${this.config.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return response.data;
    } catch (error) {
      console.error('❌ Erro ao simular pagamento:', error.response?.data || error.message);
      throw new Error('Erro ao simular pagamento');
    }
  }
}

// Criar e exportar instância singleton do gateway
const abacatePayInstance = new AbacatePayGateway({
  apiKey: process.env.ABACATEPAY_API_KEY,
  webhookSecret: process.env.ABACATEPAY_WEBHOOK_SECRET,
  enabled: process.env.ABACATEPAY_ENABLED !== 'false',
  fee: parseFloat(process.env.ABACATEPAY_FEE || '0'),
  fixedFee: parseInt(process.env.ABACATEPAY_FIXED_FEE || '80')
});

// Exportar tanto a classe quanto a instância
module.exports = abacatePayInstance;
module.exports.AbacatePayGateway = AbacatePayGateway;
