/**
 * Base para Gateways de Pagamento
 *
 * Interface padrão que todos os gateways devem implementar
 */

class PaymentGatewayBase {
  constructor(config) {
    this.config = config;
    this.name = 'base';
    this.enabled = false;
  }

  /**
   * Validar configuração do gateway
   */
  validateConfig() {
    throw new Error('validateConfig() deve ser implementado');
  }

  /**
   * Criar pagamento Pix
   * @param {Object} data - Dados do pagamento
   * @param {number} data.amount - Valor em centavos
   * @param {string} data.description - Descrição
   * @param {Object} data.payer - Dados do pagador
   * @returns {Promise<Object>} - Dados do pagamento criado
   */
  async createPixPayment(data) {
    throw new Error('createPixPayment() deve ser implementado');
  }

  /**
   * Consultar status de pagamento
   * @param {string} paymentId - ID do pagamento
   * @returns {Promise<Object>} - Status do pagamento
   */
  async getPaymentStatus(paymentId) {
    throw new Error('getPaymentStatus() deve ser implementado');
  }

  /**
   * Processar webhook
   * @param {Object} body - Corpo da requisição
   * @param {Object} headers - Headers da requisição
   * @returns {Promise<Object>} - Dados processados
   */
  async processWebhook(body, headers) {
    throw new Error('processWebhook() deve ser implementado');
  }

  /**
   * Validar assinatura do webhook (segurança)
   * @param {Object} body - Corpo da requisição
   * @param {Object} headers - Headers da requisição
   * @returns {boolean} - Válido ou não
   */
  validateWebhookSignature(body, headers) {
    throw new Error('validateWebhookSignature() deve ser implementado');
  }

  /**
   * Formatar resposta padrão de pagamento
   * @param {Object} rawData - Dados brutos do gateway
   * @returns {Object} - Dados formatados
   */
  formatPaymentResponse(rawData) {
    return {
      gateway: this.name,
      paymentId: null,
      status: 'pending',
      amount: 0,
      qrCode: null,
      qrCodeBase64: null,
      pixKey: null,
      expiresAt: null,
      createdAt: new Date().toISOString(),
      raw: rawData
    };
  }

  /**
   * Verificar se gateway está habilitado
   */
  isEnabled() {
    return this.enabled && this.validateConfig();
  }

  /**
   * Obter nome amigável do gateway
   */
  getFriendlyName() {
    return this.name;
  }

  /**
   * Obter taxa/comissão do gateway
   */
  getFee() {
    return this.config.fee || 0;
  }

  /**
   * Calcular valor final com taxa
   * @param {number} amount - Valor em centavos
   * @returns {number} - Valor com taxa
   */
  calculateTotalWithFee(amount) {
    const fee = this.getFee();
    return Math.ceil(amount * (1 + fee / 100));
  }
}

module.exports = PaymentGatewayBase;
