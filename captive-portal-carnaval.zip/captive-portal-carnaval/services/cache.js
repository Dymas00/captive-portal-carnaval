/**
 * Redis Cache Service
 * Gerenciamento de cache e sessões
 */

const Redis = require('ioredis');
const pino = require('pino');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

let redisClient = null;

/**
 * Inicializar conexão Redis
 */
async function initRedis() {
    try {
        const redisConfig = {
            host: process.env.REDIS_HOST || 'redis',
            port: parseInt(process.env.REDIS_PORT) || 6379,
            password: process.env.REDIS_PASSWORD || undefined,
            maxRetriesPerRequest: 3,
            retryDelayOnFailover: 100,
            enableReadyCheck: true,
            connectTimeout: 10000,
            lazyConnect: false
        };

        redisClient = new Redis(redisConfig);

        redisClient.on('connect', () => {
            logger.info('Redis conectado');
        });

        redisClient.on('error', (err) => {
            logger.error({ error: err.message }, 'Erro no Redis');
        });

        redisClient.on('close', () => {
            logger.warn('Conexão Redis fechada');
        });

        // Testar conexão
        await redisClient.ping();
        logger.info('Redis pronto para uso');

        return redisClient;
    } catch (error) {
        logger.error({ error: error.message }, 'Falha ao conectar ao Redis');
        throw error;
    }
}

/**
 * Obter cliente Redis
 */
function getRedisClient() {
    if (!redisClient) {
        throw new Error('Redis não inicializado. Chame initRedis() primeiro.');
    }
    return redisClient;
}

/**
 * Definir valor no cache com TTL
 */
async function setCache(key, value, ttlSeconds = 3600) {
    try {
        const serialized = typeof value === 'object' ? JSON.stringify(value) : value;
        await redisClient.setex(key, ttlSeconds, serialized);
        return true;
    } catch (error) {
        logger.error({ error: error.message, key }, 'Erro ao definir cache');
        return false;
    }
}

/**
 * Obter valor do cache
 */
async function getCache(key) {
    try {
        const value = await redisClient.get(key);
        if (!value) return null;

        try {
            return JSON.parse(value);
        } catch {
            return value;
        }
    } catch (error) {
        logger.error({ error: error.message, key }, 'Erro ao obter cache');
        return null;
    }
}

/**
 * Remover valor do cache
 */
async function deleteCache(key) {
    try {
        await redisClient.del(key);
        return true;
    } catch (error) {
        logger.error({ error: error.message, key }, 'Erro ao deletar cache');
        return false;
    }
}

/**
 * Remover valores por padrão
 */
async function deleteCachePattern(pattern) {
    try {
        const keys = await redisClient.keys(pattern);
        if (keys.length > 0) {
            await redisClient.del(...keys);
        }
        return true;
    } catch (error) {
        logger.error({ error: error.message, pattern }, 'Erro ao deletar cache por padrão');
        return false;
    }
}

/**
 * Incrementar contador
 */
async function incrementCounter(key, ttlSeconds = 900) {
    try {
        const multi = redisClient.multi();
        multi.incr(key);
        multi.expire(key, ttlSeconds);
        const results = await multi.exec();
        return results[0][1]; // Valor do contador
    } catch (error) {
        logger.error({ error: error.message, key }, 'Erro ao incrementar contador');
        return null;
    }
}

/**
 * Verificar se chave existe
 */
async function exists(key) {
    try {
        return await redisClient.exists(key);
    } catch (error) {
        logger.error({ error: error.message, key }, 'Erro ao verificar existência');
        return false;
    }
}

/**
 * Cache de sessão ativa
 */
async function cacheActiveSession(macAddress, sessionData) {
    const key = `session:active:${macAddress.toLowerCase()}`;
    return await setCache(key, sessionData, 86400); // 24 horas
}

/**
 * Obter sessão ativa do cache
 */
async function getActiveSession(macAddress) {
    const key = `session:active:${macAddress.toLowerCase()}`;
    return await getCache(key);
}

/**
 * Remover sessão ativa do cache
 */
async function removeActiveSession(macAddress) {
    const key = `session:active:${macAddress.toLowerCase()}`;
    return await deleteCache(key);
}

/**
 * Cache de usuário
 */
async function cacheUser(userId, userData) {
    const key = `user:${userId}`;
    return await setCache(key, userData, 3600); // 1 hora
}

/**
 * Obter usuário do cache
 */
async function getCachedUser(userId) {
    const key = `user:${userId}`;
    return await getCache(key);
}

/**
 * Invalidar cache de usuário
 */
async function invalidateUserCache(userId) {
    const key = `user:${userId}`;
    return await deleteCache(key);
}

module.exports = {
    initRedis,
    getRedisClient,
    setCache,
    getCache,
    deleteCache,
    deleteCachePattern,
    incrementCounter,
    exists,
    cacheActiveSession,
    getActiveSession,
    removeActiveSession,
    cacheUser,
    getCachedUser,
    invalidateUserCache
};
