/**
 * MikroTik RouterOS Integration Service
 * Comunicação com roteador MikroTik via API
 */

const RouterOSAPI = require('routeros').RouterOSAPI;
const pino = require('pino');
const { recordMikrotikOperation } = require('./monitoring');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

let connection = null;
let isConnected = false;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;

/**
 * Configuração do MikroTik
 */
const config = {
    host: process.env.ROUTER_IP || '192.168.10.1',
    user: process.env.ROUTER_USER || 'admin',
    password: process.env.ROUTER_PASSWORD || '',
    port: parseInt(process.env.ROUTER_PORT) || 8728,
    timeout: 10000
};

/**
 * Modo simulado (para desenvolvimento/testes)
 */
const isSimulated = process.env.MIKROTIK_SIMULATED === 'true';

/**
 * Conectar ao MikroTik
 */
async function connect() {
    if (isSimulated) {
        logger.info('MikroTik em modo simulado');
        isConnected = true;
        return true;
    }

    try {
        connection = new RouterOSAPI({
            host: config.host,
            user: config.user,
            password: config.password,
            port: config.port,
            timeout: config.timeout
        });

        await connection.connect();
        isConnected = true;
        reconnectAttempts = 0;

        logger.info({ host: config.host }, 'Conectado ao MikroTik');
        return true;
    } catch (error) {
        logger.error({ error: error.message, host: config.host }, 'Falha ao conectar ao MikroTik');
        isConnected = false;
        return false;
    }
}

/**
 * Desconectar do MikroTik
 */
async function disconnect() {
    if (connection && !isSimulated) {
        try {
            await connection.close();
            isConnected = false;
            logger.info('Desconectado do MikroTik');
        } catch (error) {
            logger.error({ error: error.message }, 'Erro ao desconectar do MikroTik');
        }
    }
}

/**
 * Executar comando no MikroTik
 */
async function executeCommand(command, params = {}) {
    if (isSimulated) {
        logger.debug({ command, params }, 'MikroTik (simulado): comando executado');
        return [];
    }

    if (!isConnected) {
        const connected = await connect();
        if (!connected) {
            throw new Error('Não foi possível conectar ao MikroTik');
        }
    }

    try {
        const result = await connection.write(command, Object.entries(params).map(
            ([key, value]) => `=${key}=${value}`
        ));
        return result;
    } catch (error) {
        logger.error({ error: error.message, command }, 'Erro ao executar comando MikroTik');

        // Tentar reconectar
        if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
            reconnectAttempts++;
            isConnected = false;
            await connect();
            return await executeCommand(command, params);
        }

        throw error;
    }
}

/**
 * Autorizar usuário - Adicionar à lista de autorizados
 * @param {string} macAddress - MAC address do dispositivo
 * @param {string} ipAddress - IP address do dispositivo
 * @param {number} durationMinutes - Duração da sessão em minutos (opcional, padrão sem limite)
 */
async function authorizeUser(macAddress, ipAddress, durationMinutes = null) {
    const mac = macAddress.toLowerCase();

    try {
        if (isSimulated) {
            logger.info({ macAddress: mac, ipAddress, durationMinutes }, 'MikroTik (simulado): usuário autorizado');
            recordMikrotikOperation('authorize', true);
            return true;
        }

        // Calcular timeout se duração for fornecida
        // MikroTik aceita timeout em formato 00:00:00 (hh:mm:ss)
        let timeout = null;
        if (durationMinutes && durationMinutes > 0) {
            const hours = Math.floor(durationMinutes / 60);
            const mins = durationMinutes % 60;
            timeout = `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:00`;
        }

        // Remover bindings antigos primeiro
        try {
            const oldBindings = await executeCommand('/ip/hotspot/ip-binding/print', {
                '.proplist': '.id,mac-address'
            });

            for (const binding of oldBindings) {
                if (binding['mac-address']?.toLowerCase() === mac) {
                    await executeCommand('/ip/hotspot/ip-binding/remove', {
                        '.id': binding['.id']
                    });
                }
            }
        } catch (error) {
            logger.debug('Nenhum binding antigo para remover');
        }

        // Adicionar IP Binding no Hotspot (sem timeout - bypass permanente até revogar)
        try {
            const bindingParams = {
                'mac-address': mac,
                'type': 'bypassed',
                'comment': `Captive Portal - ${new Date().toISOString()}`
            };

            await executeCommand('/ip/hotspot/ip-binding/add', bindingParams);
            logger.info({ macAddress: mac }, 'IP Binding criado (tipo bypassed - sem timeout)');
        } catch (error) {
            if (!error.message.includes('already have')) {
                logger.warn({ error: error.message }, 'Erro ao adicionar IP Binding');
            }
        }

        // Remover entradas antigas da Address List
        try {
            const oldEntries = await executeCommand('/ip/firewall/address-list/print', {
                '.proplist': '.id,address,list,comment'
            });

            for (const entry of oldEntries) {
                if (entry.list === 'authorized_users' &&
                    (entry.address === ipAddress || entry.comment?.includes(mac))) {
                    await executeCommand('/ip/firewall/address-list/remove', {
                        '.id': entry['.id']
                    });
                }
            }
        } catch (error) {
            logger.debug('Nenhuma entrada antiga na Address List para remover');
        }

        // Adicionar à Address List (com timeout se especificado)
        try {
            const addressListParams = {
                'list': 'authorized_users',
                'address': ipAddress,
                'comment': `MAC: ${mac} - ${new Date().toISOString()}`
            };

            // Adicionar timeout se fornecido
            if (timeout) {
                addressListParams['timeout'] = timeout;
                logger.info({ ipAddress, timeout }, `Address List criada com timeout de ${timeout}`);
            } else {
                logger.info({ ipAddress }, 'Address List criada sem timeout (permanente até revogar)');
            }

            await executeCommand('/ip/firewall/address-list/add', addressListParams);
        } catch (error) {
            if (!error.message.includes('already have')) {
                logger.warn({ error: error.message }, 'Erro ao adicionar à Address List');
            }
        }

        logger.info({
            macAddress: mac,
            ipAddress,
            durationMinutes,
            timeout: timeout || 'sem limite'
        }, 'Usuário autorizado no MikroTik');

        recordMikrotikOperation('authorize', true);

        return true;
    } catch (error) {
        logger.error({ error: error.message, macAddress: mac }, 'Falha ao autorizar usuário');
        recordMikrotikOperation('authorize', false);
        throw error;
    }
}

/**
 * Revogar acesso do usuário
 */
async function revokeUser(macAddress, ipAddress) {
    const mac = macAddress.toLowerCase();

    try {
        if (isSimulated) {
            logger.info({ macAddress: mac, ipAddress }, 'MikroTik (simulado): usuário revogado');
            recordMikrotikOperation('revoke', true);
            return true;
        }

        // Remover IP Binding
        try {
            const bindings = await executeCommand('/ip/hotspot/ip-binding/print', {
                '.proplist': '.id,mac-address'
            });

            for (const binding of bindings) {
                if (binding['mac-address']?.toLowerCase() === mac) {
                    await executeCommand('/ip/hotspot/ip-binding/remove', {
                        '.id': binding['.id']
                    });
                }
            }
        } catch (error) {
            logger.warn({ error: error.message }, 'Erro ao remover IP Binding');
        }

        // Remover da Address List
        try {
            const entries = await executeCommand('/ip/firewall/address-list/print', {
                '.proplist': '.id,address,list'
            });

            for (const entry of entries) {
                if (entry.list === 'authorized_users' && entry.address === ipAddress) {
                    await executeCommand('/ip/firewall/address-list/remove', {
                        '.id': entry['.id']
                    });
                }
            }
        } catch (error) {
            logger.warn({ error: error.message }, 'Erro ao remover da Address List');
        }

        // Desconectar sessão ativa do hotspot
        try {
            const activeUsers = await executeCommand('/ip/hotspot/active/print', {
                '.proplist': '.id,mac-address'
            });

            for (const user of activeUsers) {
                if (user['mac-address']?.toLowerCase() === mac) {
                    await executeCommand('/ip/hotspot/active/remove', {
                        '.id': user['.id']
                    });
                }
            }
        } catch (error) {
            logger.warn({ error: error.message }, 'Erro ao desconectar usuário ativo');
        }

        logger.info({ macAddress: mac, ipAddress }, 'Usuário revogado no MikroTik');
        recordMikrotikOperation('revoke', true);

        return true;
    } catch (error) {
        logger.error({ error: error.message, macAddress: mac }, 'Falha ao revogar usuário');
        recordMikrotikOperation('revoke', false);
        throw error;
    }
}

/**
 * Buscar IP do dispositivo pelo MAC
 */
async function getIpByMac(macAddress) {
    const mac = macAddress.toLowerCase();

    if (isSimulated) {
        return '192.168.10.100';
    }

    try {
        // Tentar DHCP Server Leases
        const leases = await executeCommand('/ip/dhcp-server/lease/print', {
            '.proplist': 'mac-address,active-address'
        });

        for (const lease of leases) {
            if (lease['mac-address']?.toLowerCase() === mac && lease['active-address']) {
                return lease['active-address'];
            }
        }

        // Tentar ARP
        const arpEntries = await executeCommand('/ip/arp/print', {
            '.proplist': 'mac-address,address'
        });

        for (const entry of arpEntries) {
            if (entry['mac-address']?.toLowerCase() === mac) {
                return entry.address;
            }
        }

        return null;
    } catch (error) {
        logger.error({ error: error.message, macAddress: mac }, 'Erro ao buscar IP pelo MAC');
        return null;
    }
}

/**
 * Verificar se MAC está autorizado
 */
async function isAuthorized(macAddress) {
    const mac = macAddress.toLowerCase();

    if (isSimulated) {
        return false;
    }

    try {
        const bindings = await executeCommand('/ip/hotspot/ip-binding/print', {
            '.proplist': 'mac-address,type'
        });

        for (const binding of bindings) {
            if (binding['mac-address']?.toLowerCase() === mac && binding.type === 'bypassed') {
                return true;
            }
        }

        return false;
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao verificar autorização');
        return false;
    }
}

/**
 * Listar usuários ativos no Hotspot
 */
async function getActiveHotspotUsers() {
    if (isSimulated) {
        return [];
    }

    try {
        const users = await executeCommand('/ip/hotspot/active/print');
        return users.map(user => ({
            id: user['.id'],
            macAddress: user['mac-address'],
            ipAddress: user.address,
            uptime: user.uptime,
            user: user.user
        }));
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao listar usuários ativos');
        return [];
    }
}

/**
 * Adicionar regra ao Walled Garden
 */
async function addWalledGardenRule(dstHost, action = 'allow') {
    if (isSimulated) {
        logger.info({ dstHost, action }, 'MikroTik (simulado): regra walled garden adicionada');
        return true;
    }

    try {
        await executeCommand('/ip/hotspot/walled-garden/add', {
            'dst-host': dstHost,
            'action': action
        });

        logger.info({ dstHost, action }, 'Regra Walled Garden adicionada');
        return true;
    } catch (error) {
        if (!error.message.includes('already have')) {
            logger.error({ error: error.message }, 'Erro ao adicionar regra Walled Garden');
        }
        return false;
    }
}

/**
 * Obter status da conexão
 */
function getConnectionStatus() {
    return {
        isConnected,
        isSimulated,
        host: config.host,
        reconnectAttempts
    };
}

module.exports = {
    connect,
    disconnect,
    executeCommand,
    authorizeUser,
    revokeUser,
    getIpByMac,
    isAuthorized,
    getActiveHotspotUsers,
    addWalledGardenRule,
    getConnectionStatus
};
