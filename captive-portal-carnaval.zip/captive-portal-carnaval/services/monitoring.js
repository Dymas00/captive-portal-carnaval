/**
 * Monitoring Service - Prometheus
 * Métricas e observabilidade do sistema
 */

const promClient = require('prom-client');
const pino = require('pino');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

// Registry global
const register = new promClient.Registry();

// Configurar métricas padrão
promClient.collectDefaultMetrics({
    register,
    prefix: 'captive_portal_'
});

// Métricas customizadas
const metrics = {
    // Contador de requisições HTTP
    httpRequestsTotal: new promClient.Counter({
        name: 'captive_portal_http_requests_total',
        help: 'Total de requisições HTTP',
        labelNames: ['method', 'route', 'status'],
        registers: [register]
    }),

    // Histograma de duração das requisições
    httpRequestDuration: new promClient.Histogram({
        name: 'captive_portal_http_request_duration_seconds',
        help: 'Duração das requisições HTTP em segundos',
        labelNames: ['method', 'route', 'status'],
        buckets: [0.01, 0.05, 0.1, 0.3, 0.5, 1, 2, 5],
        registers: [register]
    }),

    // Gauge de sessões ativas
    activeSessions: new promClient.Gauge({
        name: 'captive_portal_active_sessions',
        help: 'Número de sessões ativas',
        registers: [register]
    }),

    // Gauge de usuários totais
    totalUsers: new promClient.Gauge({
        name: 'captive_portal_total_users',
        help: 'Total de usuários cadastrados',
        registers: [register]
    }),

    // Contador de pagamentos
    paymentsTotal: new promClient.Counter({
        name: 'captive_portal_payments_total',
        help: 'Total de pagamentos por status',
        labelNames: ['status', 'gateway'],
        registers: [register]
    }),

    // Gauge de receita
    revenueTotal: new promClient.Gauge({
        name: 'captive_portal_revenue_total_cents',
        help: 'Receita total em centavos',
        registers: [register]
    }),

    // Contador de erros
    errorsTotal: new promClient.Counter({
        name: 'captive_portal_errors_total',
        help: 'Total de erros por tipo',
        labelNames: ['type'],
        registers: [register]
    }),

    // Gauge de conexões do pool de banco
    dbPoolConnections: new promClient.Gauge({
        name: 'captive_portal_db_pool_connections',
        help: 'Conexões do pool do banco de dados',
        labelNames: ['state'],
        registers: [register]
    }),

    // Contador de autenticações
    authAttempts: new promClient.Counter({
        name: 'captive_portal_auth_attempts_total',
        help: 'Total de tentativas de autenticação',
        labelNames: ['type', 'success'],
        registers: [register]
    }),

    // Contador de integrações MikroTik
    mikrotikOperations: new promClient.Counter({
        name: 'captive_portal_mikrotik_operations_total',
        help: 'Total de operações MikroTik',
        labelNames: ['operation', 'success'],
        registers: [register]
    })
};

/**
 * Middleware para métricas de requisição
 */
function metricsMiddleware(req, res, next) {
    const start = Date.now();

    res.on('finish', () => {
        const duration = (Date.now() - start) / 1000;
        const route = req.route?.path || req.path || 'unknown';
        const method = req.method;
        const status = res.statusCode;

        metrics.httpRequestsTotal.inc({
            method,
            route,
            status
        });

        metrics.httpRequestDuration.observe({
            method,
            route,
            status
        }, duration);
    });

    next();
}

/**
 * Configurar Prometheus no Express
 */
function setupPrometheus(app) {
    // Adicionar middleware de métricas
    app.use(metricsMiddleware);

    logger.info('Prometheus middleware configurado');
}

/**
 * Obter métricas formatadas
 */
async function getMetrics() {
    return await register.metrics();
}

/**
 * Obter content-type das métricas
 */
function getContentType() {
    return register.contentType;
}

/**
 * Atualizar métricas de sessões ativas
 */
function updateActiveSessions(count) {
    metrics.activeSessions.set(count);
}

/**
 * Atualizar métricas de usuários totais
 */
function updateTotalUsers(count) {
    metrics.totalUsers.set(count);
}

/**
 * Registrar pagamento
 */
function recordPayment(status, gateway) {
    metrics.paymentsTotal.inc({ status, gateway });
}

/**
 * Atualizar receita total
 */
function updateRevenue(totalCents) {
    metrics.revenueTotal.set(totalCents);
}

/**
 * Registrar erro
 */
function recordError(type) {
    metrics.errorsTotal.inc({ type });
}

/**
 * Atualizar pool de conexões
 */
function updateDbPool(active, idle, waiting) {
    metrics.dbPoolConnections.set({ state: 'active' }, active);
    metrics.dbPoolConnections.set({ state: 'idle' }, idle);
    metrics.dbPoolConnections.set({ state: 'waiting' }, waiting);
}

/**
 * Registrar tentativa de autenticação
 */
function recordAuthAttempt(type, success) {
    metrics.authAttempts.inc({ type, success: success ? 'true' : 'false' });
}

/**
 * Registrar operação MikroTik
 */
function recordMikrotikOperation(operation, success) {
    metrics.mikrotikOperations.inc({ operation, success: success ? 'true' : 'false' });
}

module.exports = {
    setupPrometheus,
    getMetrics,
    getContentType,
    updateActiveSessions,
    updateTotalUsers,
    recordPayment,
    updateRevenue,
    recordError,
    updateDbPool,
    recordAuthAttempt,
    recordMikrotikOperation,
    metrics
};
