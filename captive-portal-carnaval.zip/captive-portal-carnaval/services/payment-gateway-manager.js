/**
 * Gerenciador de Gateways de Pagamento
 *
 * Centraliza o gerenciamento de múltiplos gateways de pagamento,
 * permitindo seleção dinâmica e fallback automático.
 */

// Importação dos gateways (usando require condicional para evitar erros se não existirem)
let MercadoPagoGateway, PicPayGateway, PagSeguroGateway;
const { AbacatePayGateway } = require('./abacatepay');

try {
  MercadoPagoGateway = require('./gateways/mercadopago-gateway');
} catch (e) {
  MercadoPagoGateway = null;
}

try {
  PicPayGateway = require('./gateways/picpay-gateway');
} catch (e) {
  PicPayGateway = null;
}

try {
  PagSeguroGateway = require('./gateways/pagseguro-gateway');
} catch (e) {
  PagSeguroGateway = null;
}

class PaymentGatewayManager {
  constructor() {
    this.gateways = new Map();
    this.defaultGateway = null;
    this.initialized = false;
  }

  /**
   * Inicializa todos os gateways configurados
   */
  initialize() {
    if (this.initialized) {
      return;
    }

    // Mercado Pago
    if (MercadoPagoGateway && process.env.MERCADOPAGO_ACCESS_TOKEN) {
      const mpConfig = {
        accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN,
        publicKey: process.env.MERCADOPAGO_PUBLIC_KEY,
        sandbox: process.env.MERCADOPAGO_SANDBOX === 'true',
        enabled: process.env.MERCADOPAGO_ENABLED !== 'false',
        fee: parseFloat(process.env.MERCADOPAGO_FEE || '3.99')
      };

      const mercadoPago = new MercadoPagoGateway(mpConfig);
      this.gateways.set('mercadopago', mercadoPago);

      console.log(`✓ Mercado Pago gateway ${mercadoPago.isEnabled() ? 'habilitado' : 'desabilitado'}`);
    }

    // PicPay
    if (PicPayGateway && process.env.PICPAY_TOKEN) {
      const picpayConfig = {
        token: process.env.PICPAY_TOKEN,
        sellerToken: process.env.PICPAY_SELLER_TOKEN,
        sandbox: process.env.PICPAY_SANDBOX === 'true',
        enabled: process.env.PICPAY_ENABLED !== 'false',
        fee: parseFloat(process.env.PICPAY_FEE || '1.99')
      };

      const picpay = new PicPayGateway(picpayConfig);
      this.gateways.set('picpay', picpay);

      console.log(`✓ PicPay gateway ${picpay.isEnabled() ? 'habilitado' : 'desabilitado'}`);
    }

    // PagSeguro
    if (PagSeguroGateway && process.env.PAGSEGURO_TOKEN) {
      const pagseguroConfig = {
        token: process.env.PAGSEGURO_TOKEN,
        email: process.env.PAGSEGURO_EMAIL,
        sandbox: process.env.PAGSEGURO_SANDBOX === 'true',
        enabled: process.env.PAGSEGURO_ENABLED !== 'false',
        fee: parseFloat(process.env.PAGSEGURO_FEE || '3.49')
      };

      const pagseguro = new PagSeguroGateway(pagseguroConfig);
      this.gateways.set('pagseguro', pagseguro);

      console.log(`✓ PagSeguro gateway ${pagseguro.isEnabled() ? 'habilitado' : 'desabilitado'}`);
    }

    // AbacatePay
    if (process.env.ABACATEPAY_API_KEY) {
      const abacateConfig = {
        apiKey: process.env.ABACATEPAY_API_KEY,
        webhookSecret: process.env.ABACATEPAY_WEBHOOK_SECRET,
        enabled: process.env.ABACATEPAY_ENABLED !== 'false',
        fee: parseFloat(process.env.ABACATEPAY_FEE || '0'), // Taxa percentual (0%)
        fixedFee: parseInt(process.env.ABACATEPAY_FIXED_FEE || '80') // Taxa fixa em centavos (R$ 0,80)
      };

      const abacatePay = new AbacatePayGateway(abacateConfig);
      this.gateways.set('abacatepay', abacatePay);

      console.log(`✓ AbacatePay gateway ${abacatePay.isEnabled() ? 'habilitado' : 'desabilitado'}`);
    }

    // Definir gateway padrão
    const defaultGatewayName = process.env.DEFAULT_PAYMENT_GATEWAY || 'mercadopago';
    this.defaultGateway = this.gateways.get(defaultGatewayName);

    if (!this.defaultGateway && this.gateways.size > 0) {
      // Se o padrão não existe, pega o primeiro disponível
      this.defaultGateway = Array.from(this.gateways.values())[0];
    }

    if (this.defaultGateway) {
      console.log(`✓ Gateway padrão: ${this.defaultGateway.getFriendlyName()}`);
    } else {
      console.warn('⚠️  Nenhum gateway de pagamento configurado!');
    }

    this.initialized = true;
  }

  /**
   * Obtém gateway por nome
   */
  getGateway(gatewayName) {
    if (!this.initialized) {
      this.initialize();
    }

    const gateway = this.gateways.get(gatewayName);

    if (!gateway) {
      throw new Error(`Gateway '${gatewayName}' não encontrado`);
    }

    if (!gateway.isEnabled()) {
      throw new Error(`Gateway '${gatewayName}' está desabilitado`);
    }

    return gateway;
  }

  /**
   * Obtém gateway padrão
   */
  getDefaultGateway() {
    if (!this.initialized) {
      this.initialize();
    }

    if (!this.defaultGateway) {
      throw new Error('Nenhum gateway de pagamento disponível');
    }

    return this.defaultGateway;
  }

  /**
   * Lista todos os gateways disponíveis (habilitados)
   */
  getAvailableGateways() {
    if (!this.initialized) {
      this.initialize();
    }

    const available = [];

    this.gateways.forEach((gateway) => {
      if (gateway.isEnabled()) {
        const info = {
          id: gateway.name,
          name: gateway.getFriendlyName(),
          fee: gateway.getFee(),
          isDefault: gateway === this.defaultGateway
        };

        // Incluir taxa fixa se o gateway suportar
        if (typeof gateway.calculateFee === 'function') {
          info.fixedFee = gateway.config.fixedFee || 80;
          info.feeType = 'fixed';
        } else {
          info.feeType = 'percentage';
        }

        available.push(info);
      }
    });

    return available;
  }

  /**
   * Cria pagamento Pix usando gateway especificado ou padrão
   */
  async createPixPayment(data, gatewayName = null) {
    const gateway = gatewayName
      ? this.getGateway(gatewayName)
      : this.getDefaultGateway();

    console.log(`💳 Criando pagamento via ${gateway.getFriendlyName()}`);

    return await gateway.createPixPayment(data);
  }

  /**
   * Consulta status de pagamento
   */
  async getPaymentStatus(paymentId, gatewayName) {
    const gateway = this.getGateway(gatewayName);
    return await gateway.getPaymentStatus(paymentId);
  }

  /**
   * Processa webhook de pagamento
   */
  async processWebhook(gatewayName, body, headers) {
    const gateway = this.getGateway(gatewayName);

    // Validar assinatura do webhook
    const isValid = gateway.validateWebhookSignature(body, headers);

    if (!isValid) {
      throw new Error('Assinatura do webhook inválida');
    }

    return await gateway.processWebhook(body, headers);
  }

  /**
   * Calcula o valor total com taxa do gateway
   */
  calculateTotalWithFee(amount, gatewayName = null) {
    const gateway = gatewayName
      ? this.getGateway(gatewayName)
      : this.getDefaultGateway();

    let feeAmount;

    // Verificar se o gateway tem método calculateFee personalizado (taxa fixa)
    if (typeof gateway.calculateFee === 'function') {
      feeAmount = gateway.calculateFee(amount);
    } else {
      // Taxa percentual padrão
      const fee = gateway.getFee();
      feeAmount = Math.ceil(amount * (fee / 100));
    }

    return {
      amount,
      fee: feeAmount,
      total: amount + feeAmount,
      feePercentage: gateway.getFee(),
      feeType: typeof gateway.calculateFee === 'function' ? 'fixed' : 'percentage',
      gateway: gateway.name
    };
  }

  /**
   * Tenta criar pagamento com fallback automático
   * Se o gateway primário falhar, tenta os outros disponíveis
   */
  async createPixPaymentWithFallback(data, preferredGateway = null) {
    const gateways = this.getAvailableGateways();

    if (gateways.length === 0) {
      throw new Error('Nenhum gateway de pagamento disponível');
    }

    // Ordenar: preferido primeiro, depois padrão, depois resto
    const orderedGateways = [...gateways].sort((a, b) => {
      if (a.id === preferredGateway) return -1;
      if (b.id === preferredGateway) return 1;
      if (a.isDefault) return -1;
      if (b.isDefault) return 1;
      return 0;
    });

    let lastError = null;

    // Tentar cada gateway
    for (const gatewayInfo of orderedGateways) {
      try {
        console.log(`💳 Tentando pagamento via ${gatewayInfo.name}`);
        const result = await this.createPixPayment(data, gatewayInfo.id);
        return result;
      } catch (error) {
        console.error(`❌ Falha no gateway ${gatewayInfo.name}:`, error.message);
        lastError = error;
        // Continuar para próximo gateway
      }
    }

    // Se chegou aqui, todos falharam
    throw new Error(`Todos os gateways falharam. Último erro: ${lastError?.message}`);
  }

  /**
   * Retorna estatísticas dos gateways
   */
  getStats() {
    if (!this.initialized) {
      this.initialize();
    }

    const stats = {
      total: this.gateways.size,
      enabled: 0,
      disabled: 0,
      default: this.defaultGateway?.name || null,
      gateways: []
    };

    this.gateways.forEach((gateway) => {
      const isEnabled = gateway.isEnabled();

      if (isEnabled) {
        stats.enabled++;
      } else {
        stats.disabled++;
      }

      stats.gateways.push({
        id: gateway.name,
        name: gateway.getFriendlyName(),
        enabled: isEnabled,
        fee: gateway.getFee(),
        isDefault: gateway === this.defaultGateway
      });
    });

    return stats;
  }
}

// Singleton
const manager = new PaymentGatewayManager();

module.exports = manager;
