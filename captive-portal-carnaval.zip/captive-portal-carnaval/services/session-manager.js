/**
 * Session Manager Service
 * Gerenciamento de sessões de usuários
 */

const pino = require('pino');
const { getPool, logConnection } = require('../database/db-manager');
const { removeActiveSession, cacheActiveSession } = require('./cache');
const mikrotik = require('./mikrotik');
const { updateActiveSessions } = require('./monitoring');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

let cleanupInterval = null;

/**
 * Criar nova sessão
 */
async function createSession(userId, macAddress, ipAddress, planId, userAgent = null) {
    const pool = getPool();

    try {
        // Buscar duração do plano
        const planResult = await pool.query(
            'SELECT duration_minutes FROM plans WHERE id = $1',
            [planId]
        );

        if (planResult.rows.length === 0) {
            throw new Error('Plano não encontrado');
        }

        const durationMinutes = planResult.rows[0].duration_minutes;
        const expectedEndTime = new Date(Date.now() + durationMinutes * 60 * 1000);

        // Encerrar sessões anteriores do usuário
        await pool.query(`
            UPDATE sessions
            SET status = 'disconnected', end_time = CURRENT_TIMESTAMP
            WHERE user_id = $1 AND status = 'active'
        `, [userId]);

        // Criar nova sessão
        const result = await pool.query(`
            INSERT INTO sessions (
                user_id, mac_address, ip_address, plan_id,
                expected_end_time, status, user_agent
            )
            VALUES ($1, $2, $3, $4, $5, 'active', $6)
            RETURNING *
        `, [userId, macAddress.toLowerCase(), ipAddress, planId, expectedEndTime, userAgent]);

        const session = result.rows[0];

        // Atualizar usuário com MAC e sessão ativa
        await pool.query(`
            UPDATE users
            SET active_mac_address = $1, active_session_id = $2, last_login = CURRENT_TIMESTAMP
            WHERE id = $3
        `, [macAddress.toLowerCase(), session.id, userId]);

        // Buscar CPF do usuário para log
        const userResult = await pool.query('SELECT cpf FROM users WHERE id = $1', [userId]);
        const cpf = userResult.rows[0]?.cpf;

        // Log de conexão (Marco Civil)
        await logConnection({
            userId,
            sessionId: session.id,
            macAddress: macAddress.toLowerCase(),
            ipAddress,
            action: 'SESSION_STARTED',
            cpf,
            details: { planId, durationMinutes }
        });

        // Liberar acesso no MikroTik (com duração do plano)
        try {
            await mikrotik.authorizeUser(macAddress, ipAddress, durationMinutes);
            await pool.query(
                'UPDATE sessions SET mikrotik_synced = true WHERE id = $1',
                [session.id]
            );
            logger.info({ macAddress, ipAddress, durationMinutes }, 'MikroTik sincronizado com timeout da sessão');
        } catch (mkError) {
            logger.warn({ error: mkError.message }, 'Falha ao sincronizar com MikroTik');
        }

        // Cache da sessão ativa
        await cacheActiveSession(macAddress, {
            sessionId: session.id,
            userId,
            expectedEndTime: expectedEndTime.toISOString(),
            planId
        });

        logger.info({
            sessionId: session.id,
            userId,
            macAddress,
            planId,
            expectedEndTime
        }, 'Sessão criada');

        return session;
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao criar sessão');
        throw error;
    }
}

/**
 * Verificar sessão por MAC address
 */
async function checkSession(macAddress) {
    const pool = getPool();

    try {
        const result = await pool.query(`
            SELECT s.*, p.name as plan_name, p.duration_minutes,
                   u.name as user_name, u.cpf
            FROM sessions s
            JOIN plans p ON s.plan_id = p.id
            JOIN users u ON s.user_id = u.id
            WHERE s.mac_address = $1 AND s.status = 'active'
            ORDER BY s.start_time DESC
            LIMIT 1
        `, [macAddress.toLowerCase()]);

        if (result.rows.length === 0) {
            return null;
        }

        const session = result.rows[0];

        // Verificar se expirou
        if (new Date(session.expected_end_time) < new Date()) {
            await expireSession(session.id);
            return null;
        }

        // Calcular tempo restante
        const now = new Date();
        const endTime = new Date(session.expected_end_time);
        const remainingMs = endTime - now;
        const remainingMinutes = Math.floor(remainingMs / 60000);

        return {
            ...session,
            remaining_minutes: remainingMinutes,
            remaining_formatted: formatDuration(remainingMinutes)
        };
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao verificar sessão');
        throw error;
    }
}

/**
 * Expirar sessão
 */
async function expireSession(sessionId) {
    const pool = getPool();

    try {
        const result = await pool.query(`
            UPDATE sessions
            SET status = 'expired', end_time = CURRENT_TIMESTAMP
            WHERE id = $1
            RETURNING *
        `, [sessionId]);

        if (result.rows.length === 0) {
            return null;
        }

        const session = result.rows[0];

        // Remover do cache
        await removeActiveSession(session.mac_address);

        // Revogar acesso no MikroTik
        try {
            await mikrotik.revokeUser(session.mac_address, session.ip_address);
        } catch (mkError) {
            logger.warn({ error: mkError.message }, 'Falha ao revogar no MikroTik');
        }

        // Log de conexão
        await logConnection({
            userId: session.user_id,
            sessionId,
            macAddress: session.mac_address,
            ipAddress: session.ip_address,
            action: 'SESSION_EXPIRED',
            details: {}
        });

        logger.info({ sessionId, macAddress: session.mac_address }, 'Sessão expirada');

        return session;
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao expirar sessão');
        throw error;
    }
}

/**
 * Desconectar sessão manualmente
 */
async function disconnectSession(sessionId, reason = 'manual') {
    const pool = getPool();

    try {
        const result = await pool.query(`
            UPDATE sessions
            SET status = 'disconnected', end_time = CURRENT_TIMESTAMP
            WHERE id = $1
            RETURNING *
        `, [sessionId]);

        if (result.rows.length === 0) {
            return null;
        }

        const session = result.rows[0];

        // Remover do cache
        await removeActiveSession(session.mac_address);

        // Revogar acesso no MikroTik
        try {
            await mikrotik.revokeUser(session.mac_address, session.ip_address);
        } catch (mkError) {
            logger.warn({ error: mkError.message }, 'Falha ao revogar no MikroTik');
        }

        // Log de conexão
        await logConnection({
            userId: session.user_id,
            sessionId,
            macAddress: session.mac_address,
            ipAddress: session.ip_address,
            action: 'SESSION_DISCONNECTED',
            details: { reason }
        });

        logger.info({ sessionId, macAddress: session.mac_address, reason }, 'Sessão desconectada');

        return session;
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao desconectar sessão');
        throw error;
    }
}

/**
 * Estender tempo da sessão
 */
async function extendSession(sessionId, additionalMinutes) {
    const pool = getPool();

    try {
        const result = await pool.query(`
            UPDATE sessions
            SET expected_end_time = expected_end_time + INTERVAL '${additionalMinutes} minutes'
            WHERE id = $1 AND status = 'active'
            RETURNING *
        `, [sessionId]);

        if (result.rows.length === 0) {
            return null;
        }

        const session = result.rows[0];

        // Atualizar cache
        await cacheActiveSession(session.mac_address, {
            sessionId: session.id,
            userId: session.user_id,
            expectedEndTime: session.expected_end_time,
            planId: session.plan_id
        });

        logger.info({ sessionId, additionalMinutes }, 'Sessão estendida');

        return session;
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao estender sessão');
        throw error;
    }
}

/**
 * Listar sessões ativas
 */
async function getActiveSessions(page = 1, limit = 50) {
    const pool = getPool();
    const offset = (page - 1) * limit;

    try {
        const countResult = await pool.query(
            "SELECT COUNT(*) FROM sessions WHERE status = 'active'"
        );
        const total = parseInt(countResult.rows[0].count);

        const result = await pool.query(`
            SELECT s.*, p.name as plan_name, u.name as user_name, u.cpf
            FROM sessions s
            JOIN plans p ON s.plan_id = p.id
            JOIN users u ON s.user_id = u.id
            WHERE s.status = 'active'
            ORDER BY s.start_time DESC
            LIMIT $1 OFFSET $2
        `, [limit, offset]);

        // Adicionar tempo restante
        const sessions = result.rows.map(session => {
            const now = new Date();
            const endTime = new Date(session.expected_end_time);
            const remainingMs = endTime - now;
            const remainingMinutes = Math.max(0, Math.floor(remainingMs / 60000));

            return {
                ...session,
                remaining_minutes: remainingMinutes,
                remaining_formatted: formatDuration(remainingMinutes)
            };
        });

        return {
            sessions,
            pagination: {
                page,
                limit,
                total,
                totalPages: Math.ceil(total / limit)
            }
        };
    } catch (error) {
        logger.error({ error: error.message }, 'Erro ao listar sessões ativas');
        throw error;
    }
}

/**
 * Limpeza de sessões expiradas
 */
async function cleanupExpiredSessions() {
    const pool = getPool();

    try {
        // Buscar sessões expiradas
        const result = await pool.query(`
            SELECT id, mac_address, ip_address, user_id
            FROM sessions
            WHERE status = 'active' AND expected_end_time < CURRENT_TIMESTAMP
        `);

        if (result.rows.length === 0) {
            return 0;
        }

        logger.info(`Encontradas ${result.rows.length} sessões expiradas para limpeza`);

        for (const session of result.rows) {
            await expireSession(session.id);
        }

        // Atualizar métricas
        const activeCount = await pool.query(
            "SELECT COUNT(*) FROM sessions WHERE status = 'active'"
        );
        updateActiveSessions(parseInt(activeCount.rows[0].count));

        return result.rows.length;
    } catch (error) {
        logger.error({ error: error.message }, 'Erro na limpeza de sessões');
        return 0;
    }
}

/**
 * Recuperar sessões ativas após reinicialização
 * Garante que sessões pagas não sejam perdidas mesmo após restart do servidor/Docker
 */
async function recoverActiveSessions() {
    const pool = getPool();

    try {
        logger.info('🔄 Iniciando recuperação de sessões ativas...');

        // Buscar todas as sessões que ainda deveriam estar ativas
        const result = await pool.query(`
            SELECT s.*, u.name as user_name, p.duration_minutes
            FROM sessions s
            JOIN users u ON s.user_id = u.id
            JOIN plans p ON s.plan_id = p.id
            WHERE s.status = 'active'
            ORDER BY s.expected_end_time ASC
        `);

        if (result.rows.length === 0) {
            logger.info('✓ Nenhuma sessão ativa para recuperar');
            return { recovered: 0, expired: 0, errors: 0 };
        }

        logger.info(`📦 Encontradas ${result.rows.length} sessões marcadas como ativas`);

        let recovered = 0;
        let expired = 0;
        let errors = 0;
        const now = new Date();

        for (const session of result.rows) {
            try {
                const expectedEndTime = new Date(session.expected_end_time);
                const remainingMs = expectedEndTime - now;

                // Se a sessão já expirou, marcar como expirada
                if (remainingMs <= 0) {
                    logger.info({
                        sessionId: session.id,
                        userId: session.user_id,
                        userName: session.user_name
                    }, 'Sessão expirada durante downtime');

                    await expireSession(session.id);
                    expired++;
                    continue;
                }

                // Sessão ainda válida - recuperar
                const remainingMinutes = Math.floor(remainingMs / 60000);

                logger.info({
                    sessionId: session.id,
                    userId: session.user_id,
                    userName: session.user_name,
                    macAddress: session.mac_address,
                    remainingMinutes
                }, 'Recuperando sessão ativa');

                // Recriar cache no Redis
                await cacheActiveSession(session.mac_address, {
                    sessionId: session.id,
                    userId: session.user_id,
                    expectedEndTime: session.expected_end_time,
                    planId: session.plan_id
                });

                // Resincronizar com MikroTik (com tempo restante)
                try {
                    await mikrotik.authorizeUser(
                        session.mac_address,
                        session.ip_address || '0.0.0.0',
                        remainingMinutes // Passa o tempo restante, não o tempo total
                    );

                    // Atualizar flag de sincronização
                    await pool.query(
                        'UPDATE sessions SET mikrotik_synced = true WHERE id = $1',
                        [session.id]
                    );

                    logger.info({
                        sessionId: session.id,
                        macAddress: session.mac_address,
                        remainingMinutes
                    }, '✓ Sessão recuperada e sincronizada com MikroTik (com timeout restante)');

                } catch (mikrotikError) {
                    logger.warn({
                        sessionId: session.id,
                        error: mikrotikError.message
                    }, 'Erro ao sincronizar com MikroTik (sessão mantida no banco)');
                }

                recovered++;

            } catch (sessionError) {
                logger.error({
                    sessionId: session.id,
                    error: sessionError.message
                }, 'Erro ao recuperar sessão individual');
                errors++;
            }
        }

        // Atualizar métricas
        const activeCount = await pool.query(
            "SELECT COUNT(*) FROM sessions WHERE status = 'active'"
        );
        updateActiveSessions(parseInt(activeCount.rows[0].count));

        logger.info({
            recovered,
            expired,
            errors,
            total: result.rows.length
        }, '✅ Recuperação de sessões concluída');

        return { recovered, expired, errors };

    } catch (error) {
        logger.error({ error: error.message }, '❌ Erro ao recuperar sessões ativas');
        throw error;
    }
}

/**
 * Iniciar job de limpeza
 */
function startSessionCleanup() {
    const interval = parseInt(process.env.SESSION_CHECK_INTERVAL) || 60000;

    cleanupInterval = setInterval(async () => {
        const cleaned = await cleanupExpiredSessions();
        if (cleaned > 0) {
            logger.info(`${cleaned} sessões expiradas limpas`);
        }
    }, interval);

    logger.info(`Job de limpeza de sessões iniciado (intervalo: ${interval}ms)`);
}

/**
 * Parar job de limpeza
 */
function stopSessionCleanup() {
    if (cleanupInterval) {
        clearInterval(cleanupInterval);
        cleanupInterval = null;
        logger.info('Job de limpeza de sessões parado');
    }
}

/**
 * Formatar duração em minutos
 */
function formatDuration(minutes) {
    if (minutes < 60) {
        return `${minutes} min`;
    }

    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;

    if (hours < 24) {
        return mins > 0 ? `${hours}h ${mins}min` : `${hours}h`;
    }

    const days = Math.floor(hours / 24);
    const remainingHours = hours % 24;

    return remainingHours > 0 ? `${days}d ${remainingHours}h` : `${days}d`;
}

module.exports = {
    createSession,
    checkSession,
    expireSession,
    disconnectSession,
    extendSession,
    getActiveSessions,
    cleanupExpiredSessions,
    recoverActiveSessions,
    startSessionCleanup,
    stopSessionCleanup
};
