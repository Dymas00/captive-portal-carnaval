# Configuracao Manual - MikroTik CCR1036 para Captive Portal

## Informacoes do Ambiente

| Item | Valor |
|------|-------|
| Servidor Ubuntu | ether3 - 192.168.10.250 |
| Porta do Portal | 3000 |
| Gateway (MikroTik) | 192.168.10.1 |
| API MikroTik | Porta 8728 |
| **VLAN 112 (Radio Ladeira)** | **HOTSPOT** - bridge-lan (Portal Captivo) |
| **VLAN 110 (Radio Day Use)** | **ACESSO LIVRE** - DHCP-FORA-HOTSPOT (Senha normal) |
| Rede Hotspot | 192.168.8.0/22 |
| Rede Acesso Livre | 172.25.0.0/22 |

---

## PASSO 1: Acessar o MikroTik

### Via Winbox:
```
IP: 192.168.88.52 (ou 192.168.10.1)
Porta: 5558
Usuario: admin
Senha: [sua senha]
```

### Via SSH:
```bash
ssh -p 15422 admin@192.168.88.52
```

### Via Terminal no Winbox:
Clique em **New Terminal** no menu lateral

---

## PASSO 2: Verificar ether3 na Bridge-LAN

### Verificar (Terminal):
```
/interface bridge port print
```

### Se ether3 NAO estiver na bridge-lan, adicionar:
```
/interface bridge port add bridge=bridge-lan interface=ether3
```

**Via Winbox:**
1. Ir em **Bridge** > **Ports**
2. Verificar se `ether3` esta com Bridge = `bridge-lan`
3. Se nao estiver, clicar em **+** e adicionar

---

## PASSO 2.1: Configurar VLANs das Antenas

### IMPORTANTE:
- **VLAN 112** (Radio Ladeira) = **HOTSPOT** → deve estar em `bridge-lan`
- **VLAN 110** (Radio Day Use) = **ACESSO LIVRE** → deve estar em `DHCP-FORA-HOTSPOT`

### Verificar configuracao atual:
```
/interface bridge port print
```

### Mover VLAN 110 para DHCP-FORA-HOTSPOT (acesso livre):
```
/interface bridge port remove [find interface="VLAN 110 RADIO DAY USE HOTSPOT" bridge=bridge-lan]
/interface bridge port add bridge=DHCP-FORA-HOTSPOT interface="VLAN 110 RADIO DAY USE HOTSPOT"
```

### Garantir VLAN 112 na bridge-lan (hotspot):
```
/interface bridge port print where interface="VLAN 112 RADIO LADEIRA HOTSPOT"
```

Se nao estiver em `bridge-lan`:
```
/interface bridge port add bridge=bridge-lan interface="VLAN 112 RADIO LADEIRA HOTSPOT"
```

**Via Winbox:**
1. Ir em **Bridge** > **Ports**
2. Encontrar `VLAN 110 RADIO DAY USE HOTSPOT`
3. Duplo clique e mudar **Bridge** para `DHCP-FORA-HOTSPOT`
4. Verificar se `VLAN 112 RADIO LADEIRA HOTSPOT` esta em `bridge-lan`

### Resultado esperado:
| Interface | Bridge |
|-----------|--------|
| VLAN 110 RADIO DAY USE HOTSPOT | DHCP-FORA-HOTSPOT |
| VLAN 112 RADIO LADEIRA HOTSPOT | bridge-lan |
| VLAN 111 DAY USE FORA HOTSPOT | DHCP-FORA-HOTSPOT |
| VLAN 113 LADEIRA FORA HOTSPOT | DHCP-FORA-HOTSPOT |

---

## PASSO 3: Configurar IP Binding (Bypass do Servidor)

### Verificar se ja existe:
```
/ip hotspot ip-binding print
```

### Adicionar ou verificar entrada para 192.168.10.250:
```
/ip hotspot ip-binding add address=192.168.10.250 type=bypassed comment="Servidor_Portal_Captive"
```

**Via Winbox:**
1. Ir em **IP** > **Hotspot** > **IP Bindings**
2. Clicar em **+**
3. Preencher:
   - **Address:** 192.168.10.250
   - **Type:** bypassed
   - **Comment:** Servidor_Portal_Captive
4. Clicar em **OK**

---

## PASSO 4: Adicionar Servidor a Address List

### Verificar:
```
/ip firewall address-list print where list=authorized_users
```

### Adicionar:
```
/ip firewall address-list add address=192.168.10.250 list=authorized_users comment="Servidor_Captive_Portal"
```

**Via Winbox:**
1. Ir em **IP** > **Firewall** > **Address Lists**
2. Clicar em **+**
3. Preencher:
   - **Name:** authorized_users
   - **Address:** 192.168.10.250
   - **Comment:** Servidor_Captive_Portal
4. Clicar em **OK**

---

## PASSO 5: Configurar Walled Garden (Acesso sem Login)

### 5.1 Walled Garden (por Host)

#### Verificar:
```
/ip hotspot walled-garden print
```

#### Adicionar regra para o servidor:
```
/ip hotspot walled-garden add dst-host=192.168.10.250 comment="Portal Captive Servidor"
```

**Via Winbox:**
1. Ir em **IP** > **Hotspot** > **Walled Garden**
2. Clicar em **+**
3. Preencher:
   - **Dst. Host:** 192.168.10.250
   - **Comment:** Portal Captive Servidor
4. Clicar em **OK**

### 5.2 Walled Garden IP (por IP/Porta)

#### Verificar:
```
/ip hotspot walled-garden ip print
```

#### Adicionar regra para porta 3000:
```
/ip hotspot walled-garden ip add action=accept dst-address=192.168.10.250 dst-port=3000 protocol=tcp comment="Portal-Server-HTTP"
```

**Via Winbox:**
1. Ir em **IP** > **Hotspot** > **Walled Garden** > aba **IP**
2. Clicar em **+**
3. Preencher:
   - **Action:** accept
   - **Dst. Address:** 192.168.10.250
   - **Protocol:** tcp
   - **Dst. Port:** 3000
   - **Comment:** Portal-Server-HTTP
4. Clicar em **OK**

---

## PASSO 6: Configurar Firewall Filter

### 6.1 Permitir API do MikroTik (porta 8728)

#### Verificar:
```
/ip firewall filter print where dst-port=8728
```

#### Adicionar (se nao existir):
```
/ip firewall filter add chain=input action=accept protocol=tcp dst-port=8728 src-address=192.168.10.250 comment="API Portal Captive"
```

**IMPORTANTE:** Mover esta regra para o INICIO da lista (antes de regras de DROP)

**Via Winbox:**
1. Ir em **IP** > **Firewall** > **Filter Rules**
2. Clicar em **+**
3. Aba **General:**
   - **Chain:** input
   - **Protocol:** tcp
   - **Dst. Port:** 8728
   - **Src. Address:** 192.168.10.250
4. Aba **Action:**
   - **Action:** accept
5. Aba **Comment:**
   - **Comment:** API Portal Captive
6. Clicar em **OK**
7. **ARRASTAR a regra para o TOPO da lista**

### 6.2 Permitir Forward para Usuarios Autorizados

#### Verificar:
```
/ip firewall filter print where src-address-list=authorized_users
```

#### Adicionar (se nao existir):
```
/ip firewall filter add chain=forward action=accept src-address-list=authorized_users comment="Liberar usuarios autorizados"
```

**IMPORTANTE:** Esta regra deve estar no INICIO da chain forward

### 6.3 Permitir Webhook (porta 3000)

```
/ip firewall filter add chain=forward action=accept protocol=tcp dst-port=3000 dst-address=192.168.10.250 comment="Webhook Portal Captive"
```

---

## PASSO 7: Habilitar Servico API

### Verificar:
```
/ip service print
```

### Habilitar API na porta 8728 apenas para rede interna:
```
/ip service set api disabled=no port=8728 address=192.168.10.0/24
```

**Via Winbox:**
1. Ir em **IP** > **Services**
2. Encontrar **api**
3. Duplo clique
4. Configurar:
   - **Disabled:** desmarcado
   - **Port:** 8728
   - **Available From:** 192.168.10.0/24
5. Clicar em **OK**

---

## PASSO 8: Configurar Hotspot Profile

### Verificar perfil atual:
```
/ip hotspot profile print
```

### Atualizar perfil para portal externo:
```
/ip hotspot profile set [find name=perfil-captive] login-by=http-chap,http-pap html-directory="" http-cookie-lifetime=1d
```

**Via Winbox:**
1. Ir em **IP** > **Hotspot** > **Server Profiles**
2. Duplo clique em **perfil-captive**
3. Aba **General:**
   - **HTML Directory:** (deixar vazio)
4. Aba **Login:**
   - **Login By:** HTTP CHAP, HTTP PAP (marcar ambos)
   - **HTTP Cookie Lifetime:** 1d 00:00:00
5. Clicar em **OK**

---

## PASSO 9: Verificar Configuracao do Hotspot

### Verificar:
```
/ip hotspot print
```

### O hotspot deve estar assim:
```
name="hotspot-wifi" interface=bridge-lan address-pool=dhcp_pool2 profile=perfil-captive
```

---

## PASSO 10: Testar a Configuracao

### 10.1 Testar conectividade ao servidor:
```
/ping 192.168.10.250 count=3
```

### 10.2 Verificar usuarios ativos no hotspot:
```
/ip hotspot active print
```

### 10.3 Verificar IP bindings:
```
/ip hotspot ip-binding print
```

### 10.4 Verificar Address List:
```
/ip firewall address-list print where list=authorized_users
```

---

## Resumo das Configuracoes Necessarias

### Terminal - Todos os Comandos em Sequencia:

```routeros
# 1. Verificar/Adicionar ether3 na bridge (servidor)
/interface bridge port add bridge=bridge-lan interface=ether3

# 2. MOVER VLAN 110 PARA ACESSO LIVRE (sem hotspot)
/interface bridge port remove [find interface="VLAN 110 RADIO DAY USE HOTSPOT" bridge=bridge-lan]
/interface bridge port add bridge=DHCP-FORA-HOTSPOT interface="VLAN 110 RADIO DAY USE HOTSPOT"

# 3. GARANTIR VLAN 112 NO HOTSPOT
/interface bridge port add bridge=bridge-lan interface="VLAN 112 RADIO LADEIRA HOTSPOT"

# 4. IP Binding para servidor
/ip hotspot ip-binding add address=192.168.10.250 type=bypassed comment="Servidor_Portal_Captive"

# 5. Address List
/ip firewall address-list add address=192.168.10.250 list=authorized_users comment="Servidor_Captive_Portal"

# 6. Walled Garden
/ip hotspot walled-garden add dst-host=192.168.10.250 comment="Portal Captive Servidor"

# 7. Walled Garden IP
/ip hotspot walled-garden ip add action=accept dst-address=192.168.10.250 dst-port=3000 protocol=tcp comment="Portal-Server-HTTP"

# 8. Firewall - API
/ip firewall filter add chain=input action=accept protocol=tcp dst-port=8728 src-address=192.168.10.250 comment="API Portal Captive" place-before=0

# 9. Firewall - Forward autorizados
/ip firewall filter add chain=forward action=accept src-address-list=authorized_users comment="Liberar usuarios autorizados" place-before=0

# 10. Firewall - Webhook
/ip firewall filter add chain=forward action=accept protocol=tcp dst-port=3000 dst-address=192.168.10.250 comment="Webhook Portal" place-before=0

# 11. Habilitar API
/ip service set api disabled=no port=8728 address=192.168.10.0/24

# 12. Configurar perfil hotspot
/ip hotspot profile set [find name=perfil-captive] login-by=http-chap,http-pap html-directory="" http-cookie-lifetime=1d
```

---

## Troubleshooting

### Problema: Servidor nao consegue se comunicar com API

**Verificar:**
```
/ip service print where name=api
```

**Solucao:**
```
/ip service set api disabled=no address=192.168.10.0/24
```

### Problema: Clientes nao conseguem acessar o portal

**Verificar Walled Garden:**
```
/ip hotspot walled-garden print
/ip hotspot walled-garden ip print
```

**Verificar se o IP do servidor esta em bypass:**
```
/ip hotspot ip-binding print where address=192.168.10.250
```

### Problema: Apos pagamento, cliente nao navega

**Verificar Address List:**
```
/ip firewall address-list print where list=authorized_users
```

**Verificar regras de firewall:**
```
/ip firewall filter print where src-address-list=authorized_users
```

### Problema: Regras de firewall nao funcionam

**As regras devem estar no TOPO da lista, antes de regras de DROP.**

Para mover uma regra:
```
/ip firewall filter move [find comment="API Portal Captive"] destination=0
```

---

## Diagrama de Rede

```
                         INTERNET
                             |
                        [NE8000 BGP]
                             |
                       VLAN 66 (Uplink)
                             |
                       +-----------+
                       | CCR1036   |
                       | SFP+1     |
                       +-----------+
                             |
         +-------------------+-------------------+
         |                                       |
    VLAN 112                               VLAN 110
    (Radio Ladeira)                        (Radio Day Use)
    HOTSPOT                                ACESSO LIVRE
         |                                       |
         v                                       v
+------------------+                   +--------------------+
| bridge-lan       |                   | DHCP-FORA-HOTSPOT  |
| 192.168.10.1/22  |                   | 172.25.0.1/22      |
+------------------+                   +--------------------+
         |                                       |
  +------+------+                          Clientes com
  |      |      |                          senha normal
ether2 ether3 ether4                       (sem portal)
         |
   Servidor Ubuntu
   192.168.10.250:3000
   (Portal Captivo)

FLUXO:
- VLAN 112 -> bridge-lan -> Hotspot -> Portal Captivo -> Pagamento
- VLAN 110 -> DHCP-FORA-HOTSPOT -> Internet direto (com senha WiFi)
```

---

## Fluxo de Autenticacao

### VLAN 112 - Radio Ladeira (HOTSPOT - Portal Captivo)
1. Cliente conecta no WiFi das antenas da VLAN 112
2. Cliente recebe IP da faixa 192.168.8.0/22 (bridge-lan)
3. Hotspot intercepta requisicao HTTP
4. Cliente e redirecionado para http://192.168.10.250:3000/portal
5. Cliente realiza pagamento via PIX
6. Servidor Node.js recebe webhook do AbacatePay
7. Servidor adiciona MAC do cliente ao IP Binding (type=bypassed)
8. Servidor adiciona IP do cliente a Address List (authorized_users)
9. Cliente pode navegar normalmente

### VLAN 110 - Radio Day Use (ACESSO LIVRE)
1. Cliente conecta no WiFi das antenas da VLAN 110 usando senha
2. Cliente recebe IP da faixa 172.25.0.0/22 (DHCP-FORA-HOTSPOT)
3. Cliente navega diretamente sem portal captivo
4. NAT via 45.187.168.216/30

---

**Ultima atualizacao:** Fevereiro 2026
