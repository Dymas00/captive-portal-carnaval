/**
 * Security Middleware
 * Rate limiting, sanitização e validação de entrada
 */

const rateLimit = require('express-rate-limit');
const { body, validationResult } = require('express-validator');
const pino = require('pino');
const { logSecurityEvent } = require('../database/db-manager');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

/**
 * Rate limiter geral
 */
const generalRateLimit = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutos
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
    message: {
        error: 'Muitas requisições. Tente novamente em alguns minutos.',
        retryAfter: 15
    },
    standardHeaders: true,
    legacyHeaders: false,
    // Pular rate limit geral para endpoints com rate limit específico
    skip: (req) => {
        // Polling de status de pagamento tem rate limit próprio
        if (req.path.startsWith('/api/payments/status/')) return true;
        // Webhooks têm rate limit próprio
        if (req.path.startsWith('/api/webhooks/')) return true;
        return false;
    },
    handler: async (req, res, next, options) => {
        logger.warn({
            ip: req.ip,
            path: req.path
        }, 'Rate limit excedido');

        try {
            await logSecurityEvent('RATE_LIMIT_HIT', {
                ip: req.ip,
                path: req.path,
                method: req.method,
                severity: 'WARN'
            });
        } catch (e) { }

        res.status(429).json(options.message);
    }
});

/**
 * Rate limiter para login
 */
const loginRateLimit = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutos
    max: parseInt(process.env.LOGIN_RATE_LIMIT_MAX) || 5,
    message: {
        error: 'Muitas tentativas de login. Tente novamente em 15 minutos.',
        retryAfter: 15
    },
    skipSuccessfulRequests: true,
    handler: async (req, res, next, options) => {
        logger.warn({
            ip: req.ip,
            cpf: req.body?.cpf?.substring(0, 3) + '***'
        }, 'Rate limit de login excedido');

        try {
            await logSecurityEvent('LOGIN_RATE_LIMIT', {
                ip: req.ip,
                userAgent: req.get('user-agent'),
                severity: 'WARN'
            });
        } catch (e) { }

        res.status(429).json(options.message);
    }
});

/**
 * Rate limiter para pagamentos (criar novo pagamento)
 */
const paymentRateLimit = rateLimit({
    windowMs: 5 * 60 * 1000, // 5 minutos
    max: parseInt(process.env.PAYMENT_RATE_LIMIT_MAX) || 3,
    message: {
        error: 'Muitas solicitações de pagamento. Aguarde alguns minutos.',
        retryAfter: 5
    }
});

/**
 * Rate limiter para polling de status de pagamento
 * Mais permissivo porque o frontend faz polling a cada 3 segundos
 */
const paymentStatusRateLimit = rateLimit({
    windowMs: 60 * 1000, // 1 minuto
    max: 60, // 60 requisições por minuto (permite polling a cada 1 segundo)
    message: {
        error: 'Muitas consultas de status. Aguarde alguns segundos.',
        retryAfter: 1
    },
    keyGenerator: (req) => {
        // Rate limit por IP + payment ID para não afetar outros usuários
        return `${req.ip}-${req.params.paymentId || 'unknown'}`;
    }
});

/**
 * Rate limiter para webhooks
 */
const webhookRateLimit = rateLimit({
    windowMs: 60 * 1000, // 1 minuto
    max: 30,
    message: { error: 'Rate limit excedido para webhooks' }
});

/**
 * Sanitizar entrada - remover caracteres perigosos
 */
function sanitizeInput(req, res, next) {
    const sanitize = (obj) => {
        if (typeof obj === 'string') {
            // Remover scripts e tags HTML
            return obj
                .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                .replace(/<[^>]*>/g, '')
                .replace(/javascript:/gi, '')
                .replace(/on\w+=/gi, '')
                .trim();
        }

        if (Array.isArray(obj)) {
            return obj.map(sanitize);
        }

        if (typeof obj === 'object' && obj !== null) {
            const sanitized = {};
            for (const key of Object.keys(obj)) {
                sanitized[key] = sanitize(obj[key]);
            }
            return sanitized;
        }

        return obj;
    };

    if (req.body) req.body = sanitize(req.body);
    if (req.query) req.query = sanitize(req.query);
    if (req.params) req.params = sanitize(req.params);

    next();
}

/**
 * Prevenir SQL Injection
 */
function preventSqlInjection(req, res, next) {
    const sqlPatterns = [
        /(\%27)|(\')|(\-\-)|(\%23)|(#)/i,
        /((\%3D)|(=))[^\n]*((\%27)|(\')|(\-\-)|(\%3B)|(;))/i,
        /\w*((\%27)|(\'))((\%6F)|o|(\%4F))((\%72)|r|(\%52))/i,
        /((\%27)|(\'))union/i,
        /exec(\s|\+)+(s|x)p\w+/i,
        /union\s+select/i,
        /select\s+.*\s+from/i,
        /insert\s+into/i,
        /delete\s+from/i,
        /drop\s+table/i
    ];

    const checkValue = (value) => {
        if (typeof value === 'string') {
            return sqlPatterns.some(pattern => pattern.test(value));
        }
        return false;
    };

    const checkObject = (obj) => {
        if (typeof obj !== 'object' || obj === null) return false;

        for (const key of Object.keys(obj)) {
            if (checkValue(obj[key]) || checkValue(key)) return true;
            if (typeof obj[key] === 'object' && checkObject(obj[key])) return true;
        }
        return false;
    };

    if (checkObject(req.body) || checkObject(req.query) || checkObject(req.params)) {
        logger.warn({
            ip: req.ip,
            path: req.path,
            method: req.method
        }, 'Tentativa de SQL Injection detectada');

        logSecurityEvent('SQL_INJECTION_ATTEMPT', {
            ip: req.ip,
            path: req.path,
            method: req.method,
            userAgent: req.get('user-agent'),
            severity: 'CRITICAL'
        }).catch(() => { });

        return res.status(403).json({
            error: 'Requisição bloqueada por motivos de segurança'
        });
    }

    next();
}

/**
 * Validação de CPF
 */
function validateCPF(cpf) {
    cpf = cpf.replace(/\D/g, '');

    if (cpf.length !== 11) return false;

    // Verifica CPFs com dígitos iguais
    if (/^(\d)\1+$/.test(cpf)) return false;

    // Validação do primeiro dígito
    let sum = 0;
    for (let i = 0; i < 9; i++) {
        sum += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let digit = 11 - (sum % 11);
    if (digit >= 10) digit = 0;
    if (digit !== parseInt(cpf.charAt(9))) return false;

    // Validação do segundo dígito
    sum = 0;
    for (let i = 0; i < 10; i++) {
        sum += parseInt(cpf.charAt(i)) * (11 - i);
    }
    digit = 11 - (sum % 11);
    if (digit >= 10) digit = 0;
    if (digit !== parseInt(cpf.charAt(10))) return false;

    return true;
}

/**
 * Validação de MAC Address
 */
function validateMacAddress(mac) {
    const macRegex = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;
    return macRegex.test(mac);
}

/**
 * Validadores para registro
 */
const registerValidation = [
    body('name')
        .trim()
        .notEmpty().withMessage('Nome é obrigatório')
        .isLength({ min: 3, max: 255 }).withMessage('Nome deve ter entre 3 e 255 caracteres'),

    body('cpf')
        .trim()
        .notEmpty().withMessage('CPF é obrigatório')
        .custom((value) => {
            if (!validateCPF(value)) {
                throw new Error('CPF inválido');
            }
            return true;
        }),

    body('email')
        .optional({ checkFalsy: true })
        .trim()
        .isEmail().withMessage('Email inválido')
        .normalizeEmail(),

    body('phone')
        .optional({ checkFalsy: true })
        .trim()
        .matches(/^\d{10,11}$/).withMessage('Telefone inválido'),

    body('password')
        .notEmpty().withMessage('Senha é obrigatória')
        .isLength({ min: 6 }).withMessage('Senha deve ter no mínimo 6 caracteres'),

    body('mac_address')
        .optional()
        .trim()
        .custom((value) => {
            if (value && !validateMacAddress(value)) {
                throw new Error('MAC Address inválido');
            }
            return true;
        })
];

/**
 * Validadores para login
 */
const loginValidation = [
    body('cpf')
        .trim()
        .notEmpty().withMessage('CPF é obrigatório'),

    body('password')
        .notEmpty().withMessage('Senha é obrigatória')
];

/**
 * Validadores para pagamento
 */
const paymentValidation = [
    body('plan_id')
        .notEmpty().withMessage('Plano é obrigatório')
        .isInt({ min: 1 }).withMessage('ID do plano inválido'),

    body('mac_address')
        .optional()
        .trim()
        .custom((value) => {
            if (value && !validateMacAddress(value)) {
                throw new Error('MAC Address inválido');
            }
            return true;
        })
];

/**
 * Processar erros de validação
 */
function handleValidationErrors(req, res, next) {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Dados inválidos',
            details: errors.array().map(e => ({
                field: e.path,
                message: e.msg
            }))
        });
    }

    next();
}

/**
 * Middleware de autenticação JWT
 */
const jwt = require('jsonwebtoken');

function authenticate(req, res, next) {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ error: 'Token de acesso não fornecido' });
        }

        const token = authHeader.substring(7);

        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        req.user = decoded;
        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ error: 'Token expirado' });
        }

        return res.status(401).json({ error: 'Token inválido' });
    }
}

/**
 * Middleware de autorização por role
 */
function authorize(...roles) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'Não autenticado' });
        }

        if (!roles.includes(req.user.role)) {
            logger.warn({
                userId: req.user.id,
                role: req.user.role,
                requiredRoles: roles,
                path: req.path
            }, 'Acesso não autorizado');

            return res.status(403).json({ error: 'Acesso não autorizado' });
        }

        next();
    };
}

module.exports = {
    generalRateLimit,
    loginRateLimit,
    paymentRateLimit,
    paymentStatusRateLimit,
    webhookRateLimit,
    sanitizeInput,
    preventSqlInjection,
    validateCPF,
    validateMacAddress,
    registerValidation,
    loginValidation,
    paymentValidation,
    handleValidationErrors,
    authenticate,
    authorize
};
