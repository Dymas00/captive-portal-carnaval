# 🧪 TESTES DE CARGA - CAPTIVE PORTAL CARNAVAL

Documentação completa para execução de testes de carga simulando até **4.000+ usuários simultâneos**.

---

## 📋 OPÇÕES DE FERRAMENTAS

Oferecemos dois tipos de testes de carga:

### 1. **Artillery** (Recomendado para iniciantes)
- ✅ Mais fácil de usar
- ✅ Configuração em YAML
- ✅ Relatórios HTML bonitos
- ❌ Menos performático em testes extremos

### 2. **K6** (Recomendado para testes profissionais)
- ✅ Mais performático
- ✅ Consome menos recursos
- ✅ Melhor para testes de stress extremo
- ✅ Métricas mais detalhadas
- ❌ Curva de aprendizado maior

---

## 🚀 OPÇÃO 1: ARTILLERY

### Instalação

```bash
npm install -g artillery
```

### Executar Teste Básico

```bash
cd /Volumes/10.0.0.107/Projeto\ saulo/captive-portal-carnaval
artillery run tests/load-test.yml
```

### Executar com Relatório HTML

```bash
artillery run tests/load-test.yml --output report.json
artillery report report.json --output report.html
open report.html
```

### Tipos de Teste (Editar arquivo YAML)

O arquivo `load-test.yml` contém 6 fases pré-configuradas:

1. **Aquecimento** (60s) - 10 usuários/segundo
2. **Ramp-up** (120s) - 10 → 50 usuários/segundo
3. **Carga Alta** (180s) - 50 usuários/segundo (~2500 usuários ativos)
4. **Stress** (120s) - 50 → 100 usuários/segundo
5. **Pico Máximo** (180s) - 100 usuários/segundo (~4000 usuários ativos)
6. **Cooldown** (60s) - 100 → 10 usuários/segundo

**Duração total:** ~13 minutos
**Pico de usuários simultâneos:** ~4000

---

## ⚡ OPÇÃO 2: K6 (RECOMENDADO)

### Instalação

**macOS:**
```bash
brew install k6
```

**Linux (Ubuntu/Debian):**
```bash
sudo gpg -k
sudo gpg --no-default-keyring --keyring /usr/share/keyrings/k6-archive-keyring.gpg \
  --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys C5AD17C747E3415A3642D57D77C6C491D6AC1D69
echo "deb [signed-by=/usr/share/keyrings/k6-archive-keyring.gpg] https://dl.k6.io/deb stable main" | \
  sudo tee /etc/apt/sources.list.d/k6.list
sudo apt-get update
sudo apt-get install k6
```

**Windows:**
```bash
choco install k6
```

### Tipos de Teste

#### 1. Teste de Fumaça (Smoke Test) - 1 minuto
Teste rápido para verificar se tudo está funcionando:

```bash
k6 run tests/load-test-k6.js --env TEST_TYPE=smoke
```

#### 2. Teste de Carga (Load Test) - 10 minutos
Simula ~2000 usuários simultâneos:

```bash
k6 run tests/load-test-k6.js --env TEST_TYPE=load
```

#### 3. Teste de Stress - 15 minutos ⚠️
Simula 4000-6000 usuários simultâneos:

```bash
k6 run tests/load-test-k6.js --env TEST_TYPE=stress
```

#### 4. Teste de Pico (Spike Test) - 4 minutos
Pico súbito de 2000 usuários:

```bash
k6 run tests/load-test-k6.js --env TEST_TYPE=spike
```

### Alterar URL do Servidor

```bash
k6 run tests/load-test-k6.js --env BASE_URL=https://seudominio.com
```

### Gerar Relatório HTML

```bash
k6 run --out json=report.json tests/load-test-k6.js
# Converter para HTML (requer ferramenta adicional)
```

---

## 📊 CENÁRIOS DE TESTE

Ambas as ferramentas testam os seguintes cenários:

### 1. **Fluxo Completo de Usuário Novo** (30%)
- Acesso à página inicial
- Visualização de planos
- Cadastro de novo usuário
- Login
- Criação de pagamento PIX
- Verificação de status de pagamento
- Verificação de sessão ativa

### 2. **Usuário Existente** (40%)
- Login com credenciais existentes
- Verificação de dados do usuário
- Visualização de planos
- Verificação de sessão ativa

### 3. **Navegação Pública** (20%)
- Acesso à homepage
- Visualização de planos
- Health check
- Captive portal detection URLs

### 4. **Admin Dashboard** (10%)
- Login como administrador
- Acesso ao dashboard
- Visualização de usuários
- Visualização de sessões ativas
- Visualização de logs

---

## 📈 MÉTRICAS IMPORTANTES

### O que observar durante o teste:

1. **Taxa de Erro (Error Rate)**
   - Objetivo: < 5%
   - Aceitável: < 10%
   - Crítico: > 15%

2. **Tempo de Resposta**
   - P50 (mediana): < 500ms
   - P95: < 2000ms
   - P99: < 5000ms

3. **Requisições por Segundo (RPS)**
   - Mínimo esperado: 100 RPS
   - Bom: 500+ RPS
   - Excelente: 1000+ RPS

4. **Sucessos HTTP**
   - Objetivo: > 95%

---

## 🔍 MONITORAMENTO DURANTE O TESTE

### Enquanto o teste roda, monitore:

#### 1. Logs do Servidor
```bash
docker compose logs -f app
```

#### 2. Uso de Recursos
```bash
docker stats
```

#### 3. PostgreSQL
```bash
docker compose exec postgres psql -U captive -d captive_portal -c "SELECT count(*) FROM sessions WHERE status='active';"
```

#### 4. Redis
```bash
docker compose exec redis redis-cli INFO stats
```

---

## ⚠️ AVISOS IMPORTANTES

### Antes de executar testes de stress:

1. ✅ Certifique-se de que está em **ambiente de homologação**, não produção
2. ✅ Avise a equipe antes de executar
3. ✅ Monitore os recursos do servidor em tempo real
4. ✅ Tenha um plano de rollback caso algo dê errado
5. ✅ Execute primeiro um teste de fumaça para validar

### Não execute testes de carga se:

- ❌ O sistema estiver em produção com usuários reais
- ❌ Você não tiver acesso aos logs e monitoramento
- ❌ O servidor não atender aos requisitos mínimos de hardware

---

## 🐛 TROUBLESHOOTING

### Problema: "Connection refused" ou timeout

**Solução:**
1. Verifique se o servidor está rodando:
   ```bash
   curl https://capitive.ateliemyrellasilva.com.br/health
   ```

2. Verifique se há firewall bloqueando:
   ```bash
   telnet capitive.ateliemyrellasilva.com.br 443
   ```

3. Verifique os containers:
   ```bash
   docker compose ps
   ```

### Problema: Taxa de erro muito alta (> 20%)

**Possíveis causas:**
- Recursos do servidor insuficientes (CPU, RAM)
- Banco de dados saturado
- Conexões de rede limitadas
- Rate limiting muito agressivo

**Solução:**
1. Reduza a carga do teste
2. Aumente recursos do servidor
3. Ajuste configurações de pool do PostgreSQL
4. Ajuste rate limiting no código

### Problema: Teste muito lento

**Solução Artillery:**
```bash
# Reduza o número de usuários no arquivo YAML
arrivalRate: 10  # Era 100
```

**Solução K6:**
```bash
# Use teste de smoke primeiro
k6 run tests/load-test-k6.js --env TEST_TYPE=smoke
```

---

## 📋 CHECKLIST PÓS-TESTE

Após executar o teste, verifique:

- [ ] Taxa de erro aceitável (< 10%)
- [ ] Tempos de resposta dentro do esperado
- [ ] Nenhum erro crítico nos logs
- [ ] Banco de dados estável
- [ ] Redis funcionando normalmente
- [ ] Containers saudáveis (`docker compose ps`)
- [ ] Sessões criadas corretamente
- [ ] Pagamentos processados sem erros

---

## 📞 SUPORTE

Se encontrar problemas:

1. Verifique os logs: `docker compose logs -f app`
2. Verifique o status: `docker compose ps`
3. Reinicie se necessário: `docker compose restart`
4. Abra uma issue no repositório

---

## 🎯 PRÓXIMOS PASSOS

Após validar os testes:

1. Configure monitoramento com Prometheus/Grafana
2. Configure alertas para métricas críticas
3. Documente os resultados obtidos
4. Ajuste o hardware conforme necessário (veja [SERVER_REQUIREMENTS.md](../SERVER_REQUIREMENTS.md))
