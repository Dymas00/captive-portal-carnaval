/**
 * ============================================
 * K6 LOAD TEST - CAPTIVE PORTAL CARNAVAL
 * Teste de carga para até 4000+ usuários simultâneos
 * ============================================
 *
 * Instalação do K6:
 * macOS: brew install k6
 * Linux: sudo apt install k6
 * Windows: choco install k6
 *
 * Executar teste:
 * k6 run tests/load-test-k6.js
 *
 * Executar com relatório HTML:
 * k6 run --out html=report.html tests/load-test-k6.js
 *
 * Executar teste de smoke (rápido):
 * k6 run tests/load-test-k6.js --env TEST_TYPE=smoke
 *
 * Executar teste de stress (máximo):
 * k6 run tests/load-test-k6.js --env TEST_TYPE=stress
 * ============================================
 */

import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Rate, Trend, Counter } from 'k6/metrics';
import { randomString, randomIntBetween } from 'https://jslib.k6.io/k6-utils/1.2.0/index.js';

// ===== CONFIGURAÇÃO =====
const BASE_URL = __ENV.BASE_URL || 'https://capitive.ateliemyrellasilva.com.br';
const TEST_TYPE = __ENV.TEST_TYPE || 'load'; // smoke, load, stress, spike

// ===== MÉTRICAS PERSONALIZADAS =====
const errorRate = new Rate('errors');
const loginDuration = new Trend('login_duration');
const paymentDuration = new Trend('payment_duration');
const sessionCreation = new Counter('sessions_created');
const paymentsCreated = new Counter('payments_created');

// ===== CONFIGURAÇÕES DE TESTE =====
const testConfigs = {
    // Teste rápido de fumaça (1 minuto)
    smoke: {
        stages: [
            { duration: '30s', target: 10 },
            { duration: '30s', target: 0 },
        ],
        thresholds: {
            http_req_duration: ['p(95)<2000'],
            errors: ['rate<0.1'],
        },
    },

    // Teste de carga (10 minutos, ~2000 usuários)
    load: {
        stages: [
            { duration: '1m', target: 50 },     // Warm-up
            { duration: '3m', target: 200 },    // Ramp-up
            { duration: '5m', target: 500 },    // Carga normal (~2000 usuários ativos)
            { duration: '1m', target: 0 },      // Cool-down
        ],
        thresholds: {
            http_req_duration: ['p(95)<5000', 'p(99)<10000'],
            http_req_failed: ['rate<0.05'],
            errors: ['rate<0.1'],
        },
    },

    // Teste de stress (15 minutos, 4000+ usuários)
    stress: {
        stages: [
            { duration: '2m', target: 100 },    // Warm-up
            { duration: '3m', target: 500 },    // Ramp-up moderado
            { duration: '5m', target: 1000 },   // Carga alta (~4000 usuários ativos)
            { duration: '3m', target: 1500 },   // Stress máximo (~6000 usuários)
            { duration: '2m', target: 0 },      // Cool-down
        ],
        thresholds: {
            http_req_duration: ['p(95)<10000'],
            http_req_failed: ['rate<0.1'],
            errors: ['rate<0.2'],
        },
    },

    // Teste de pico (spike)
    spike: {
        stages: [
            { duration: '30s', target: 100 },   // Warm-up
            { duration: '30s', target: 2000 },  // Pico súbito
            { duration: '2m', target: 2000 },   // Manter pico
            { duration: '30s', target: 100 },   // Queda
            { duration: '30s', target: 0 },     // Cool-down
        ],
        thresholds: {
            http_req_duration: ['p(95)<15000'],
            http_req_failed: ['rate<0.15'],
        },
    },
};

export const options = testConfigs[TEST_TYPE];

// ===== FUNÇÕES AUXILIARES =====

/**
 * Gerar CPF válido
 */
function generateCPF() {
    const nums = [];
    for (let i = 0; i < 9; i++) {
        nums.push(randomIntBetween(0, 9));
    }

    // Primeiro dígito verificador
    let sum = 0;
    for (let i = 0; i < 9; i++) {
        sum += nums[i] * (10 - i);
    }
    let digit1 = 11 - (sum % 11);
    if (digit1 >= 10) digit1 = 0;
    nums.push(digit1);

    // Segundo dígito verificador
    sum = 0;
    for (let i = 0; i < 10; i++) {
        sum += nums[i] * (11 - i);
    }
    let digit2 = 11 - (sum % 11);
    if (digit2 >= 10) digit2 = 0;
    nums.push(digit2);

    return nums.join('');
}

/**
 * Gerar MAC address
 */
function generateMac() {
    return Array.from({ length: 6 }, () =>
        randomIntBetween(0, 255).toString(16).padStart(2, '0')
    ).join(':').toUpperCase();
}

/**
 * Gerar dados de usuário
 */
function generateUser() {
    return {
        name: `Usuario Teste ${randomString(8)}`,
        cpf: generateCPF(),
        password: `Senha@${randomIntBetween(1000, 9999)}`,
        email: `test${randomIntBetween(1000, 999999)}@carnaval.com`,
        phone: `(81) 9${randomIntBetween(1000, 9999)}-${randomIntBetween(1000, 9999)}`,
        mac: generateMac(),
    };
}

// ===== CENÁRIOS DE TESTE =====

/**
 * Cenário principal de teste
 */
export default function () {
    const scenario = randomIntBetween(1, 100);

    if (scenario <= 30) {
        // 30% - Fluxo completo (cadastro + compra)
        fullUserFlow();
    } else if (scenario <= 70) {
        // 40% - Login de usuário existente
        existingUserFlow();
    } else if (scenario <= 90) {
        // 20% - Navegação pública
        publicBrowsing();
    } else {
        // 10% - Admin dashboard
        adminFlow();
    }

    sleep(randomIntBetween(1, 3));
}

/**
 * Fluxo completo: Cadastro → Login → Compra
 */
function fullUserFlow() {
    group('Full User Flow', () => {
        const user = generateUser();
        let authToken = null;
        let planId = null;

        // 1. Página inicial
        group('Homepage', () => {
            const res = http.get(`${BASE_URL}/`);
            check(res, {
                'homepage loaded': (r) => r.status === 200,
            }) || errorRate.add(1);
        });

        // 2. Buscar planos
        group('Get Plans', () => {
            const res = http.get(`${BASE_URL}/api/plans`);
            const success = check(res, {
                'plans loaded': (r) => r.status === 200,
                'has plans': (r) => {
                    try {
                        const plans = JSON.parse(r.body);
                        return plans.length > 0;
                    } catch (e) {
                        return false;
                    }
                },
            });

            if (success && res.status === 200) {
                try {
                    const plans = JSON.parse(res.body);
                    planId = plans[0].id;
                } catch (e) {
                    console.error('Failed to parse plans:', e);
                }
            } else {
                errorRate.add(1);
            }
        });

        // 3. Cadastro
        group('Register', () => {
            const startTime = new Date();
            const res = http.post(`${BASE_URL}/api/auth/register`, JSON.stringify(user), {
                headers: { 'Content-Type': 'application/json' },
            });

            const success = check(res, {
                'register successful': (r) => r.status === 201 || r.status === 200,
            });

            if (success) {
                loginDuration.add(new Date() - startTime);
                try {
                    const data = JSON.parse(res.body);
                    authToken = data.token;
                } catch (e) {
                    console.error('Failed to parse register response:', e);
                }
            } else {
                errorRate.add(1);
            }
        });

        // 4. Criar pagamento (se autenticado e tem plano)
        if (authToken && planId) {
            group('Create Payment', () => {
                const startTime = new Date();
                const res = http.post(
                    `${BASE_URL}/api/payments/create`,
                    JSON.stringify({ plan_id: planId }),
                    {
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${authToken}`,
                        },
                    }
                );

                const success = check(res, {
                    'payment created': (r) => r.status === 200 || r.status === 201,
                });

                if (success) {
                    paymentDuration.add(new Date() - startTime);
                    paymentsCreated.add(1);
                } else {
                    errorRate.add(1);
                }
            });

            // 5. Verificar sessão
            group('Check Session', () => {
                const res = http.get(`${BASE_URL}/api/sessions/my`, {
                    headers: { 'Authorization': `Bearer ${authToken}` },
                });

                check(res, {
                    'session check ok': (r) => r.status === 200,
                }) || errorRate.add(1);
            });
        }
    });
}

/**
 * Fluxo de usuário existente
 */
function existingUserFlow() {
    group('Existing User Flow', () => {
        // Login com admin
        const res = http.post(
            `${BASE_URL}/api/auth/login`,
            JSON.stringify({
                cpf: '11111111111',
                password: 'Admin@Carnaval2026!',
            }),
            {
                headers: { 'Content-Type': 'application/json' },
            }
        );

        const success = check(res, {
            'login successful': (r) => r.status === 200,
        });

        if (success) {
            try {
                const data = JSON.parse(res.body);
                const token = data.token;

                // Verificar dados do usuário
                const meRes = http.get(`${BASE_URL}/api/auth/me`, {
                    headers: { 'Authorization': `Bearer ${token}` },
                });

                check(meRes, {
                    'get user data ok': (r) => r.status === 200,
                }) || errorRate.add(1);
            } catch (e) {
                errorRate.add(1);
            }
        } else {
            errorRate.add(1);
        }
    });
}

/**
 * Navegação pública (sem autenticação)
 */
function publicBrowsing() {
    group('Public Browsing', () => {
        // Homepage
        const homeRes = http.get(`${BASE_URL}/`);
        check(homeRes, {
            'homepage ok': (r) => r.status === 200,
        }) || errorRate.add(1);

        // Planos
        const plansRes = http.get(`${BASE_URL}/api/plans`);
        check(plansRes, {
            'plans ok': (r) => r.status === 200,
        }) || errorRate.add(1);

        // Health check
        const healthRes = http.get(`${BASE_URL}/health`);
        check(healthRes, {
            'health ok': (r) => r.status === 200,
        }) || errorRate.add(1);

        // Captive portal detection
        const detectRes = http.get(`${BASE_URL}/generate_204`);
        check(detectRes, {
            'detection ok': (r) => r.status === 200 || r.status === 302,
        }) || errorRate.add(1);
    });
}

/**
 * Fluxo admin
 */
function adminFlow() {
    group('Admin Flow', () => {
        // Login admin
        const loginRes = http.post(
            `${BASE_URL}/api/auth/login`,
            JSON.stringify({
                cpf: '11111111111',
                password: 'Admin@Carnaval2026!',
            }),
            {
                headers: { 'Content-Type': 'application/json' },
            }
        );

        const success = check(loginRes, {
            'admin login ok': (r) => r.status === 200,
        });

        if (success) {
            try {
                const data = JSON.parse(loginRes.body);
                const token = data.token;

                // Dashboard
                const dashRes = http.get(`${BASE_URL}/api/admin/dashboard`, {
                    headers: { 'Authorization': `Bearer ${token}` },
                });
                check(dashRes, {
                    'dashboard ok': (r) => r.status === 200,
                }) || errorRate.add(1);

                // Usuários
                const usersRes = http.get(`${BASE_URL}/api/admin/users?page=1&limit=20`, {
                    headers: { 'Authorization': `Bearer ${token}` },
                });
                check(usersRes, {
                    'users ok': (r) => r.status === 200,
                }) || errorRate.add(1);

                // Sessões ativas
                const sessionsRes = http.get(`${BASE_URL}/api/sessions/active`, {
                    headers: { 'Authorization': `Bearer ${token}` },
                });
                check(sessionsRes, {
                    'sessions ok': (r) => r.status === 200,
                }) || errorRate.add(1);
            } catch (e) {
                errorRate.add(1);
            }
        } else {
            errorRate.add(1);
        }
    });
}

// ===== RELATÓRIO FINAL =====
export function handleSummary(data) {
    return {
        'stdout': textSummary(data, { indent: ' ', enableColors: true }),
        'summary.json': JSON.stringify(data),
    };
}

function textSummary(data, options) {
    const indent = options.indent || '';
    const colors = options.enableColors;

    let output = '\n';
    output += `${indent}╔═══════════════════════════════════════════════════════════╗\n`;
    output += `${indent}║                                                           ║\n`;
    output += `${indent}║   📊 RELATÓRIO DE TESTE DE CARGA - CAPTIVE PORTAL       ║\n`;
    output += `${indent}║                                                           ║\n`;
    output += `${indent}╚═══════════════════════════════════════════════════════════╝\n\n`;

    const metrics = data.metrics;

    output += `${indent}Requisições totais: ${metrics.http_reqs.values.count}\n`;
    output += `${indent}Taxa de erro: ${(metrics.errors.values.rate * 100).toFixed(2)}%\n`;
    output += `${indent}Duração média: ${metrics.http_req_duration.values.avg.toFixed(2)}ms\n`;
    output += `${indent}P95: ${metrics.http_req_duration.values['p(95)'].toFixed(2)}ms\n`;
    output += `${indent}P99: ${metrics.http_req_duration.values['p(99)'].toFixed(2)}ms\n`;

    if (metrics.payments_created) {
        output += `${indent}\nPagamentos criados: ${metrics.payments_created.values.count}\n`;
    }

    return output;
}
