/**
 * Artillery Load Test Processor
 * Funções customizadas para geração de dados de teste
 */

const crypto = require('crypto');

/**
 * Gerar CPF válido aleatório
 */
function generateCPF() {
    // Gera os 9 primeiros dígitos
    const nums = [];
    for (let i = 0; i < 9; i++) {
        nums.push(Math.floor(Math.random() * 10));
    }

    // Calcula primeiro dígito verificador
    let sum = 0;
    for (let i = 0; i < 9; i++) {
        sum += nums[i] * (10 - i);
    }
    let digit1 = 11 - (sum % 11);
    if (digit1 >= 10) digit1 = 0;
    nums.push(digit1);

    // Calcula segundo dígito verificador
    sum = 0;
    for (let i = 0; i < 10; i++) {
        sum += nums[i] * (11 - i);
    }
    let digit2 = 11 - (sum % 11);
    if (digit2 >= 10) digit2 = 0;
    nums.push(digit2);

    return nums.join('');
}

/**
 * Gerar MAC address aleatório
 */
function generateMacAddress() {
    const hex = '0123456789ABCDEF';
    let mac = '';
    for (let i = 0; i < 6; i++) {
        if (i > 0) mac += ':';
        mac += hex[Math.floor(Math.random() * 16)];
        mac += hex[Math.floor(Math.random() * 16)];
    }
    return mac;
}

/**
 * Gerar email aleatório
 */
function generateEmail() {
    const randomString = crypto.randomBytes(8).toString('hex');
    return `test_${randomString}@carnaval-teste.com`;
}

/**
 * Gerar telefone brasileiro aleatório
 */
function generatePhone() {
    const ddd = Math.floor(Math.random() * 89) + 11; // 11 a 99
    const prefix = 9;
    const number = Math.floor(Math.random() * 90000000) + 10000000;
    return `(${ddd}) ${prefix}${number}`;
}

/**
 * Gerar nome aleatório
 */
function generateName() {
    const firstNames = [
        'João', 'Maria', 'José', 'Ana', 'Pedro', 'Paula', 'Carlos', 'Fernanda',
        'Ricardo', 'Juliana', 'Lucas', 'Mariana', 'Felipe', 'Camila', 'Bruno',
        'Amanda', 'Rafael', 'Beatriz', 'Gustavo', 'Larissa'
    ];

    const lastNames = [
        'Silva', 'Santos', 'Oliveira', 'Souza', 'Lima', 'Pereira', 'Costa',
        'Rodrigues', 'Almeida', 'Nascimento', 'Carvalho', 'Fernandes', 'Gomes',
        'Martins', 'Rocha', 'Ribeiro', 'Alves', 'Monteiro', 'Mendes', 'Barros'
    ];

    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const lastName2 = lastNames[Math.floor(Math.random() * lastNames.length)];

    return `${firstName} ${lastName} ${lastName2}`;
}

/**
 * Setup do contexto antes das requisições
 */
function beforeRequest(requestParams, context, ee, next) {
    // Gerar dados de usuário aleatório
    context.vars.randomCPF = generateCPF();
    context.vars.randomMacAddress = generateMacAddress();
    context.vars.randomEmail = generateEmail();
    context.vars.randomPhone = generatePhone();
    context.vars.randomName = generateName();
    context.vars.randomPassword = `Senha@${Math.floor(Math.random() * 10000)}`;

    return next();
}

/**
 * Processar resposta após requisição
 */
function afterResponse(requestParams, response, context, ee, next) {
    // Log de erros
    if (response.statusCode >= 400) {
        console.error(`[ERROR] ${requestParams.url} - Status: ${response.statusCode}`);
        if (response.body) {
            console.error(`Body: ${response.body.substring(0, 200)}`);
        }
    }

    // Métricas customizadas
    if (response.statusCode === 200) {
        ee.emit('counter', `success.${requestParams.url}`, 1);
    } else if (response.statusCode >= 500) {
        ee.emit('counter', `server_error.${requestParams.url}`, 1);
    } else if (response.statusCode >= 400) {
        ee.emit('counter', `client_error.${requestParams.url}`, 1);
    }

    return next();
}

module.exports = {
    beforeRequest,
    afterResponse,
    generateCPF,
    generateMacAddress,
    generateEmail,
    generatePhone,
    generateName
};
